# Дерево узлов сцен (актуальное)

Этот файл фиксирует жёсткие пути узлов, на которые опираются `@onready`-переменные скриптов.
Имена и вложенность менять нельзя без правки скриптов, иначе будет `Node not found`.

Все сцены в проекте уже есть; ниже — их фактическое дерево на момент Этапа 4.

## 1. `res://scenes/player/player.tscn`

```text
Player (CharacterBody3D)  [player.gd]
├── HealthComponent (Node)              [health_component.gd]
├── CollisionShape3D (CollisionShape3D) [CapsuleShape3D, height 1.8]
├── BodyMesh (MeshInstance3D)           [CapsuleMesh]
├── HeadPivot (Node3D)
│   ├── FirstPersonCamera (Camera3D)
│   ├── SpringArm3D (SpringArm3D)
│   │   └── ThirdPersonCamera (Camera3D)
│   ├── AimRayCast3D (RayCast3D)        [target_position (0,0,-50), mask 5]
│   └── WeaponMeshHolder (Node3D)
│       └── WeaponMesh (MeshInstance3D) [BoxMesh — заглушка оружия]
└── InteractionArea3D (Area3D)          [mask 44 = Enemy + Interactable + Corpse]
    └── CollisionShape3D (CollisionShape3D) [SphereShape3D, radius ~2.5]
```

Важно:
- `InteractionArea3D` ловит и `body_entered`, и `area_entered`.
- `AimRayCast3D` попадает в World + Enemy.
- Скрипт сам создаёт дефолтные `WeaponData` (АК-74М и нож), если поля пустые.

## 2. `res://scenes/ui/mobile_hud.tscn`

```text
MobileHUD (CanvasLayer)  [mobile_hud.gd]
└── RootControl (Control)  [anchors: full rect]
    ├── InfectionVignette (ColorRect)   [скрыт, пока нет заражения]
    ├── TopLeftNoise (Control)
    │   ├── BarsContainer (Control)
    │   │   ├── Bar1 (ColorRect)
    │   │   ├── Bar2 (ColorRect)
    │   │   ├── Bar3 (ColorRect)
    │   │   └── Bar4 (ColorRect)
    │   └── NoiseRadiusLabel (Label)
    ├── TopCenterTimer (PanelContainer)
    │   └── TimerLabel (Label)
    ├── ExtractionBanner (PanelContainer)
    │   └── ExtractionLabel (Label)
    ├── TopRightCluster (Control)
    │   ├── HPBar (ProgressBar)
    │   │   └── HPValueLabel (Label)
    │   ├── InjuriesRow (HBoxContainer)
    │   │   ├── BleedBadge (ColorRect) → Label
    │   │   ├── FractureBadge (ColorRect) → Label
    │   │   └── InfectedBadge (ColorRect) → Label
    │   ├── BackpackButton (Button)
    │   ├── StatusTimersLabel (Label)
    │   └── VehicleHPBar (ProgressBar)
    │       └── VehicleHPLabel (Label)
    ├── JoystickTouchZone (Control)
    │   └── JoystickBase (ColorRect)
    │       └── JoystickKnob (ColorRect)
    ├── BottomRightCluster (Control)
    │   ├── CrouchButton (Button)
    │   ├── FireButton (Button)
    │   ├── AimButton (Button)
    │   ├── ReloadButton (Button)
    │   ├── SwitchHandButton (Button)
    │   ├── ContextActionButton (Button)
    │   ├── TrunkButton (Button)
    │   └── WeaponInfoLabel (Label)
    ├── VehicleControlsCluster (Control)
    │   ├── GasButton (Button)
    │   ├── ReverseBrakeButton (Button)
    │   └── ExitVehicleButton (Button)
    └── LockpickQTEPanel (PanelContainer)
        └── VBox (VBoxContainer)
            ├── Title (Label)
            ├── TrackBar (ColorRect)
            │   ├── TargetZone (ColorRect)
            │   └── CursorBar (ColorRect)
            └── HitButton (Button)
```

Важно:
- У `JoystickBase` и `JoystickKnob` заданы размеры — от них зависит формула центрирования.
- `ContextActionButton`, `TrunkButton`, `VehicleControlsCluster` и `LockpickQTEPanel`
  скрипт скрывает до появления контекста (посадка, багажник, взлом).
- `FireButton` использует `button_down` / `button_up`.
- `ExtractionBanner` показывает имя точки эвакуации и оставшиеся секунды удержания.
- `VehicleHPBar` появляется только когда игрок за рулём.
- HUD сам инстанцирует `inventory_modal.tscn` в `_ready()`; отдельно в сцену рейда его не добавляют.

## 3. `res://scenes/ui/inventory_modal.tscn`

```text
InventoryModal (CanvasLayer)  [inventory_modal.gd]
└── RootControl (Control)
    ├── DimBackground (ColorRect)
    └── MainPanel (PanelContainer)
        └── Margin (MarginContainer)
            └── MainVBox (VBoxContainer)
                ├── HeaderBar (HBoxContainer)
                │   ├── TitleLabel (Label)
                │   ├── SelectedInfoLabel (Label)
                │   ├── RotateButton (Button)
                │   ├── UseButton (Button)
                │   ├── EquipButton (Button)
                │   └── CloseButton (Button)
                └── ColumnsHBox (HBoxContainer)
                    ├── EquipColumn (VBoxContainer)
                    │   ├── EquipHeader (Label)
                    │   └── SlotsVBox (VBoxContainer)
                    ├── CenterColumn (VBoxContainer)
                    │   ├── PocketsLabel (Label)
                    │   ├── PocketsHolder (Control)
                    │   ├── SafeLabel (Label)
                    │   ├── SafeHolder (Control)
                    │   ├── BackpackLabel (Label)
                    │   └── BackpackScroll (ScrollContainer)
                    │       └── BackpackHolder (Control)
                    └── RightColumn (VBoxContainer)
                        ├── ExternalTitleLabel (Label)
                        └── ExternalScroll (ScrollContainer)
                            └── ExternalHolder (Control)
```

## 4. `res://scenes/zombies/zombie.tscn`

```text
Zombie (CharacterBody3D)  [zombie.gd, layer 4 / mask 7]
├── CollisionShape3D (CollisionShape3D)
├── MeshInstance3D (MeshInstance3D)
├── NavigationAgent3D (NavigationAgent3D)
├── VisionRayCast3D (RayCast3D)          [mask 3 = World + Player]
└── CorpseLootArea3D (Area3D)            [layer 8, monitoring/monitorable = false]
    └── CollisionShape3D (CollisionShape3D)
```

После смерти: `CorpseLootArea3D.monitorable = true`, тело переводится на слой 32 (Corpse),
труп становится контейнером с сеткой 4×3 и не блокирует игрока.

## 5. `res://scenes/world/extraction_zone.tscn`

```text
ExtractionZone (Area3D)  [extraction_zone.gd, layer 8 / mask 18]
├── CollisionShape3D (CollisionShape3D)  [BoxShape3D 8×4×8, Y = 2.0]
└── BeaconMesh (MeshInstance3D)          [BoxMesh 8×0.25×8 — маркер]
```

Удержание — `hold_time_sec` (0.0 = `Balance.data.extraction_hold_time_sec`, 15 с),
сирена — 4-й уровень шума (33 м). Маска 18 = Player + Vehicle.
Типы: `HELIPAD = 0`, `TRAIN_TUNNEL = 1`, `VEHICLE_CHECKPOINT = 2`.
На `VEHICLE_CHECKPOINT` сирена стартует автоматически при въезде открытой машины с водителем.

## 6. `res://scenes/vehicles/raid_vehicle.tscn`

```text
RaidVehicle (VehicleBody3D)  [raid_vehicle.gd, layer 16 / mask 23, mass 1350, COM Y = 0.35]
├── ChassisCollision (CollisionShape3D)  [BoxShape3D 2.0×1.25×4.2, Y = 0.85]
├── ChassisMesh (Node3D)
│   ├── LowerBodyMesh / HoodPanel / RoofPanel / DashboardMesh / SteeringWheelMesh
│   ├── PillarFrontLeft / PillarFrontRight / PillarRearLeft / PillarRearRight
│   ├── DoorLeft / DoorRight
│   └── RearTailgate
├── RamBumperVisual (MeshInstance3D)     [скрыт, пока не установлен отвал]
├── AlarmAudio (AudioStreamPlayer3D)     [процедурный WAV, 7 секунд]
├── WheelFL / WheelFR / WheelRL / WheelRR (VehicleWheel3D, развёрнуты по X/Z)
│   └── WheelMesh (MeshInstance3D)       [CylinderMesh — визуал колеса]
├── DriverExitMarker (Marker3D)          [позиция задаётся EXIT_LOCAL_OFFSET = (-2.4, 0.6, 0)]
├── CameraPivot (Node3D)
│   ├── FirstPersonCamera3D (Camera3D)   [fov 80, near 0.05, внутри салона]
│   └── SpringArm3D (SpringArm3D)        [длина 5.8, mask 1]
│       └── ThirdPersonCamera3D (Camera3D)
├── InteractArea3D (Area3D)              [layer 8, mask 2]
│   └── CollisionShape3D (SphereShape3D, radius 2.8)
├── TrunkArea3D (Area3D)                 [layer 8, mask 2]
│   └── CollisionShape3D (SphereShape3D, radius 2.1)
└── RamHitboxArea3D (Area3D)             [layer 0, mask 4]
    └── CollisionShape3D (BoxShape3D 2.2×1.1×0.9)
```

`center_of_mass_mode = 1` (CUSTOM) стоит **до** `center_of_mass`, иначе Godot пишет ERROR.
Сцена детализирована по фиксу ИИ (файл 58); `AlarmAudio` — наше дополнение, в партии ИИ его не было.
Колёса развёрнуты по X/Z (`Transform3D(-1,0,0, 0,1,0, 0,0,-1, ...)`), поэтому положительный
`engine_force` толкает машину вперёд по −Z. Жёсткость подвески `suspension_stiffness = 40`,
`suspension_travel = 0.2`; коллизия кузова поднята, поэтому шасси не ложится на землю.
`AlarmAudio` создаёт звук кодом в `_ready()`, потому что в проекте нет звуковых ассетов.

## 7. `res://scenes/hub/hub_scene.tscn`

```text
HubScene (Node3D)  [hub_scene.gd]
├── WorldEnvironment
├── DirectionalLight3D
├── BirdEyeCamera3D (Camera3D)
├── PanoramaBuildings (Node3D)
│   └── Building1..3 (MeshInstance3D)
├── HubUI (CanvasLayer)
│   ├── DimOverlay (ColorRect)
│   └── MainPanel (PanelContainer)
│       └── Margin (MarginContainer)
│           └── VBox (VBoxContainer)
│               ├── HeaderRow (HBoxContainer)
│               │   ├── HubTitle (Label)
│               │   ├── StatusLabel (Label)
│               │   ├── SaveButton (Button)
│               │   └── ChangeCameraButton (Button)
│               ├── NavTabsRow (HBoxContainer)
│               │   ├── TabStashBtn (Button)
│               │   ├── TabGarageBtn (Button)
│               │   ├── TabTradersBtn (Button)
│               │   └── TabContractsBtn (Button)
│               ├── PagesContainer (Control)
│               │   ├── StashPage (VBoxContainer)
│               │   │   ├── OpenStashModalButton (Button)
│               │   │   ├── WeaponModsTitle (Label)
│               │   │   └── WeaponModsVBox (VBoxContainer)  [5 слотов обвесов]
│               │   ├── GaragePage (VBoxContainer)
│               │   │   ├── GarageStatusLabel (Label)
│               │   │   ├── PartsVBox (VBoxContainer)        [6 кнопок узлов]
│               │   │   └── GarageActionsHBox (HBoxContainer)
│               │   │       ├── RepairCarButton (Button)
│               │   │       ├── OpenTrunkButton (Button)
│               │   │       └── DeployWithCarCheck (CheckButton)
│               │   ├── TradersPage (HBoxContainer)
│               │   │   ├── TraderListVBox (VBoxContainer)   [7 кнопок торговцев]
│               │   │   └── TraderContentVBox (VBoxContainer)
│               │   │       ├── TraderTitleLabel (Label)
│               │   │       ├── TraderDescLabel (Label)
│               │   │       └── CatalogScroll (ScrollContainer)
│               │   │           └── TraderItemsVBox (VBoxContainer)
│               │   └── ContractsPage (VBoxContainer)
│               │       ├── ContractsTitle (Label)
│               │       └── ContractsScroll (ScrollContainer)
│               │           └── ContractsListVBox (VBoxContainer)
│               └── DeployButton (Button)
└── PauseMenu (instance)
```

`hub_scene.gd` в `_ready()` строит 7 кнопок торговцев, 5 строк обвесов, 6 строк узлов авто
и строки контрактов; `OpenStashModalButton` открывает `inventory_modal` на `GameState.stash_grid`;
`OpenTrunkButton` — на `GameState.garage_trunk_grid`; `DeployWithCarCheck` включает спавн машины.
`StatusLabel` теперь лежит в `HeaderRow`, а не напрямую в `VBox` (путь обновлён и в `flow_test`).

## 8. `res://scenes/world/raid_world.tscn`

```text
RaidWorld (Node3D)  [raid_world.gd]
├── WorldEnvironment, DirectionalLight3D
├── NavigationRegion3D / GroundStaticBody + BlockBuilding1..2
├── Player (instance player.tscn)
├── GarageCarSpawnMarker (Marker3D)
├── WildLockedCar (instance raid_vehicle.tscn)
├── SupplyCrate1 (instance loot_container.tscn)
├── ExtractionPoints (Node3D)
│   ├── ExtractionVehicleCheckpoint (type 2)
│   ├── ExtractionHelipad (type 0)
│   └── ExtractionTrainTunnel (type 1)
├── ZombiesContainer (Node3D)
│   ├── Zombie_Road_1, Zombie_Road_2, Zombie_Checkpoint_Guard, Zombie_Road_3
├── MobileHUD (instance)
└── PauseMenu (instance)
```

Если в Хабе включён «Выехать в рейд на машине», `raid_world.gd` спавнит сохранённую машину
у `GarageCarSpawnMarker`; иначе в городе остаётся только запертая `WildLockedCar`.

## 9. `res://scenes/world/loot_container.tscn`

```text
LootContainer (StaticBody3D)  [loot_container.gd, layer 9 / mask 0]
├── CollisionShape3D (CollisionShape3D)  [BoxShape3D 1.1×0.8×0.7]
├── MeshInstance3D (MeshInstance3D)      [BoxMesh]
└── InteractArea3D (Area3D)              [layer 8]
    └── CollisionShape3D (CollisionShape3D) [SphereShape3D, radius 1.9]
```

Сетка лута по умолчанию 5×4. Пул предметов — `preset_item_ids` (2–4 предмета за генерацию).

## 10. Чего ещё нет

- Разметки опасных секторов в `raid_world` и излучения `EventBus.sector_cleared`
  (контракт «зачистить сектор» ждёт этого события).
- Всплывающего уведомления о подобранном луте в HUD.
- Отдельных сцен для торговцев/контрактов нет: весь UI Этапа 4 строится кодом внутри `hub_scene`.
