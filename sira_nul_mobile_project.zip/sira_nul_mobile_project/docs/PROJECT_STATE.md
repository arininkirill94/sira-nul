# Карточка проекта — перенос контекста в новую сессию

> Этот файл — «снимок памяти». Если чат с ассистентом обнулился или кончился лимит токенов,
> достаточно открыть новую сессию и приложить/прочитать этот файл. Всё остальное восстановится.

Дата снимка: 2026-11-11
Движок: **Godot 4.7.2 stable** (`C:\Users\user\Downloads\Godot_v4.7.2-stable_win64.exe\Godot_v4.7.2-stable_win64_console.exe`)
Платформа: **Android, landscape**, Mobile renderer, экспорт `.apk` / `.aab`
Проект: `C:\Users\user\Documents\Проект по умолчанию\ZombieLooter`
Исходный GDD: PDF «Зомби-лутер — выживание в городе» (3D extraction-looter)

---

## 1. Главное правило работы (нарушать нельзя)

**Любые изменения данных — только после явного согласия пользователя.**

К данным относятся: числа, шансы, таймеры, цены, урон, здоровье, скорости, размеры сеток,
количество слотов, длительности баффов, радиусы шума и т.п.

Правильный порядок:
1. Нашёл расхождение или спорное значение → **написать пользователю**: «здесь X, в GDD Y, менять?»
2. Дождаться ответа.
3. Только потом править.

Особо: `zombie_loot_drop_chance = 0.07` (7%) — **намеренное решение пользователя**, ИИ один раз
самовольно поменял на 16,7%, пользователь вернул 7%. **Не трогать.**

Утверждённая пользователем таблица предметов и весов зафиксирована в разделе 6.1.
Её значения (размеры, цены, стаки, веса) тоже считаются данными: менять только по согласованию.

Разрешено без согласования: исправление синтаксических ошибок (без которых код не компилируется),
создание отсутствующих файлов, настройки Input Map, технические фиксы.

---

## 2. Что за игра (сжато из GDD)

- 3D extraction-looter от третьего/первого лица в постсоветском городе.
- Рейд длится **25:00 (1500 сек)**. Успел эвакуироваться — вынес лут. Умер или истекло время — потерял всё,
  кроме защищённого страхового слота 2×2.
- Хаб: склад 12×30, гараж с машиной, 7 торговцев с репутацией, контракты.
- Лут с зомби: **7%** на обыск трупа.
- Стелс: 4 уровня шума — 0 м / 6 м / 16 м / 33 м. Выстрел без глушителя: 25% → 3-й уровень, 75% → 4-й.
  С глушителем — всегда 2-й уровень (6 м), длительность всплеска 0,5 сек.
- Травмы: кровотечение (периодический урон), перелом (запрет бега), заражение
  (кап HP сначала 60, потом падает до 25). Лечение заражения: Антидот — 120 сек, Инъектор Химика — 25 сек.
- Инъекторы-баффы 1–3 уровня: 16 / 35 / 120 сек (без неуязвимости).
- Камера выбирается **до рейда** и в рейде не меняется.

---

## 3. Структура проекта (актуальная)

```text
ZombieLooter/
├── project.godot                      # автозагрузки, Input Map, main scene, Mobile, landscape
├── autoload/
│   ├── balance.gd                     # Balance.data → default_balance.tres
│   ├── event_bus.gd                   # все сигналы игры (включая экономику и контракты)
│   ├── game_state.gd                  # Этап 4: камера, таймер, рубли, сетки, экипировка,
│   │                                  # 7 торговцев, репутация, ремонт, крафт, обвесы, квесты
│   └── save_manager.gd                # сохранение/загрузка JSON (version 4)
├── resources/
│   ├── default_balance.tres           # ЗНАЧЕНИЯ БАЛАНСА (править только с разрешения)
│   ├── defs/
│   │   ├── game_balance_data.gd       # схема баланса (все @export)
│   │   ├── item_data.gd
│   │   ├── weapon_data.gd
│   │   ├── attachment_data.gd
│   │   ├── vehicle_part_data.gd
│   │   ├── zombie_data.gd
│   │   ├── trader_data.gd
│   │   └── quest_data.gd
│   ├── items/                         # 12 утверждённых предметов + отмычка + предметы Этапа 4
│   │   ├── ammo_545.tres
│   │   ├── antidote.tres
│   │   ├── bandage.tres
│   │   ├── canned_food.tres
│   │   ├── infected_crystal.tres
│   │   ├── injector_buff.tres
│   │   ├── lockpick.tres              # Этап 3: взлом машин
│   │   ├── mutant_fingers.tres
│   │   ├── mutant_heart.tres
│   │   ├── painkiller.tres
│   │   ├── ruble_pack_small.tres
│   │   ├── splint.tres
│   │   ├── tourniquet.tres
│   │   ├── pawnshop_watch.tres         # Этап 4: редкий лут Чёрного торговца
│   │   ├── backpack_4x4.tres
│   │   ├── backpack_10x10.tres
│   │   ├── silent_boots.tres
│   │   └── vehicle_repair_kit.tres
│   ├── traders/                        # Этап 4: 7 торговцев Хаба
│   │   ├── medic.tres
│   │   ├── gunsmith.tres
│   │   ├── mechanic.tres
│   │   ├── supplier.tres
│   │   ├── chemist.tres
│   │   ├── auto_mechanic.tres
│   │   └── black_trader.tres
│   ├── weapons/                        # Этап 4: АК-74М и армейский нож
│   │   ├── ak74m.tres
│   │   └── combat_knife.tres
│   ├── attachments/                    # Этап 4: 5 слотов обвесов
│   │   ├── optic_pso1.tres
│   │   ├── muzzle_suppressor.tres
│   │   ├── mag_extended_45.tres
│   │   ├── grip_tactical.tres
│   │   └── stock_polymer.tres
│   ├── quests/                         # Этап 4: 3 контракта Чёрного торговца
│   │   ├── contract_kill_50_zombies.tres
│   │   ├── contract_clear_sector.tres
│   │   └── contract_fetch_mutant_heart.tres
│   ├── vehicle_parts/                  # Этап 3: 6 узлов тюнинга
│   │   ├── bumper_ram.tres
│   │   ├── body_armor.tres
│   │   ├── engine_stock.tres
│   │   ├── tires_stock.tres
│   │   ├── exhaust_muffler.tres
│   │   └── trunk_stock.tres
│   └── loot/
│       ├── loot_table.gd              # LootTable: веса, roll_entry() / roll_items() / roll_item()
│       └── zombie_loot.tres           # утверждённая таблица дропа (12 записей)
├── scenes/
│   ├── boot/camera_select_screen.tscn # ГЛАВНАЯ сцена: выбор 1-го/3-го лица
│   ├── hub/hub_scene.tscn             # Хаб: 4 вкладки (склад/тюнинг, Гараж, 7 торговцев, контракты)
│   ├── player/player.tscn             # Player + HealthComponent
│   ├── ui/inventory_modal.tscn        # сеточный инвентарь (инстанцируется HUD)
│   ├── ui/mobile_hud.tscn             # HUD + педали авто + QTE взлома + баннер эвакуации
│   ├── ui/pause_menu.tscn             # пауза + громкость (общая для хаба и рейда)
│   ├── vehicles/raid_vehicle.tscn     # VehicleBody3D: 4 колеса, камеры, багажник, таран
│   ├── world/extraction_zone.tscn     # зона эвакуации (3 типа)
│   ├── world/loot_container.tscn      # обыскиваемый ящик
│   ├── world/raid_world.tscn          # город: машина, 3 зоны эвакуации, 4 зомби, 2 контейнера
│   └── zombies/zombie.tscn
├── scripts/
│   ├── boot/camera_select_screen.gd
│   ├── hub/hub_scene.gd               # Этап 4: 4 вкладки, 7 торговцев, ремонт/крафт, обвесы, контракты
│   ├── inventory/inventory_grid.gd    # InventoryGrid: сетка, поворот, стаки, сериализация
│   ├── player/health_component.gd     # HP, травмы, таймеры лечения, баффы
│   ├── player/player.gd               # от ИИ (Этап 2)
│   ├── ui/inventory_modal.gd          # рюкзак / карманы / страховой слот / контейнер / склад / багажник
│   ├── ui/mobile_hud.gd               # Этап 3: QTE, педали, багажник, баннер эвакуации
│   ├── ui/pause_menu.gd               # пауза, громкость, выход в хаб
│   ├── vehicles/raid_vehicle.gd       # RaidVehicle: взлом, 6 узлов, таран, багажник, посадка
│   ├── world/extraction_zone.gd       # 3 типа эвакуации, сирена, автостарт на автовыезде
│   ├── world/loot_container.gd        # WorldLootContainer: генерация лута в сетку
│   ├── world/raid_world.gd            # спавн гаражной машины, возврат в Хаб
│   └── zombies/zombie.gd              # от ИИ (Этап 2): ИИ + труп-контейнер 4×3
├── tools/                             # служебное, в игру не входит
│   ├── flow_test.gd                   # драйвер автопрогона boot → hub → raid (97 проверок)
│   ├── flow_launcher.gd/.tscn         # точка входа прогона (запускать её)
│   ├── stage3_test.gd/.tscn           # автотест Этапа 3 (31 проверка)
│   ├── stage4_test.gd/.tscn           # автотест Этапа 4 (7 групп: торговцы, ремонт, крафт, обвесы, квесты, JSON)
│   ├── vehicle_runtime_test.gd/.tscn  # физика машины, выход, QTE, звук сигнализации (20 проверок)
│   ├── check_scenes.gd                # проверка загрузки сцен (только через --script)
│   ├── check_scenes_runner.gd/.tscn   # проверка сцен с поднятыми автозагрузками (рекомендуется)
│   ├── add_input_actions.gd           # запись Input Map в project.godot
│   └── generate_loot_items.ps1        # генерация 12 .tres предметов (PS 5.1, UTF-8 with BOM)
└── docs/
    ├── PROJECT_STATE.md               # ЭТОТ ФАЙЛ
    └── scene_structure_required.md    # дерево узлов, которого требуют скрипты
```

### Дерево узлов (жёсткие пути в скриптах, менять нельзя)

**player.tscn** — `Player` (CharacterBody3D, `class_name Player`):
`HealthComponent` (Node, `health_component.gd`), `CollisionShape3D`, `BodyMesh`,
`HeadPivot/{FirstPersonCamera, SpringArm3D/ThirdPersonCamera, AimRayCast3D, WeaponMeshHolder/WeaponMesh}`,
`InteractionArea3D/CollisionShape3D`.

**mobile_hud.tscn** — `MobileHUD` (CanvasLayer, `class_name MobileHUD`):
`RootControl/{InfectionVignette, TopLeftNoise/BarsContainer/Bar1..4 + NoiseRadiusLabel,
TopCenterTimer/PanelContainer → TimerLabel, ExtractionBanner/PanelContainer → ExtractionLabel,
TopRightCluster/{HPBar/HPValueLabel, InjuriesRow/{BleedBadge/Label, FractureBadge/Label,
InfectedBadge/Label}, BackpackButton, StatusTimersLabel, VehicleHPBar/VehicleHPLabel},
JoystickTouchZone/JoystickBase/JoystickKnob, BottomRightCluster/{CrouchButton, FireButton,
AimButton, ReloadButton, SwitchHandButton, ContextActionButton, TrunkButton, WeaponInfoLabel},
VehicleControlsCluster/{GasButton, ReverseBrakeButton, ExitVehicleButton},
LockpickQTEPanel/VBox/{Title, TrackBar/{TargetZone, CursorBar}, HitButton}}`.

HUD сам инстанцирует `scenes/ui/inventory_modal.tscn` в `_ready()`.
`VehicleControlsCluster` скрыт, пока игрок не за рулём; `LockpickQTEPanel` скрыт до взлома.
`ExtractionBanner` показывает имя точки и оставшиеся секунды удержания.

**inventory_modal.tscn** — `InventoryModal` (CanvasLayer, `class_name InventoryModal`):
`RootControl/{DimBackground, MainPanel/Margin/MainVBox/{HeaderBar/{TitleLabel, SelectedInfoLabel,
RotateButton, UseButton, EquipButton, CloseButton}, ColumnsHBox/{EquipColumn/{EquipHeader, SlotsVBox},
CenterColumn/{PocketsLabel, PocketsHolder, SafeLabel, SafeHolder, BackpackLabel,
BackpackScroll/BackpackHolder}, RightColumn/{ExternalTitleLabel, ExternalScroll/ExternalHolder}}}}`.

**zombie.tscn** — `Zombie` (CharacterBody3D, `class_name Zombie`, layer 4 / mask 7):
`CollisionShape3D`, `MeshInstance3D`, `NavigationAgent3D`, `VisionRayCast3D` (mask 3),
`CorpseLootArea3D/CollisionShape3D` (layer 8, monitoring/monitorable включаются после смерти).
После смерти тело переводится на слой **32 (Corpse)** и mask 0: труп виден `InteractionArea3D`
игрока, но не блокирует его движение.

**extraction_zone.tscn** — `ExtractionZone` (Area3D, `class_name ExtractionZone`):
`CollisionShape3D` (BoxShape3D 8×4×8, центр Y = 2.0), `BeaconMesh` (BoxMesh-маркер).
Слой `Interactable` (8), маска **18** = Player (2) + Vehicle (16).
Удержание — `hold_time_sec` (0.0 = брать `Balance.data.extraction_hold_time_sec`, 15 с),
сирена — 4-й уровень шума (`noise_radius_level_4 = 33 м`).
`extraction_type`: `HELIPAD = 0`, `TRAIN_TUNNEL = 1`, `VEHICLE_CHECKPOINT = 2`.
На автовыезде сирена стартует автоматически, когда в зону въезжает открытая машина с водителем.

**raid_vehicle.tscn** — `RaidVehicle` (VehicleBody3D, `class_name RaidVehicle`, layer **16** / mask **23**):
`ChassisCollision` (BoxShape3D 2.0×1.25×4.2, Y = 0.85), `ChassisMesh` (Node3D) с деталями кузова
(`LowerBodyMesh`, `HoodPanel`, `RoofPanel`, `DashboardMesh`, `SteeringWheelMesh`, стойки, двери,
`RearTailgate`), `RamBumperVisual` (скрыт без отвала), `AlarmAudio` (AudioStreamPlayer3D),
`WheelFL/FR/RL/RR` (по `WheelMesh`), `DriverExitMarker`, `CameraPivot/{FirstPersonCamera3D,
SpringArm3D/ThirdPersonCamera3D}`, `InteractArea3D` (layer 8, mask 2),
`TrunkArea3D` (layer 8, mask 2), `RamHitboxArea3D` (layer 0, mask 4).
Масса 1350 кг, `center_of_mass = Vector3(0, 0.35, 0)`. Маска 23 = World (1) + Player (2) + Zombie (4) + Vehicle (16).
`center_of_mass_mode = 1` (CUSTOM) обязателен перед `center_of_mass`, иначе Godot пишет ERROR.
Сцена детализирована по фиксу ИИ (файл 58); `AlarmAudio` — наше дополнение, в партии ИИ его не было.
Колёса развёрнуты по X/Z (`Transform3D(-1,0,0, 0,1,0, 0,0,-1, ...)`), поэтому знак `engine_force`
для движения вперёд — положительный.

**hub_scene.tscn** — `HubScene` (Node3D):
`WorldEnvironment`, `DirectionalLight3D`, `BirdEyeCamera3D`, `PanoramaBuildings/Building1..3`,
`HubUI/{DimOverlay, MainPanel/Margin/VBox/{HeaderRow/{HubTitle, StatusLabel, SaveButton,
ChangeCameraButton}, NavTabsRow/{TabStashBtn, TabGarageBtn, TabTradersBtn, TabContractsBtn},
PagesContainer/{StashPage/{OpenStashModalButton, WeaponModsTitle, WeaponModsVBox},
GaragePage/{GarageStatusLabel, PartsVBox, GarageActionsHBox/{RepairCarButton, OpenTrunkButton,
DeployWithCarCheck}}, TradersPage/{TraderListVBox, TraderContentVBox/{TraderTitleLabel,
TraderDescLabel, CatalogScroll/TraderItemsVBox}}, ContractsPage/{ContractsTitle,
ContractsScroll/ContractsListVBox}}, DeployButton}}`, `PauseMenu`.
7 кнопок торговцев и строки товаров/ремонта/крафта/скупки строятся кодом; `PartsVBox`
заполняется 6 кнопками узлов; `OpenTrunkButton` открывает багажник машины из Гаража.

**loot_container.tscn** — `LootContainer` (StaticBody3D, `class_name WorldLootContainer`):
`CollisionShape3D`, `MeshInstance3D`, `InteractArea3D/CollisionShape3D` (layer 8).
Сам корпус — layer 9 (World + Interactable), mask 0. Сетка лута по умолчанию 5×4.

---

## 4. Слои физики (важно, иначе лучи не попадают куда надо)

| Бит | Слой | Кто |
|---|---|---|
| 1 | World | земля, дома, стены |
| 2 | Player | игрок (`collision_layer = 2`, mask 29) |
| 3 | Enemy | зомби (`collision_layer = 4`, mask 7) |
| 4 | Interactable | трупы / контейнеры / зоны машин (`InteractArea3D`, `TrunkArea3D` — layer 8) |
| 6 | Corpse | тело убитого зомби после смерти (layer **32**) |
| 5 | Vehicle | машина (`RaidVehicle`, layer **16**, mask **23**) |

`AimRayCast3D` игрока: mask **5** = World + Enemy. `InteractionArea3D`: mask **44** = Enemy (4) + Interactable (8) + Corpse (32).
`WorldLootContainer`: корпус layer **9** (World + Interactable), `InteractArea3D` layer **8**.
`ExtractionZone` маска **18** = Player (2) + Vehicle (16), поэтому зона видит и пешего игрока, и машину.
`RamHitboxArea3D` машины: mask **4** (Enemy), слой 0.

---

## 5. Input Map (добавлено ассистентом, это настройка, не баланс)

| Действие | Клавиши |
|---|---|
| move_forward | W, ↑ |
| move_back | S, ↓ |
| move_left | A, ← |
| move_right | D, → |
| jump | Space |
| crouch | C, Ctrl |
| fire | F, ЛКМ |
| aim | Q, ПКМ |
| reload | R |
| switch_weapon | V |
| interact | E |
| open_backpack | B |
| pause | Esc |

Перезаписать заново: `tools/add_input_actions.gd` (запуск через `--script`).

---

## 6. Что готово

- [x] Проект создан, импортируется и запускается в Godot 4.7.2.
- [x] Все партии файлов от ИИ (1–35) разложены по путям из `project.godot` и `ext_resource`.
- [x] 8 Resource-классов + 4 автозагрузки работают, `default_balance.tres` грузится.
- [x] Сцены: boot, hub, player, mobile_hud, zombie, raid_world, extraction_zone,
      pause_menu, loot_container, inventory_modal.
- [x] Input Map заполнен — спам `action doesn't exist` устранён.
- [x] Этап 1 закрыт: boot → hub → raid, таймер 25:00, HUD, зомби, эвакуация 15 с с сиреной,
      возврат в Хаб.
- [x] Меню паузы `scenes/ui/pause_menu.tscn` + `scripts/ui/pause_menu.gd`:
      Esc или кнопка «II», «Продолжить», ползунок громкости (сохраняется в `user://settings.cfg`),
      «Покинуть рейд» → Хаб. Дерево реально встаёт на паузу (`PROCESS_MODE_ALWAYS`).
- [x] Утверждённая таблица дропа реализована: `resources/items/*.tres` (12 шт.),
      `resources/loot/loot_table.gd`, `resources/loot/zombie_loot.tres`.
- [x] **Этап 2 от ИИ разложен:**
      `InventoryGrid` (сетки 4×4..10×10, поворот, стаки, страховой слот, сериализация),
      `HealthComponent` (HP, кровотечение, перелом, заражение, таймеры 120/25, баффы),
      `InventoryModal` (рюкзак, карманы, страховой слот 2×2, контейнер/труп, склад 12×30),
      `WorldLootContainer` (ящики в городе), обновлённые `player.gd/.tscn`,
      `mobile_hud.gd/.tscn`, `zombie.gd`, `game_state.gd`.
- [x] В `raid_world.tscn` добавлены 2 контейнера:
      `LootContainers/LootContainer_1` (4, 0.1, 8) и `LootContainer_2` (-5, 0.1, 15).
- [x] Обыск трупа зомби открывает сетку 4×3; дроп бросается по шансу 7% и таблице из 12 записей.
- [x] **Этап 3 от ИИ разложен и проверен движком:**
      `RaidVehicle` (VehicleBody3D + 4 колеса, 6 узлов тюнинга, взлом отмычкой, QTE,
      сигнализация 33 м / 7 с, таран, багажник 6×6, посадка/выезд, камеры),
      `ExtractionZone` трёх типов, автостарт сирены на автовыезде при въезде машины с водителем,
      Гараж Хаба (6 слотов, склад, багажник, «Выехать в рейд на машине»), потеря машины
      при пешей эвакуации, сохранение состояния машины и багажника в `SaveManager`.
- [x] Автопрогон `tools/flow_launcher.tscn`: **97 проверок, 0 провалов**, 0 runtime-ERROR —
      импорт сцен, boot → hub → raid, пауза (включая восстановление режима курсора), урон через
      `HealthComponent`, обыск трупа, сетка 4×3, поворот предмета, страховой слот, машина и её зоны,
      3 точки эвакуации, эвакуация, возврат в Хаб. Значение `zombie_loot_drop_chance = 0.07`
      тест подтверждает отдельной проверкой.
- [x] Автотест `tools/stage3_test.tscn`: **31 проверка, 0 провалов**, 0 runtime-ERROR —
      баланс авто, 6 ресурсов деталей, создание машины, багажник 6×6, взлом и списание отмычки,
      сигнализация, шум выхлопа, таран с отвалом и без, сохранение в Гараж, потеря машины.
- [x] **Этап 4 от ИИ разложен и проверен движком:** 7 торговцев, репутация, покупка/продажа
      за рубли, ремонт снаряжения у Механика, крафт инъекторов у Химика, 5 слотов обвесов,
      тюнинг/ремонт 6 узлов авто, 3 контракта Чёрного торговца, JSON-сохранение **version 4**.
      Хаб перестроен в 4 вкладки; старые сохранения version 1 мигрируют (карманы не теряются).
- [x] Установленные обвесы реально влияют на рейд: глушитель синхронизируется в `player.gd`
      (выстрел = 2-й уровень шума), расширенный магазин добавляет +15 к ёмкости.
- [x] Автотест `tools/stage4_test.tscn`: **7 групп проверок, все пройдены** —
      торговцы, покупка/репутация, ремонт, крафт, обвесы, скупка редкостей/контракты, JSON.

### 6.1 Утверждённая таблица предметов (12 шт.)

| id | Название | Категория | Клетки | Цена, ₽ | Стак |
|---|---|---|---|---:|---:|
| `ruble_pack_small` | Пачка рублей (мелкая) | VALUABLE | 1×1 | 200 (при дропе 100–300) | 1 |
| `ammo_545` | Патроны 5.45 | AMMO | 1×1 | 30 | 60 |
| `canned_food` | Консервы | FOOD_WATER | 1×1 | 80 | 5 |
| `bandage` | Бинт | MEDICAL | 1×1 | 120 | 5 |
| `tourniquet` | Жгут | MEDICAL | 1×1 | 150 | 3 |
| `splint` | Шина | MEDICAL | 2×1 | 200 | 3 |
| `painkiller` | Обезболивающее | MEDICAL | 1×1 | 180 | 3 |
| `antidote` | Антидот | MEDICAL | 1×1 | 600 | 2 |
| `injector_buff` | Инъектор-бафф | INJECTOR | 1×1 | 900 | 2 |
| `mutant_heart` | Мутировавшее сердце | BIO_TROPHY | 1×1 | 3500 | 1 |
| `mutant_fingers` | Мутировавшие пальцы | BIO_TROPHY | 1×1 | 1200 | 1 |
| `infected_crystal` | Заражённый кристалл | BIO_TROPHY | 2×2 | 8000 | 1 |

**Веса внутри одного дропа** (сам шанс дропа остаётся **7%**):

| Группа | Вес | Предметы |
|---|---:|---|
| Мелочь | 70 | рубли 30, патроны 20, консервы 20 |
| Расходники | 20 | бинт 8, жгут 5, шина 4, обезболивающее 3 |
| Медицина | 8 | антидот 5, инъектор 3 |
| Редкие био-трофеи | 2 | сердце 0.8, пальцы 0.8, кристалл 0.4 |

### 6.2 Исправления после проверки пользователем (2026-11-09)

- [x] **Кнопка «Обыскать»**: у живого зомби подсказки больше нет, у убитого — появляется сразу.
      Причина была в том, что живой зомби отдавал непустую подсказку, а после смерти его
      `CollisionShape3D` отключался и цель взаимодействия сбрасывалась. Теперь труп переводится
      на отдельный слой 32, а игрок периодически (раз в 0,15 с) пересчитывает ближайшую цель
      по пересечениям `InteractionArea3D`.
- [x] **Инвентарь**: клетка увеличена с 44 до 64 px, шрифт подписи — 14 px, добавлены короткие
      имена («Рубли», «Патроны», «Сердце» и т.д.), контрастный цвет текста и обводка.
      Полные названия по-прежнему показываются в строке выбранного предмета.
- [x] **Курсор после паузы**: меню запоминает режим курсора до открытия и восстанавливает его
      при закрытии. На ПК видимый курсор больше не пропадает; если игра была в захвате мыши,
      захват возвращается.

### 6.3 Исправления Этапа 3 после проверки пользователем (2026-11-09)

- [x] **Машина не ехала.** `VehicleBody3D` после стоянки засыпал (`sleeping = true`), и
      `engine_force` игнорировался физикой. Теперь при посадке машина будится, на время
      вождения сон запрещён (`can_sleep = false`), а после выхода разрешается снова.
- [x] **Газ вёл назад.** Кузов собран передом в −Z. В сцене ИИ колёса развёрнуты по X/Z,
      поэтому положительный газ снова даёт `engine_force > 0`, а машина едет вперёд по −Z
      (проверено runtime-тестом: `dz` отрицательный).
- [x] **При выходе машину подбрасывало.** Капсула игрока включалась в тот же тик, когда ещё
      стояла в центре машины, и выталкивала кузов. Теперь позиция игрока сначала синхронизируется
      с физическим сервером, и только через один физический кадр включается коллизия.
- [x] **Шасси проваливалось в землю.** В новой сцене коллизия кузова поднята (Y = 0.85, высота 1.25),
      у колёс `suspension_stiffness = 40` и `suspension_travel = 0.2`; машина стоит на колёсах
      (origin ≈ 0.04 м над землёй), а не на кузове. Это техническая настройка сцены, не баланс.
- [x] **Сигнализация была беззвучной.** В проекте нет звуковых ассетов, поэтому
      `RaidVehicle` генерирует двухтональный WAV кодом и проигрывает его через
      `AudioStreamPlayer3D` (`AlarmAudio`) все 7 секунд. Шкала шума 4 / 33 м работала и раньше —
      теперь есть и звук.
- [x] Добавлен `tools/vehicle_runtime_test.tscn` — **20 проверок**: пробуждение, движение по −Z,
      безопасный выход, пиксельное QTE, звук и таймер сигнализации.

### 6.4 Слияние фиксов ИИ по машине (2026-11-11)

Приняты четыре фикса ИИ (файлы 57–60) и слиты с нашими доработками:

- [x] **QTE проверяется в пикселях `TrackBar`.** Раньше сравнивались нормализованные 0..1;
      теперь `cursor_center` и границы зелёной зоны берутся в пикселях, поэтому попадание
      не зависит от фактической ширины шкалы. Промах по-прежнему включает сигнализацию.
- [x] **Коллизии с игроком исключаются взаимно** (`add_collision_exception_with`) при посадке
      и высадке, плюс grace-таймер 1,2 с: исключение снимается только когда игрок отошёл
      больше чем на 2 м. Игрок высаживается слева от двери
      (`EXIT_LOCAL_OFFSET = Vector3(-2.4, 0.6, 0)`), машина ставится на ручной тормоз,
      вертикальная и угловая скорость гасятся.
- [x] **SpringArm3D не цепляется** за собственный кузов машины и за капсулу игрока.
- [x] **Новая детализированная сцена** (масса 1350 кг, mask 23): полый салон, стойки, двери,
      приборка, руль. Колёса развёрнуты по X/Z, поэтому знак `engine_force` для движения
      вперёд — положительный.
- [x] Сохранены наши фиксы: процедурная сигнализация `AlarmAudio`, пробуждение машины
      (`sleeping = false`, `can_sleep = false`), периодический поиск цели взаимодействия
      (обыск трупа), возврат управления игроку после высадки.
- [x] `vehicle_runtime_test` расширен до **20 проверок**: добавлены пиксельная ширина зелёной
      зоны и успешное QTE без сигнализации.

`car_alarm_chance = 0.5` — шанс сигнализации при взломе *без* QTE (страховочный путь для тестов).
В обычной игре HUD всегда передаёт результат QTE (0 или 1), поэтому на геймплей значение не влияет.

### 6.5 Этап 4: экономика Хаба, торговцы и контракты (2026-11-11)

Принята финальная партия ИИ (файлы 61–90). Новые числа — из партии, баланс Этапов 1–3 не менялся.

**7 торговцев** (`resources/traders/*.tres`):

| № | ID | Специализация | Особенность |
|---|---|---|---|
| 1 | `medic` | Аптечки, бинты, жгуты, шины, обезболивающее, антидот | — |
| 2 | `gunsmith` | АК-74М, нож, патроны, 5 обвесов | — |
| 3 | `mechanic` | Броня + **ремонт снаряжения/оружия за рубли** | 8 ₽ за 1% износа, минимум 25 ₽ |
| 4 | `supplier` | Рюкзаки 4×4/6×6/10×10, отмычки, фонарик, бесшумные сапоги | — |
| 5 | `chemist` | Гранаты, дым, молотов, инъекторы + **крафт инъекторов** | 4 рецепта (см. ниже) |
| 6 | `auto_mechanic` | Ремкомплект и 6 узлов авто | — |
| 7 | `black_trader` | Контракты + скупка **только редкого** лута по ×1.25 | 3 контракта |

**Экономика:** покупка даёт +2 репутации торговцу; обычная продажа — 65% цены и +1 репутация;
Чёрный торговец платит 125% и даёт +3 репутации. Репутация не может уйти ниже 0.

**Крафт Химика** (списывает ингредиент и рубли, кладёт инъектор на Склад):

| Результат | Ингредиент | Цена |
|---|---|---:|
| `injector_cure_fast` (25 с) | `antidote` | 300 ₽ |
| `injector_buff` (16 с) | `mutant_fingers` | 250 ₽ |
| `injector_buff_t2` (35 с) | `mutant_heart` | 500 ₽ |
| `injector_buff_t3` (120 с) | `infected_crystal` | 800 ₽ |

**Контракты Чёрного торговца:**

| ID | Цель | Награда |
|---|---|---:|
| `contract_kill_50_zombies` | 50 зомби за одну вылазку | 12 000 ₽, +25 реп., рюкзак 10×10 + глушитель |
| `contract_clear_sector` | зачистить опасный сектор | 8 500 ₽, +20 реп., армейский бронежилет |
| `contract_fetch_mutant_heart` | принести сердце мутанта | 9 500 ₽, +20 реп., инъектор Ур. 3 |

**Новые предметы/цены:** часы Ломбарда 4 200 ₽ (редкий лут), рюкзаки 4×4 — 900 ₽,
10×10 — 6 800 ₽, бесшумные сапоги 2 200 ₽ (5 брони), ремкомплект авто 1 200 ₽ (+100 прочности).
Оружие: АК-74М 4 500 ₽ (28 урона, 5.5 выстр./с, 60 м, магазин 30, 2.2 с перезарядка),
нож 1 100 ₽ (35 урона, 1.8 уд./с, 2.3 м). Обвесы: ПСО-1 1 900 ₽, глушитель 2 600 ₽,
магазин +15 1 500 ₽, рукоять 1 200 ₽, приклад 1 350 ₽.

---

## 7. Что не готово / открытые вопросы

- [x] **Регрессия HUD Этапа 2 закрыта:** в `mobile_hud.tscn` снова есть баннер эвакуации
      (`RootControl/ExtractionBanner` + `ExtractionLabel`), он показывает точку и оставшиеся
      секунды удержания. Осталось только всплывающее уведомление о подобранном луте.
- [ ] **Этап 3:** механики приняты и проверены; осталась ручная проверка в редакторе/на устройстве —
      физика вождения, QTE на тач-экране, посадка/выезд, багажник из Гаража, таран зомби.
- [ ] **Этап 4:** механики приняты и проверены автотестом; осталась ручная проверка UI Хаба
      (4 вкладки, 7 торговцев, ремонт, крафт, скупка, контракты) в редакторе/на устройстве.
- [ ] Зомби не стреляют (`uses_ranged_weapon` в `ZombieData` есть, логики огня нет).
- [ ] Контракт «зачистить сектор» ждёт игрового события `EventBus.sector_cleared` — в текущем
      `raid_world` сектора ещё не размечены, сигнал пока никто не излучает.
- [ ] Из настроек есть только громкость. Нет чувствительности, качества графики, языка.
- [ ] Нет экспорт-пресетов Android (`.apk`/`.aab`) и иконок.
- [ ] `NavigationRegion3D` в `raid_world` использует вручную заданный `NavigationMesh`
      (плоскость 80×80), а не запечённый из геометрии. Для больших уровней — перепекать.
- [ ] Повторно проверить в редакторе после исправлений 2026-11-09:
      кнопка «Обыскать» у живого/мёртвого зомби, читаемость клеток инвентаря,
      возврат курсора после паузы. Остальное из чек-листа: поворот предметов,
      страховой слот 2×2, обыск контейнеров, травмы и таймеры 120/25 с,
      правила смерти (теряется всё, кроме страхового слота).
- [ ] Сигнал `EventBus.loot_collected` объявлен, но сейчас никем не излучается:
      лут попадает сразу в сетку трупа/контейнера, а переносит его игрок через `InventoryModal`.

## 8. Известные технические компромиссы

1. **`selected_camera_mode: CameraMode`** — в GDScript enum-каст потребовал технического фикса;
   данные не затронуты.
2. **Зомби стреляют?** Нет. `_perform_attack` всегда ближний бой — так задумано для MVP.
3. **Труп зомби**: `rotation_degrees.x = 90` — чтобы лежал. После смерти тело переводится
   на слой **32 (Corpse)** с mask 0, поэтому не блокирует игрока, пули (`AimRayCast3D` mask 5)
   и навигацию. `CorpseLootArea3D.monitorable = true` включается после смерти,
   но основная надёжная проверка — периодический опрос пересечений в `player.gd`.
4. **`--script` режим не поднимает автозагрузки** — ошибки вида `Identifier not found: EventBus`
   в нём ложные. Проверять сцены нужно прогоном самой сцены:
   `res://tools/check_scenes_runner.tscn` (с автозагрузками) или `flow_test`.
5. **Кодировка**: все `.gd`/`.tscn`/`.tres` — UTF-8 **без BOM**. Файлы от ИИ иногда в UTF-8 with BOM
   или с двойной перекодировкой — при переносе всегда проверять первые байты.
   PowerShell 5.1 не читает UTF-8 без BOM в `.ps1` — скрипты сохранять с BOM.
6. **Тест эвакуации**: `flow_test.gd` временно ставит экземпляру зоны `hold_time_sec = 0.15`
   и вызывает `start_extraction_siren()`, чтобы не ждать 15 секунд.
   Значение в `default_balance.tres` при этом не меняется.
7. **Fallback-предметы `GameState`**: если `.tres` не найден, `game_state.gd` создаёт упрощённые
   предметы с другими ценами (патроны 12 ₽, пачка 150 ₽, сердце 2×2 и т.п.).
   Утверждённые `.tres` имеют приоритет; fallback нужен только для устойчивости загрузки.
8. **`WorldLootContainer`** генерирует лут из своего пула (`preset_item_ids`, 2–4 предмета),
   а не по утверждённой таблице зомби. Шанс 7% к контейнерам не применяется.
   Это поведение ИИ; менять данные без согласования нельзя.
9. **`GameState` хранит и старые массивы** (`pockets`, `safe_slot_items`, `backpack_items`,
   `stash_items`), и новые сетки (`pockets_grid`, `safe_grid`, `backpack_grid`, `stash_grid`).
   Источник истины — сетки; массивы синхронизируются через `_sync_backing_arrays()`.
10. **`InventoryModal` живёт внутри HUD** и подписан на `EventBus` сам. Отдельно в сцену рейда
    его добавлять не нужно.
11. **`raid_vehicle.tscn` собрана ассистентом:** в партии ИИ сцены машины не было, только скрипт
    с `@onready`-путями. Физические размеры кузова, колёс, камер и зон — наша реализация;
    менять их можно как технические настройки, но балансные числа остаются в `default_balance.tres`.
12. **`center_of_mass_mode = 1`** в `raid_vehicle.tscn` обязателен: без него присвоение
    `center_of_mass` вызывает `ERROR: Condition "center_of_mass_mode != CENTER_OF_MASS_MODE_CUSTOM"`.
13. **Автостарт сирены на автовыезде:** отдельной кнопки «Вызвать транспорт» в автомобильном HUD
    нет, поэтому `ExtractionZone` сам включает сирену, когда в `VEHICLE_CHECKPOINT` въезжает
    открытая машина с водителем. На пеших точках эвакуация по-прежнему запускается вручную.
14. **SaveManager version 4** пишет карманы/страховой слот/рюкзак/склад как сетки
    (`pockets_grid`, `safe_slot_items`, ...), а также прочность экипировки и 5 обвесов.
    Старые сохранения version 1 читаются: карманы восстанавливаются из массива ID (по 1 шт. на ячейку).
15. **`stage4_test` пишет в `user://savegame.json`** (последняя проверка — save/load).
    Перед прогоном на важном сохранении сделайте резервную копию файла.

---

## 9. Команды (PowerShell)

```powershell
$GODOT = "$env:USERPROFILE\Downloads\Godot_v4.7.2-stable_win64.exe\Godot_v4.7.2-stable_win64_console.exe"
$PROJ  = "C:\Users\user\Documents\Проект по умолчанию\ZombieLooter"

# Импорт / пересканирование проекта (ловит ошибки парсинга)
& $GODOT --headless --path $PROJ --editor --quit

# Запуск конкретной сцены на N кадров
& $GODOT --headless --path $PROJ res://scenes/world/raid_world.tscn --quit-after 60

# Полный автопрогон boot → hub → raid (код возврата 0 = всё ок, 97 проверок)
& $GODOT --headless --path $PROJ res://tools/flow_launcher.tscn

# Автотест Этапа 3: транспорт, QTE, таран, багажник, Гараж (код возврата 0, 31 проверка)
& $GODOT --headless --path $PROJ res://tools/stage3_test.tscn

# Runtime-тест машины: пробуждение, газ, выход без переворота, пиксельное QTE, звук сигнализации (20 проверок)
& $GODOT --headless --path $PROJ res://tools/vehicle_runtime_test.tscn

# Автотест Этапа 4: 7 торговцев, экономика, ремонт, крафт, обвесы, контракты, JSON (7 групп)
& $GODOT --headless --path $PROJ res://tools/stage4_test.tscn --quit-after 300

# Проверка загрузки всех 7 сцен с поднятыми автозагрузками
& $GODOT --headless --path $PROJ res://tools/check_scenes_runner.tscn

# Перезаписать Input Map
& $GODOT --headless --path $PROJ --script res://tools/add_input_actions.gd
```

Для запуска с графикой — убрать `--headless`.

---

## 10. Как продолжить в новой сессии

Вставить в новую сессию:

```text
Продолжаем разработку Godot-проекта «Зомби-лутер — выживание в городе».
Прочитай C:\Users\user\Documents\Проект по умолчанию\ZombieLooter\docs\PROJECT_STATE.md — там структура,
правила, что готово и что нет.
Главное правило: НЕ менять числа/шансы/баланс без моего явного согласия. zombie_loot_drop_chance = 0.07 не трогать.
Движок: Godot 4.7.2, путь к консольному exe указан в карточке.
Начинай с раздела «Что не готово» и предложи следующий шаг.
```

Проверка, что карточка не устарела: запустить `tools/flow_launcher.tscn`,
`tools/stage3_test.tscn`, `tools/stage4_test.tscn` и `tools/vehicle_runtime_test.tscn` —
везде должно быть `failures=0` / все группы `[OK]`.
После интеграции Этапа 4 ожидаемый результат: **97 + 31 + 20 проверок + 7 групп Этапа 4, 0 провалов**.

---

## 11. Следующие шаги (по приоритету)

1. **Ручная проверка Этапов 3–4 в редакторе/на устройстве:** вождение, QTE, сигнализация, таран,
   багажник, выезд из Гаража; 4 вкладки Хаба, 7 торговцев, ремонт, крафт, скупка, контракты.
2. **Проверка в редакторе по чек-листу пользователя:**
   инвентарь и поворот предметов, страховой слот 2×2, обыск контейнеров, травмы и таймеры 120/25 с,
   смерть (теряется всё, кроме страхового слота).
3. **Экспорт-пресеты Android** + проверка на устройстве (тач, джойстик, ориентация, `.apk`/`.aab`).
4. **Сектора и `EventBus.sector_cleared`** для контракта «зачистить опасный сектор».
5. **Огнестрельные зомби** и полировка боя.

---

## 12. Баланс Этапа 3 — что принято из партии ИИ

Значения лежат в `resources/default_balance.tres` и схеме `resources/defs/game_balance_data.gd`.
**Любое изменение — только с согласия пользователя.**

| Параметр | Значение | Комментарий |
|---|---:|---|
| `zombie_loot_drop_chance` | **0.07** | решение пользователя, в партии снова было 0.1667 — оставлено 0.07 |
| `extraction_hold_time_sec` | 15.0 | без изменений |
| `car_max_durability` | 200.0 | из партии |
| `car_alarm_chance` | **0.50** | из партии; в утверждённой таблице не было — требует подтверждения |
| `car_alarm_duration_sec` | 7.0 | из партии |
| `car_default_trunk_grid` | 6×6 | из партии |
| `car_ram_min_speed_mps` | 3.5 | из партии |
| `car_ram_zombie_damage` | 120.0 | из партии |
| `car_ram_self_damage_no_bumper` | 35.0 | из партии |
| `qte_cursor_speed` | 1.35 | из партии |
| `qte_success_zone_width` | 0.14 | из партии |
| `qte_required_hits` | 1 | из партии |

Числа Этапа 4 (цены торговцев, репутация, награды, крафт, обвесы) перечислены в разделе 6.5.
Они взяты из партии ИИ без изменения; баланс Этапов 1–3 в `default_balance.tres` не тронут.
