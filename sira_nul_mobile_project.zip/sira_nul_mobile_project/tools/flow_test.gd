extends Node
## Драйвер автопрогона: живёт в корне дерева, поэтому смены сцен его не удаляют.
## Запускается из tools/flow_launcher.tscn.

const BOOT_SCENE: String = "res://scenes/boot/camera_select_screen.tscn"
const HUB_SCENE: String = "res://scenes/hub/hub_scene.tscn"
const RAID_SCENE: String = "res://scenes/world/raid_world.tscn"
const PLAYER_SCENE: String = "res://scenes/player/player.tscn"
const HUD_SCENE: String = "res://scenes/ui/mobile_hud.tscn"
const ZOMBIE_SCENE: String = "res://scenes/zombies/zombie.tscn"
const EXTRACTION_ZONE_SCENE: String = "res://scenes/world/extraction_zone.tscn"
const VEHICLE_SCENE: String = "res://scenes/vehicles/raid_vehicle.tscn"

const ITEM_PRICES: Dictionary = {
	"ruble_pack_small": 200,
	"ammo_545": 30,
	"canned_food": 80,
	"bandage": 120,
	"tourniquet": 150,
	"splint": 200,
	"painkiller": 180,
	"antidote": 600,
	"injector_buff": 900,
	"mutant_heart": 3500,
	"mutant_fingers": 1200,
	"infected_crystal": 8000,
	"lockpick": 350,
}

const WATCHDOG_SEC: float = 30.0

var failures: int = 0
var finished: bool = false


func _ready() -> void:
	_run_watchdog()
	await _run()


func _run_watchdog() -> void:
	await get_tree().create_timer(WATCHDOG_SEC).timeout
	if finished:
		return
	print("FAIL  watchdog: прогон не завершился за ", WATCHDOG_SEC, " сек")
	get_tree().quit(2)


func _run() -> void:
	print("=== FLOW TEST START ===")

	_check_balance()
	_check_items()
	_check_inventory()
	_check_scene_instantiation()

	await _goto(BOOT_SCENE)
	var boot: Node = get_tree().current_scene
	_check(boot != null and boot.has_method("_on_first_person_selected"), "boot: скрипт загружен")
	if boot != null and boot.has_method("_on_first_person_selected"):
		boot.call("_on_first_person_selected")
		await _wait_frames(4)
		_check(get_tree().current_scene != null
			and get_tree().current_scene.scene_file_path == HUB_SCENE, "boot -> hub переход")

	var hub: Node = get_tree().current_scene
	_check(hub != null and hub.get_script() != null, "hub: скрипт загружен")
	if hub == null:
		_finish()
		return

	var status: Label = hub.get_node_or_null("HubUI/MainPanel/Margin/VBox/HeaderRow/StatusLabel") as Label
	if status == null:
		status = hub.get_node_or_null("HubUI/MainPanel/Margin/VBox/StatusLabel") as Label
	_check(status != null and (status.text.contains("Рубли") or status.text.contains("Баланс")),
		"hub: статус заполнен")
	_check(status != null and status.text.to_lower().contains("камера"),
		"hub: статус показывает режим камеры")
	_check(hub.has_method("_on_change_cam_pressed"),
		"hub: кнопка смены камеры подключена")

	var before_mode: int = GameState.selected_camera_mode
	var next_mode: int = GameState.CameraMode.FIRST_PERSON
	if before_mode == GameState.CameraMode.FIRST_PERSON:
		next_mode = GameState.CameraMode.THIRD_PERSON
	GameState.set_camera_mode_before_raid(next_mode)
	_check(GameState.selected_camera_mode == next_mode, "GameState: смена режима камеры")
	GameState.selected_camera_mode = before_mode

	if hub.has_method("_on_deploy_pressed"):
		hub.call("_on_deploy_pressed")
		await _wait_frames(4)

	_check(get_tree().current_scene != null
		and get_tree().current_scene.scene_file_path == RAID_SCENE, "hub -> raid переход")

	var raid: Node = get_tree().current_scene
	if raid == null:
		_finish()
		return

	await _wait_frames(3)

	var player: Node = raid.get_node_or_null("Player")
	var hud: Node = raid.get_node_or_null("MobileHUD")
	var zombies: Node = raid.get_node_or_null("ZombiesContainer")
	var pause_menu: Node = raid.get_node_or_null("PauseMenu")
	_check(player != null, "raid: игрок на сцене")
	_check(hud != null, "raid: HUD на сцене")
	_check(zombies != null and zombies.get_child_count() == 4, "raid: 4 зомби на сцене")
	_check(pause_menu != null, "raid: меню паузы на сцене")
	_check(GameState.is_in_raid, "raid: рейд активен")
	_check(GameState.raid_time_left_sec <= Balance.data.raid_duration_sec
		and GameState.raid_time_left_sec > Balance.data.raid_duration_sec - 5.0,
		"raid: таймер отсчитывается от длительности из баланса")

	if pause_menu != null:
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
		pause_menu.call("open_menu")
		_check(get_tree().paused, "pause: игра ставится на паузу")
		_check(bool(pause_menu.get("is_paused")), "pause: состояние меню активно")
		_check(int(pause_menu.get("mouse_mode_before_pause")) == int(Input.MOUSE_MODE_VISIBLE),
			"pause: запоминает режим курсора")
		pause_menu.call("close_menu")
		_check(not get_tree().paused, "pause: игра снимается с паузы")

	if zombies != null and zombies.get_child_count() > 0:
		var zombie: Node = zombies.get_child(0)
		_check(zombie.has_method("apply_damage"), "zombie: apply_damage есть")
		_check(zombie.has_method("get_interaction_prompt"), "zombie: обыск трупа есть")
		_check(str(zombie.call("get_interaction_prompt")) == "",
			"zombie: у живого нет кнопки обыска")
		var corpse_grid: InventoryGrid = zombie.call("get_loot_grid") as InventoryGrid
		_check(corpse_grid != null, "zombie: сетка трупа 4x3")
		var player_pos: Vector3 = player.global_position if player != null else Vector3.ZERO
		if player != null:
			zombie.global_position = player.global_position + Vector3(1.0, 0.0, 0.0)
			for i in range(3):
				await get_tree().physics_frame
		zombie.call("apply_damage", 99999.0, player_pos)
		for i in range(3):
			await get_tree().physics_frame
		_check(int(zombie.get("state")) == 4, "zombie: смерть обрабатывается")
		_check(str(zombie.call("get_interaction_prompt")) == "ОБЫСКАТЬ ТРУП", "zombie: труп можно обыскать")
		_check(int(zombie.get("collision_layer")) == 32,
			"zombie: труп на отдельном слое (не блокирует игрока)")
		if player != null:
			player.set("interaction_refresh_timer", 0.0)
			player.call("_update_interaction_target", 1.0)
			_check(player.get("current_interact_target") == zombie,
				"player: убитый зомби становится целью взаимодействия")
		var opened: Dictionary = {"count": 0}
		EventBus.request_open_loot_container.connect(func(_node: Node) -> void:
			opened["count"] = int(opened["count"]) + 1)
		zombie.call("interact", player)
		_check(int(opened["count"]) == 1, "zombie: обыск открывает контейнер")

	if player != null:
		_check(player.has_method("perform_attack"), "player: атака доступна")
		var health: Node = player.get_node_or_null("HealthComponent")
		_check(health != null, "player: HealthComponent на сцене")
		if health != null:
			var hp_before: float = float(health.get("current_hp"))
			player.call("receive_attack_damage", 10.0, false, false, false)
			_check(float(health.get("current_hp")) < hp_before, "player: получает урон")

	var vehicle: Node = raid.get_node_or_null("WildLockedCar")
	_check(vehicle != null and vehicle is RaidVehicle, "raid: запертая машина на сцене")
	if vehicle != null:
		_check(bool(vehicle.get("is_locked")), "raid: городская машина заперта")
		_check(vehicle.get_node_or_null("TrunkArea3D") != null,
			"raid: у машины есть зона багажника")
		_check(vehicle.get_node_or_null("RamHitboxArea3D") != null,
			"raid: у машины есть зона тарана")

	var zone: Node = raid.get_node_or_null("ExtractionPoints/ExtractionVehicleCheckpoint")
	if zone == null:
		zone = raid.get_node_or_null("ExtractionZones/Evac_Point")
	_check(zone != null, "raid: зона эвакуации на сцене")
	if zone != null:
		_check(is_equal_approx(float(zone.call("get_effective_hold_time")),
			Balance.data.extraction_hold_time_sec),
			"raid: время удержания эвакуации взято из баланса")
		_check(int(zone.get("extraction_type")) == 2,
			"raid: автовыезд помечен как VEHICLE_CHECKPOINT")

		# Ускоряем удержание только на время теста, значение баланса не меняется.
		zone.set("hold_time_sec", 0.15)
		zone.set("player_inside", true)
		zone.call("start_extraction_siren")
		await _wait_frames(2)
		await get_tree().create_timer(0.6).timeout
		_check(not GameState.is_in_raid, "raid: эвакуация завершает рейд")
		await _wait_frames(4)
		_check(get_tree().current_scene != null
			and get_tree().current_scene.scene_file_path == HUB_SCENE,
			"raid -> hub после успешной эвакуации")

	_finish()


func _finish() -> void:
	finished = true
	print("=== FLOW TEST RESULT: failures=", failures, " ===")
	get_tree().quit(1 if failures > 0 else 0)


func _check_balance() -> void:
	_check(Balance.data != null, "Balance: ресурс загружен")
	_check(GameState.rubles == 2500, "GameState: стартовый баланс 2500")
	_check(Balance.data.raid_duration_sec == 1500.0, "Balance: рейд 1500 сек")
	_check(is_equal_approx(Balance.data.zombie_loot_drop_chance, 0.07),
		"Balance: шанс лута 7% (значение пользователя не тронуто)")
	_check(is_equal_approx(Balance.data.extraction_hold_time_sec, 15.0),
		"Balance: удержание эвакуации 15 сек")
	_check(is_equal_approx(Balance.data.car_max_durability, 200.0),
		"Balance: прочность авто 200")
	_check(is_equal_approx(Balance.data.car_alarm_duration_sec, 7.0),
		"Balance: сигнализация авто 7 сек")
	_check(is_equal_approx(Balance.data.car_ram_self_damage_no_bumper, 35.0),
		"Balance: урон тарана без отвала 35")
	_check(Balance.data.car_default_trunk_grid == Vector2i(6, 6),
		"Balance: багажник 6x6")


func _check_items() -> void:
	for item_id in ITEM_PRICES.keys():
		var path: String = "res://resources/items/%s.tres" % item_id
		var item: ItemData = load(path) as ItemData
		_check(item != null and item.base_price_rubles == int(ITEM_PRICES[item_id]),
			"item: %s = %d руб." % [item_id, int(ITEM_PRICES[item_id])])

	var splint: ItemData = load("res://resources/items/splint.tres") as ItemData
	_check(splint != null and splint.grid_size == Vector2i(2, 1), "item: шина 2x1")
	var crystal: ItemData = load("res://resources/items/infected_crystal.tres") as ItemData
	_check(crystal != null and crystal.grid_size == Vector2i(2, 2), "item: кристалл 2x2")

	for part_id in ["bumper_ram", "body_armor", "engine_stock",
			"tires_stock", "exhaust_muffler", "trunk_stock"]:
		var part: VehiclePartData = load("res://resources/vehicle_parts/%s.tres" % part_id) as VehiclePartData
		_check(part != null and part is VehiclePartData,
			"part: %s загружается" % part_id)

	var table: LootTable = load("res://resources/loot/zombie_loot.tres") as LootTable
	_check(table != null and table.entries.size() == 12, "loot: таблица из 12 записей")
	if table == null:
		return

	var entry: Dictionary = table.roll_entry()
	_check(not entry.is_empty(), "loot: запись выбирается по весам")
	var loot_item: ItemData = load(str(entry.get("item", ""))) as ItemData
	_check(loot_item != null, "loot: предмет из записи загружается")
	if loot_item != null:
		_check(table.resolve_value(entry, loot_item) > 0, "loot: стоимость вычисляется")


func _check_inventory() -> void:
	_check(GameState.item_database.size() >= 12, "GameState: база предметов загружена")
	_check(GameState.safe_grid != null and GameState.safe_grid.get_items().size() >= 2,
		"inventory: страховой слот 2x2 заполнен стартовым набором")
	_check(GameState.backpack_grid != null and GameState.backpack_grid.get_items().size() > 0,
		"inventory: рюкзак стартового набора")
	_check(GameState.pockets_grid != null and GameState.pockets_grid.get_items().size() > 0,
		"inventory: карманы стартового набора")
	_check(GameState.garage_trunk_grid != null
		and GameState.garage_trunk_grid.width == 6
		and GameState.garage_trunk_grid.height == 6,
		"inventory: сетка багажника 6x6 создана")
	_check(GameState.count_any_item("lockpick") >= 1,
		"inventory: стартовые отмычки есть")
	_check(GameState.get_vehicle_part_data("bumper_ram") != null,
		"inventory: детали тюнинга зарегистрированы")

	var grid := InventoryGrid.new(4, 4)
	var splint: ItemData = load("res://resources/items/splint.tres") as ItemData
	_check(grid.add_item_auto(splint, 1), "inventory: предмет кладётся в сетку")
	var items: Array[Dictionary] = grid.get_items()
	_check(items.size() == 1, "inventory: предмет учтён в сетке")
	if items.is_empty():
		return

	var uid: int = int(items[0].get("uid", -1))
	_check(grid.rotate_item_in_place(uid), "inventory: поворот на 90°")
	var rotated_item: Dictionary = grid.get_item_by_uid(uid)
	_check(bool(rotated_item.get("rotated", false)), "inventory: флаг поворота выставлен")

	var modal_script: GDScript = load("res://scripts/ui/inventory_modal.gd") as GDScript
	if modal_script != null:
		var constants: Dictionary = modal_script.get_script_constant_map()
		_check(int(constants.get("CELL_PIXELS", 0)) == 64,
			"inventory: клетка 64 px (увеличенный читаемый размер)")
		var labels: Dictionary = constants.get("ITEM_SHORT_LABELS", {})
		_check(labels.size() >= 12, "inventory: короткие подписи для всех предметов")


func _check_scene_instantiation() -> void:
	for path in [PLAYER_SCENE, HUD_SCENE, ZOMBIE_SCENE, EXTRACTION_ZONE_SCENE, VEHICLE_SCENE]:
		var packed: PackedScene = load(path) as PackedScene
		_check(packed != null, "загрузка " + path)
		if packed == null:
			continue
		var instance: Node = packed.instantiate()
		_check(instance != null, "инстанцирование " + path)
		if instance != null:
			instance.free()


func _goto(path: String) -> void:
	var error: int = get_tree().change_scene_to_file(path)
	_check(error == OK, "переход на " + path)
	await _wait_frames(4)


func _wait_frames(count: int) -> void:
	for i in range(count):
		await get_tree().process_frame


func _check(condition: bool, message: String) -> void:
	if condition:
		print("OK    ", message)
	else:
		failures += 1
		print("FAIL  ", message)
