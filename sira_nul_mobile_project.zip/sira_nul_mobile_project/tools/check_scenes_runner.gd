extends Node
## Диагностика сцен с загруженными автозагрузками (Balance/EventBus/GameState/SaveManager).
## Запуск: godot --headless --path . res://tools/check_scenes_runner.tscn

const SCENE_PATHS: Array[String] = [
	"res://scenes/boot/camera_select_screen.tscn",
	"res://scenes/hub/hub_scene.tscn",
	"res://scenes/player/player.tscn",
	"res://scenes/ui/mobile_hud.tscn",
	"res://scenes/vehicles/raid_vehicle.tscn",
	"res://scenes/zombies/zombie.tscn",
	"res://scenes/world/raid_world.tscn",
]


func _ready() -> void:
	var failed: int = 0
	for path in SCENE_PATHS:
		var packed: PackedScene = load(path) as PackedScene
		if packed == null:
			print("FAIL  ", path)
			failed += 1
			continue
		var instance: Node = packed.instantiate()
		if instance == null:
			print("FAIL  instantiate ", path)
			failed += 1
			continue
		print("OK    ", path, "  root=", instance.name)
		instance.free()
	print("RESULT: failed=", failed, " of ", SCENE_PATHS.size())
	get_tree().quit(1 if failed > 0 else 0)
