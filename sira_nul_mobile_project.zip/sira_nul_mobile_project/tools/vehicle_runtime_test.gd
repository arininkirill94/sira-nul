extends Node
## Runtime-тест машины: пробуждение после стоянки, движение по газу,
## безопасный выход без подбрасывания кузова и звуковая сигнализация QTE.
## Запускается из tools/vehicle_runtime_test.tscn.

const RAID_SCENE: String = "res://scenes/world/raid_world.tscn"
const VEHICLE_SCENE: String = "res://scenes/vehicles/raid_vehicle.tscn"

var failures: int = 0


func _ready() -> void:
	call_deferred("_run")


func _run() -> void:
	print("=== VEHICLE RUNTIME TEST START ===")
	var raid: Node3D = load(RAID_SCENE).instantiate() as Node3D
	add_child(raid)
	await _wait(1.5)

	# Убираем зомби, чтобы они не убили игрока во время теста.
	var zombies: Node = raid.get_node_or_null("ZombiesContainer")
	if zombies != null:
		zombies.queue_free()
		await get_tree().physics_frame

	var car: RaidVehicle = raid.get_node_or_null("WildLockedCar") as RaidVehicle
	var player: Player = raid.get_node_or_null("Player") as Player
	var hud: MobileHUD = raid.get_node_or_null("MobileHUD") as MobileHUD
	_check(car != null and player != null and hud != null, "runtime: город, игрок и HUD созданы")
	if car == null or player == null or hud == null:
		_finish()
		return

	_check(car.global_position.y > 0.0,
		"physics: шасси не провалилось в землю (y=%.3f)" % car.global_position.y)
	_check(car.alarm_audio != null and car.alarm_audio.stream != null,
		"alarm: процедурный звук сигнализации создан")

	# 1. Посадка будит машину и разрешает сон только после выхода.
	car.is_locked = false
	var entered: bool = car.enter_vehicle(player)
	_check(entered, "drive: игрок садится в машину")
	_check(car.sleeping == false, "drive: после посадки машина не спит")
	_check(car.can_sleep == false, "drive: пока водитель внутри, сон запрещён")

	# 2. Газ действительно двигает машину вперёд (-Z).
	var start_pos: Vector3 = car.global_position
	car.hud_throttle_input = 1.0
	await _wait(1.5)
	var moved: Vector3 = car.global_position - start_pos
	_check(car.linear_velocity.length() > 1.0,
		"drive: газ разгоняет машину (speed=%.2f м/с)" % car.linear_velocity.length())
	_check(moved.z < -1.0, "drive: машина едет вперёд по -Z (dz=%.2f)" % moved.z)
	car.hud_throttle_input = 0.0

	# 3. Тормоз почти останавливает машину, выход не подбрасывает кузов.
	car.hud_brake_input = 1.0
	await _wait(1.0)
	car.hud_brake_input = 0.0
	await _wait(0.3)
	var pos_before: Vector3 = car.global_position
	var rot_before: Vector3 = car.global_rotation
	car.exit_vehicle()
	await _wait(0.8)
	var pos_delta: Vector3 = car.global_position - pos_before
	var rot_delta: Vector3 = car.global_rotation - rot_before
	_check(pos_delta.length() < 1.0,
		"exit: машина не отлетает после выхода (delta=%.2f м)" % pos_delta.length())
	_check(absf(rot_delta.x) + absf(rot_delta.y) + absf(rot_delta.z) < 0.35,
		"exit: машина не переворачивается после выхода")
	_check(player.visible and player.collision_shape.disabled == false,
		"exit: игрок снова видим и его коллизия включена")

	# 4. Промах QTE включает сигнализацию 4/33 м на 7 секунд и звук.
	var car2: RaidVehicle = load(VEHICLE_SCENE).instantiate() as RaidVehicle
	raid.add_child(car2)
	car2.global_position = Vector3(0, 0.3, -5)
	await _wait(0.4)
	EventBus.request_start_lockpick_qte.emit(car2)
	await get_tree().process_frame
	_check(hud.qte_active, "qte: панель взлома открылась")
	# Промах: курсор слева, зелёная зона всегда правее 25% шкалы.
	hud.qte_cursor_norm = 0.0
	hud.qte_cursor.position.x = 0.0
	hud._evaluate_qte_hit()
	await _wait(0.2)
	_check(car2.is_locked == false, "qte: промах всё равно открывает замок")
	_check(car2.alarm_timer > 6.0, "alarm: таймер сигнализации около 7 секунд")
	_check(car2.alarm_audio.playing, "alarm: звук сигнализации играет")
	_check(hud.noise_label.text.contains("4") and hud.noise_label.text.contains("33"),
		"alarm: HUD показывает 4-й уровень шума (33 м)")
	car2.alarm_timer = 0.05
	await _wait(0.2)
	_check(not car2.alarm_audio.playing, "alarm: звук останавливается по истечении таймера")

	# 5. Попадание в зелёную зону QTE: тихое открытие без сигнализации.
	var car3: RaidVehicle = load(VEHICLE_SCENE).instantiate() as RaidVehicle
	raid.add_child(car3)
	car3.global_position = Vector3(0, 0.3, -9)
	await _wait(0.4)
	EventBus.request_start_lockpick_qte.emit(car3)
	await get_tree().process_frame
	_check(hud.qte_target_zone.size.x > 0.0, "qte: зелёная зона имеет ширину в пикселях")
	var hit_x: float = (
		hud.qte_target_zone.position.x
		+ hud.qte_target_zone.size.x * 0.5
		- hud.qte_cursor.size.x * 0.5
	)
	hud.qte_cursor.position.x = hit_x
	hud._evaluate_qte_hit()
	await _wait(0.2)
	_check(car3.is_locked == false, "qte: попадание открывает замок")
	_check(car3.alarm_timer <= 0.0 and not car3.alarm_audio.playing,
		"qte: успех без сигнализации")

	_finish()


func _wait(seconds: float) -> void:
	var end: int = Time.get_ticks_msec() + int(seconds * 1000.0)
	while Time.get_ticks_msec() < end:
		await get_tree().physics_frame


func _check(condition: bool, message: String) -> void:
	if condition:
		print("OK    ", message)
	else:
		failures += 1
		print("FAIL  ", message)


func _finish() -> void:
	print("=== VEHICLE RUNTIME TEST RESULT: failures=", failures, " ===")
	get_tree().quit(1 if failures > 0 else 0)
