extends Node
## Полный автотест Этапа 4: проверяет всех 7 торговцев, покупку/продажу за рубли,
## прокачку репутации, ремонт у Механика, крафт инъекторов у Химика,
## 5 слотов обвесов оружия, тюнинг/ремонт авто, контракты Чёрного торговца и JSON-сохранение.


func _ready() -> void:
	run_stage4_checks()


func run_stage4_checks() -> void:
	print("=== ЗАПУСК АВТОТЕСТА ЭТАПА 4 (ЭКОНОМИКА ХАБА, 7 ТОРГОВЦЕВ, КОНТРАКТЫ, JSON) ===")

	# 1. Проверка загрузки всех 7 торговцев
	var expected_traders: Array[String] = [
		"medic", "gunsmith", "mechanic", "supplier", "chemist", "auto_mechanic", "black_trader"
	]
	for t_id in expected_traders:
		assert(GameState.get_trader_data(t_id) != null, "Торговец должен существовать: " + t_id)
	print("[OK] Все 7 торговцев Хаба загружены.")

	# 2. Проверка покупки у Медика за рубли и роста репутации
	GameState.rubles = 10000
	var rep_before: int = GameState.get_trader_reputation("medic")
	var bought_ok: bool = GameState.buy_item_from_trader("medic", "antidote")
	assert(bought_ok == true, "Покупка антидота у Медика должна пройти успешно")
	assert(GameState.get_trader_reputation("medic") > rep_before, "Репутация у Медика должна вырасти")
	print("[OK] Покупка за рубли и начисление репутации работают.")

	# 3. Проверка ремонта изношенного оружия у Механика
	GameState.equipped_items["primary_weapon"] = "ak74m"
	GameState.equipped_durability["primary_weapon"] = 60.0
	var repair_cost: int = GameState.get_slot_repair_cost("primary_weapon")
	assert(repair_cost > 0, "Стоимость ремонта изношенного оружия должна быть > 0")
	var repaired_ok: bool = GameState.repair_equipped_slot_at_mechanic("primary_weapon")
	assert(repaired_ok == true and is_equal_approx(GameState.equipped_durability["primary_weapon"], 100.0), "Оружие должно починиться до 100%")
	print("[OK] Ремонт снаряжения у Механика за рубли работает.")

	# 4. Проверка крафта инъектора у Химика из био-образцов
	GameState.stash_grid.add_item_auto(GameState.get_item_data("mutant_fingers"), 1)
	var crafted_ok: bool = GameState.craft_injector_at_chemist(1) # Уровень 1 (16 сек) из mutant_fingers
	assert(crafted_ok == true, "Крафт инъектора 1-го уровня у Химика должен пройти успешно")
	print("[OK] Создание инъекторов у Химика из био-трофеев работает.")

	# 5. Проверка установки глушителя (слот модификации оружия)
	GameState.stash_grid.add_item_auto(GameState.get_item_data("muzzle_suppressor"), 1)
	var mod_ok: bool = GameState.install_weapon_attachment("muzzle_suppressor")
	assert(mod_ok == true and GameState.has_weapon_suppressor_installed() == true, "Глушитель должен установиться на оружие")
	print("[OK] Поузловой тюнинг огнестрельного оружия (5 слотов обвесов) работает.")

	# 6. Проверка скупки редкостей из Ломбарда и контракта у Чёрного торговца
	var watch_uid: int = GameState.stash_grid.place_item(GameState.get_item_data("pawnshop_watch"), Vector2i(0, 20), false, 1)
	if watch_uid != -1:
		var rubles_pre_sell: int = GameState.rubles
		var sold_ok: bool = GameState.sell_item_to_trader("black_trader", GameState.stash_grid, watch_uid)
		assert(sold_ok == true and GameState.rubles > rubles_pre_sell, "Чёрный торговец должен скупать редкие часы из Ломбарда")

	GameState.accept_quest("contract_fetch_mutant_heart")
	GameState.stash_grid.add_item_auto(GameState.get_item_data("mutant_heart"), 1)
	assert(GameState.is_quest_ready_to_claim("contract_fetch_mutant_heart") == true, "Контракт на сердце мутанта должен быть готов к сдаче")
	var claimed_ok: bool = GameState.claim_quest_reward("contract_fetch_mutant_heart")
	assert(claimed_ok == true, "Сдача контракта Чёрному торговцу должна выдать рубли, репутацию и награду")
	print("[OK] Скупка редкостей и контракты Чёрного торговца работают.")

	# 7. Проверка сохранения и загрузки JSON (SaveManager)
	var saved_rubles: int = GameState.rubles
	assert(SaveManager.save_game() == true, "SaveManager.save_game() должен вернуть true")
	GameState.rubles = 0
	assert(SaveManager.load_game() == true, "SaveManager.load_game() должен вернуть true")
	assert(GameState.rubles == saved_rubles, "Баланс рублей должен восстановиться из user://savegame.json")
	print("[OK] Сохранение и загрузка прогресса в user://savegame.json работают.")

	print("=== ВСЕ ПРОВЕРКИ ЭТАПА 4 УСПЕШНО ПРОЙДЕНЫ! ПРОТОТИП ГОТОВ! ===")