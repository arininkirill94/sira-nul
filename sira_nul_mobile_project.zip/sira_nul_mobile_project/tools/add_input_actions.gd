extends SceneTree
## Добавляет действия Input Map, которые требует player.gd.
## Запуск: godot --headless --path . --script res://tools/add_input_actions.gd


func _init() -> void:
	var actions: Dictionary = {
		"move_forward": [KEY_W, KEY_UP],
		"move_back": [KEY_S, KEY_DOWN],
		"move_left": [KEY_A, KEY_LEFT],
		"move_right": [KEY_D, KEY_RIGHT],
		"jump": [KEY_SPACE],
		"crouch": [KEY_C, KEY_CTRL],
		"reload": [KEY_R],
		"switch_weapon": [KEY_V],
		"interact": [KEY_E],
		"open_backpack": [KEY_B],
		"pause": [KEY_ESCAPE],
		"fire": [KEY_F],
		"aim": [KEY_Q],
	}

	for action_name in actions.keys():
		var events: Array = []
		for key in actions[action_name]:
			var key_event := InputEventKey.new()
			key_event.physical_keycode = key
			events.append(key_event)
		ProjectSettings.set_setting("input/" + action_name, {
			"deadzone": 0.2,
			"events": events,
		})

	# Огонь и прицел дополнительно на мышь (для отладки на ПК).
	var fire_mouse := InputEventMouseButton.new()
	fire_mouse.button_index = MOUSE_BUTTON_LEFT
	_add_mouse_to_action("fire", fire_mouse)

	var aim_mouse := InputEventMouseButton.new()
	aim_mouse.button_index = MOUSE_BUTTON_RIGHT
	_add_mouse_to_action("aim", aim_mouse)

	ProjectSettings.save()
	print("Input actions written")
	quit()


func _add_mouse_to_action(action_name: String, mouse_event: InputEventMouseButton) -> void:
	var current: Dictionary = ProjectSettings.get_setting("input/" + action_name, {})
	var events: Array = current.get("events", [])
	events.append(mouse_event)
	current["events"] = events
	ProjectSettings.set_setting("input/" + action_name, current)
