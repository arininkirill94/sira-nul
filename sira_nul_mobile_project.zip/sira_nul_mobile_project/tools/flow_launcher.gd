extends Node
## Точка входа автопрогона: создаёт драйвер в корне дерева и сразу снимает себя со сцены,
## чтобы последующие change_scene не убили тест.

const DRIVER_SCRIPT: String = "res://tools/flow_test.gd"


func _ready() -> void:
	var driver := Node.new()
	driver.name = "FlowDriver"
	driver.set_script(load(DRIVER_SCRIPT))
	get_tree().root.add_child.call_deferred(driver)
