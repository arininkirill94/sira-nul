extends Node
## Автотест механик Этапа 3: взлом отмычкой, сигнализация 33 м, 6 узлов авто,
## таран с бампером и без, багажник, сирена эвакуации, сохранение машины в Гараж
## и безвозвратная потеря машины при пешей эвакуации.
## Запускается из tools/stage3_test.tscn.

const VEHICLE_SCENE: String = "res://scenes/vehicles/raid_vehicle.tscn"
const PART_IDS: Array[String] = [
	"bumper_ram", "body_armor", "engine_stock",
	"tires_stock", "exhaust_muffler", "trunk_stock",
]

var failures: int = 0


func _ready() -> void:
	call_deferred("_run")


func _run() -> void:
	await run_stage3_checks()
	print("=== STAGE 3 TEST RESULT: failures=", failures, " ===")
	get_tree().quit(1 if failures > 0 else 0)


func run_stage3_checks() -> void:
	print("=== ЗАПУСК АВТОТЕСТА ЭТАПА 3 (ТРАНСПОРТ, ЭВАКУАЦИЯ, ГАРАЖ) ===")

	_check(is_equal_approx(Balance.data.zombie_loot_drop_chance, 0.07),
		"balance: шанс лута с зомби остался 7%")
	_check(is_equal_approx(Balance.data.car_max_durability, 200.0),
		"balance: прочность авто 200")
	_check(is_equal_approx(Balance.data.car_ram_self_damage_no_bumper, 35.0),
		"balance: урон тарана без отвала 35")
	_check(Balance.data.car_default_trunk_grid == Vector2i(6, 6),
		"balance: багажник 6x6")

	for part_id in PART_IDS:
		var part: VehiclePartData = GameState.get_vehicle_part_data(part_id)
		_check(part != null and part is VehiclePartData,
			"part: %s загружена как VehiclePartData" % part_id)

	var car_scene: PackedScene = load(VEHICLE_SCENE) as PackedScene
	_check(car_scene != null, "vehicle: сцена raid_vehicle.tscn загружается")
	if car_scene == null:
		return

	var car: RaidVehicle = car_scene.instantiate() as RaidVehicle
	_check(car != null, "vehicle: сцена создаёт RaidVehicle")
	if car == null:
		return
	add_child(car)
	await get_tree().process_frame

	_check(car.trunk_grid != null and car.trunk_grid.width == 6 and car.trunk_grid.height == 6,
		"vehicle: багажник 6x6 создан")
	_check(car.installed_parts.size() == 6, "vehicle: 6 слотов тюнинга")
	_check(is_equal_approx(car.max_durability, 200.0), "vehicle: прочность 200")
	_check(car.current_durability == car.max_durability, "vehicle: старт с полной прочностью")

	# 1. Взлом замка отмычкой и сигнализация 33 м / 7 сек
	var lockpicks_before: int = GameState.count_any_item("lockpick")
	_check(car.is_locked, "lockpick: дикая машина заперта по умолчанию")
	var unlocked_ok: bool = car.attempt_lockpick(1)
	_check(unlocked_ok and not car.is_locked, "lockpick: машина открывается отмычкой")
	_check(GameState.count_any_item("lockpick") == lockpicks_before - 1,
		"lockpick: списана ровно 1 отмычка")
	_check(is_equal_approx(car.alarm_timer, Balance.data.car_alarm_duration_sec),
		"alarm: сигнализация включена на 7 сек (33 м)")

	# 2. Шум при езде: сток 4 палочки, тихий глушитель 2 палочки
	_check(car.get_driving_noise_level() == 4, "noise: стоковый выхлоп = 4 палочки")
	car.installed_parts["exhaust"] = "exhaust_muffler"
	_check(car.get_driving_noise_level() == 2, "noise: глушитель = 2 палочки (6 м)")

	# 3. Таран: без отвала машина получает 35 урона, с отвалом — защищена
	var hp_start: float = car.current_durability
	_check(not car.has_ram_bumper(), "ram: отвал по умолчанию не установлен")
	car.apply_vehicle_damage(Balance.data.car_ram_self_damage_no_bumper)
	_check(car.current_durability < hp_start, "ram: без отвала машина получает урон")
	car.installed_parts["bumper_ram"] = "bumper_ram"
	car._recalculate_vehicle_stats()
	_check(car.has_ram_bumper(), "ram: с bumper_ram отвал защищает двигатель")

	# 4. Багажник и сохранение машины в Гараж Хаба
	_check(car.trunk_grid.add_item_auto(GameState.get_item_data("canned_food"), 1),
		"trunk: лут кладётся в багажник")
	GameState.save_vehicle_to_garage(car)
	_check(GameState.has_garage_vehicle(), "garage: машина сохраняется в Гараж")
	_check(GameState.garage_trunk_grid.count_item_by_id("canned_food") == 1,
		"garage: лут багажника сохранён")
	var saved_parts: Dictionary = GameState.garage_vehicle_state.get("installed_parts", {})
	_check(saved_parts.get("exhaust", "") == "exhaust_muffler",
		"garage: установленные детали сохранены")

	# 5. Пешая эвакуация без машины — машина теряется навсегда
	GameState.start_raid(true)
	_check(GameState.deployed_with_garage_vehicle, "raid: флаг выезда на машине из Гаража")
	EventBus.extraction_completed.emit(false)
	_check(not GameState.has_garage_vehicle(),
		"garage: при пешей эвакуации без машины она теряется")

	car.queue_free()


func _check(condition: bool, message: String) -> void:
	if condition:
		print("OK    ", message)
	else:
		failures += 1
		print("FAIL  ", message)
