﻿$ErrorActionPreference = 'Stop'

# Генерирует .tres предметы по утверждённой пользователем таблице.
# Повторный запуск перезаписывает файлы теми же значениями.

$projectRoot = Split-Path $PSScriptRoot -Parent
$itemsDir = Join-Path $projectRoot 'resources\items'
if (-not (Test-Path $itemsDir)) { New-Item -ItemType Directory -Path $itemsDir -Force | Out-Null }

$utf8NoBom = New-Object System.Text.UTF8Encoding($false)

# id | имя | категория | ширина | высота | цена | стак | цвет | доп. поля
$items = @(
    @{ id='ruble_pack_small'; name='Пачка рублей (мелкая)'; cat=16; w=1; h=1; price=200; stack=1; color='0.86, 0.72, 0.29, 1'; desc='Мелкие купюры, найденные в карманах заражённого.'; extra='' },
    @{ id='ammo_545'; name='Патроны 5.45'; cat=10; w=1; h=1; price=30; stack=60; color='0.55, 0.55, 0.35, 1'; desc='Промежуточный патрон 5.45x39.'; extra='' },
    @{ id='canned_food'; name='Консервы'; cat=18; w=1; h=1; price=80; stack=5; color='0.5, 0.52, 0.35, 1'; desc='Просроченные, но съедобные консервы.'; extra='' },
    @{ id='bandage'; name='Бинт'; cat=11; w=1; h=1; price=120; stack=5; color='0.85, 0.85, 0.82, 1'; desc='Останавливает кровотечение.'; extra="cures_bleeding = true" },
    @{ id='tourniquet'; name='Жгут'; cat=11; w=1; h=1; price=150; stack=3; color='0.7, 0.25, 0.25, 1'; desc='Останавливает сильное кровотечение.'; extra="cures_bleeding = true" },
    @{ id='splint'; name='Шина'; cat=11; w=2; h=1; price=200; stack=3; color='0.62, 0.5, 0.36, 1'; desc='Фиксирует перелом.'; extra="cures_fracture = true" },
    @{ id='painkiller'; name='Обезболивающее'; cat=11; w=1; h=1; price=180; stack=3; color='0.45, 0.6, 0.85, 1'; desc='Снимает боль при переломе.'; extra="cures_fracture = true" },
    @{ id='antidote'; name='Антидот'; cat=11; w=1; h=1; price=600; stack=2; color='0.35, 0.78, 0.45, 1'; desc='Медленно выводит заражение за 120 секунд.'; extra="infection_cure_duration_sec = 120.0" },
    @{ id='injector_buff'; name='Инъектор-бафф'; cat=12; w=1; h=1; price=900; stack=2; color='0.7, 0.4, 0.85, 1'; desc='Стимулятор Химика. Выводит заражение за 25 секунд.'; extra="infection_cure_duration_sec = 25.0`nbuff_tier = 1`nbuff_speed_multiplier = 1.15" },
    @{ id='mutant_heart'; name='Мутировавшее сердце'; cat=17; w=1; h=1; price=3500; stack=1; color='0.6, 0.15, 0.2, 1'; desc='Огромное сердце мутанта. Скупает Чёрный торговец.'; extra="is_rare_black_market = true" },
    @{ id='mutant_fingers'; name='Мутировавшие пальцы'; cat=17; w=1; h=1; price=1200; stack=1; color='0.55, 0.4, 0.35, 1'; desc='Острые пальцы мутанта. Скупает Чёрный торговец.'; extra="is_rare_black_market = true" },
    @{ id='infected_crystal'; name='Заражённый кристалл'; cat=17; w=2; h=2; price=8000; stack=1; color='0.35, 0.85, 0.75, 1'; desc='Загадочный кристалл. Скупает Чёрный торговец.'; extra="is_rare_black_market = true" }
)

foreach ($item in $items) {
    $lines = @(
        '[gd_resource type="Resource" script_class="ItemData" load_steps=2 format=3]',
        '',
        '[ext_resource type="Script" path="res://resources/defs/item_data.gd" id="1_item"]',
        '',
        '[resource]',
        'script = ExtResource("1_item")',
        ('id = "{0}"' -f $item.id),
        ('display_name = "{0}"' -f $item.name),
        ('description = "{0}"' -f $item.desc),
        ('category = {0}' -f $item.cat),
        ('grid_size = Vector2i({0}, {1})' -f $item.w, $item.h),
        ('max_stack = {0}' -f $item.stack),
        ('base_price_rubles = {0}' -f $item.price),
        ('placeholder_color = Color({0})' -f $item.color)
    )
    if ($item.extra -ne '') {
        $lines += ($item.extra -split "`n")
    }

    $target = Join-Path $itemsDir ($item.id + '.tres')
    [System.IO.File]::WriteAllText($target, ($lines -join "`n") + "`n", $utf8NoBom)
    Write-Output ('OK  ' + $item.id + '.tres')
}
