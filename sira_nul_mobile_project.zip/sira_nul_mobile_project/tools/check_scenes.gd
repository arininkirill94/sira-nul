extends SceneTree
## Диагностика: пробует загрузить и инстанцировать все сцены проекта.
## Запуск: godot --headless --path . --script res://tools/check_scenes.gd


func _init() -> void:
	var paths: Array[String] = [
		"res://scenes/boot/camera_select_screen.tscn",
		"res://scenes/hub/hub_scene.tscn",
		"res://scenes/player/player.tscn",
		"res://scenes/ui/mobile_hud.tscn",
		"res://scenes/vehicles/raid_vehicle.tscn",
		"res://scenes/zombies/zombie.tscn",
		"res://scenes/world/raid_world.tscn",
	]
	var failed: int = 0
	for path in paths:
		var packed: PackedScene = load(path) as PackedScene
		if packed == null:
			print("FAIL  ", path)
			failed += 1
			continue
		var instance: Node = packed.instantiate()
		if instance == null:
			print("FAIL  instantiate ", path)
			failed += 1
			continue
		print("OK    ", path, "  root=", instance.name)
		instance.free()
	print("RESULT: failed=", failed, " of ", paths.size())
	quit()
