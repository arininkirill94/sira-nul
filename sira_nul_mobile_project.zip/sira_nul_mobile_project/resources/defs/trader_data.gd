class_name TraderData
extends Resource
## Ресурс торговца в Хабе (7 торговцев по разделу 4 GDD).

@export var trader_id: String = ""
@export var display_name: String = ""
@export_multiline var specialization_desc: String = ""

## Список ID товаров в ассортименте торговца
@export var catalog_item_ids: Array[String] = []
## Словарь минимальной репутации для покупки редких товаров: { "item_id": 25 }
@export var item_required_rep: Dictionary = {}

@export_group("Специальные функции торговца")
## Механик: ремонт изношенного оружия и брони за рубли
@export var can_repair_gear: bool = false
## Химик: создание инъекторов 1-3 уровня (16/35/120 с и снятие вируса за 25 с)
@export var can_craft_injectors: bool = false
## Автомеханик: продажа ремкомплектов и деталей для 6 узлов машины
@export var can_tune_vehicles: bool = false
## Чёрный торговец: скупка исключительно редкого/ценного лута и выдача сложных контрактов
@export var buys_only_rare_loot: bool = false