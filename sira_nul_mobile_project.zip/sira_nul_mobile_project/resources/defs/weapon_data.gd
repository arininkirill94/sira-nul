class_name WeaponData
extends ItemData
## Ресурс оружия: 1-я рука (строго основное огнестрельное) или 2-я рука (строго холодное).

enum WeaponSlot {
	PRIMARY_FIREARM = 1,
	SECONDARY_MELEE = 2
}

@export_group("Параметры оружия")
## 1-я рука (огнестрельное) или 2-я рука (холодное)
@export var hand_slot: WeaponSlot = WeaponSlot.PRIMARY_FIREARM
@export var damage: float = 25.0
## Скорострельность (выстрелов или ударов в секунду)
@export var fire_rate_rps: float = 4.0
## Дальность поражения RayCast3D в метрах
@export var range_meters: float = 50.0
## Ёмкость магазина (для огнестрельного оружия)
@export var magazine_capacity: int = 30
## Время перезарядки в секундах
@export var reload_time_sec: float = 2.2
## ID предмета патронов
@export var ammo_item_id: String = "ammo_rifle"
## Базовый разброс в градусах
@export var base_spread_deg: float = 2.0
## Потеря прочности за 1 выстрел/удар (ремонтируется у Механика в Хабе)
@export var durability_loss_per_use: float = 0.2
## Разрешённые слоты обвесов (AttachmentData.AttachmentSlot)
@export var allowed_attachment_slots: Array[int] = [0, 1, 2, 3, 4]