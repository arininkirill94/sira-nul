class_name QuestData
extends Resource
## Ресурс контракта / квеста торговцев Хаба.

enum QuestType {
	KILL_COUNT = 0,    ## Убить N врагов (например, 50 зомби за вылазку)
	CLEAR_SECTOR = 1,  ## Зачистить опасный сектор
	FETCH_ITEM = 2     ## Добыть редкий био-трофей или предмет
}

@export var quest_id: String = ""
@export var trader_id: String = ""
@export var title: String = ""
@export_multiline var description: String = ""
@export var objective_type: QuestType = QuestType.KILL_COUNT
## ID типа врага, сектора или предмета
@export var target_id: String = ""
## Требуемое количество (например, 50)
@export var required_amount: int = 1
## Нужно ли выполнить строго за одну вылазку
@export var single_raid_only: bool = false

@export_group("Вознаграждение")
@export var reward_rubles: int = 5000
@export var reward_reputation: int = 15
## Выдача топового снаряжения (для контрактов Чёрного торговца)
@export var reward_item_ids: Array[String] = []