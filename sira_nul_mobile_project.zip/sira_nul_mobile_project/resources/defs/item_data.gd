class_name ItemData
extends Resource
## Базовый ресурс любого предмета инвентаря, лута и торговли.

enum ItemCategory {
	MISC = 0,
	ARMOR_HEAD = 1,
	ARMOR_HANDS = 2,
	ARMOR_TORSO = 3,
	ARMOR_LEGS = 4,
	ARMOR_BOOTS = 5,
	BACKPACK = 6,
	FIREARM = 7,
	MELEE = 8,
	ATTACHMENT = 9,
	AMMO = 10,
	MEDICAL = 11,
	INJECTOR = 12,
	EXPLOSIVE = 13,
	VEHICLE_PART = 14,
	LOCKPICK = 15,
	VALUABLE = 16,
	BIO_TROPHY = 17,
	FOOD_WATER = 18
}

@export var id: String = ""
@export var display_name: String = ""
@export_multiline var description: String = ""
@export var category: ItemCategory = ItemCategory.MISC

@export_group("Клеточная сетка и Экономика")
## Размер в клетках инвентаря (ширина x высота)
@export var grid_size: Vector2i = Vector2i(1, 1)
## Можно ли поворачивать предмет на 90 градусов
@export var can_rotate: bool = true
## Максимальный размер стака
@export var max_stack: int = 1
## Базовая стоимость в российских рублях
@export var base_price_rubles: int = 100
## Скупается ли исключительно Чёрным торговцем (часы/электроника Ломбарда, редкие мутации)
@export var is_rare_black_market: bool = false
## Цвет плашки-заглушки в UI (заменить на иконку Texture2D при добавлении ассетов)
@export var placeholder_color: Color = Color(0.45, 0.48, 0.45, 1.0)

@export_group("Броня, Обувь и Рюкзаки")
@export var max_durability: float = 100.0
@export var armor_defense: float = 0.0
## Специальные бесшумные сапоги (шаг = 1 палочка, бег = 2 палочки)
@export var is_silent_boots: bool = false
## Размер сетки рюкзака (от 4x4 до 10x10, если category == BACKPACK)
@export var backpack_grid_size: Vector2i = Vector2i(0, 0)

@export_group("Медицина и Инъекторы Химика")
## Восполнение общего ХП (аптечки)
@export var heal_hp_amount: float = 0.0
## Снимает ли кровотечение (Бинт, Жгут)
@export var cures_bleeding: bool = false
## Снимает ли перелом/вывих (Шина, Обезболивающее)
@export var cures_fracture: bool = false
## Длительность вывода заражения вирусом (120 с для Антидота Медика, 25 с для Инъектора Химика)
@export var infection_cure_duration_sec: float = 0.0
## Уровень инъектора-баффа Химика (0 — нет, 1 — 16 с, 2 — 35 с, 3 — 120 с)
@export_range(0, 3) var buff_tier: int = 0
@export var buff_speed_multiplier: float = 1.0
@export var buff_strength_multiplier: float = 1.0