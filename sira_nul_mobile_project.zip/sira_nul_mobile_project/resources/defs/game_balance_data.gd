class_name GameBalanceData
extends Resource
## Ресурс всех балансных констант игры «Зомби-лутер — выживание в городе».
## Включает параметры Этапов 1–3 (таймер 25:00, шум 0/6/16/33 м, медицина, транспорт и экстракт).

@export_group("Регламент вылазки")
## Таймер рейда: 25:00 минут (1500 секунд)
@export var raid_duration_sec: float = 1500.0
## Время удержания зоны эвакуации под сиреной (15 секунд)
@export var extraction_hold_time_sec: float = 15.0

@export_group("Шкала шума (4 уровня) и Стрельба")
@export var noise_radius_level_1: float = 0.0
@export var noise_radius_level_2: float = 6.0
@export var noise_radius_level_3: float = 16.0
@export var noise_radius_level_4: float = 33.0
@export var melee_strike_noise_level: int = 1
@export var unmuffled_shot_quiet_chance: float = 0.25
@export var unmuffled_shot_loud_chance: float = 0.75
@export var shot_noise_duration_sec: float = 0.5

@export_group("Передвижение персонажа и Управление")
@export var walk_speed: float = 3.5
@export var run_speed: float = 6.5
@export var crouch_speed: float = 2.0
@export var fracture_walk_multiplier: float = 0.6
@export var joystick_run_threshold: float = 0.9
@export var touch_look_sensitivity: float = 0.0045

@export_group("Здоровье, Травмы и Инъекторы")
@export var player_base_max_hp: float = 100.0
@export var bleed_damage_per_sec: float = 1.5
@export var infection_max_hp_cap_initial: float = 60.0
@export var infection_max_hp_decay_per_sec: float = 0.5
@export var infection_min_hp_cap: float = 25.0
@export var medic_antidote_cure_sec: float = 120.0
@export var chemist_injector_cure_sec: float = 25.0
@export var buff_tier_1_duration_sec: float = 16.0
@export var buff_tier_2_duration_sec: float = 35.0
@export var buff_tier_3_duration_sec: float = 120.0

@export_group("Лутинг и Инвентарь")
@export var zombie_loot_drop_chance: float = 0.07
@export var pockets_slot_count: int = 6
@export var pocket_cell_size: Vector2i = Vector2i(1, 1)
@export var safe_slot_grid_size: Vector2i = Vector2i(2, 2)
@export var backpack_min_grid: Vector2i = Vector2i(4, 4)
@export var backpack_max_grid: Vector2i = Vector2i(10, 10)
@export var stash_grid_size: Vector2i = Vector2i(12, 30)

@export_group("Транспорт, Взлом отмычкой и Таран")
## Базовая максимальная прочность автомобиля
@export var car_max_durability: float = 200.0
## Вероятность срабатывания штатной сигнализации (33 м) при взломе авто отмычкой
@export var car_alarm_chance: float = 0.50
## Длительность работы штатной автосигнализации (7 секунд)
@export var car_alarm_duration_sec: float = 7.0
## Скорость палочки QTE взлома
@export var qte_cursor_speed: float = 1.35
## Ширина зоны успеха QTE
@export var qte_success_zone_width: float = 0.14
## Количество успешных попаданий QTE
@export var qte_required_hits: int = 1
## Базовая тяга двигателя (VehicleBody3D.engine_force)
@export var car_base_engine_force: float = 1100.0
## Базовое тормозное усилие (VehicleBody3D.brake)
@export var car_base_brake_force: float = 45.0
## Максимальный угол поворота передних колёс (радианы)
@export var car_max_steer_angle_rad: float = 0.48
## Минимальная скорость авто (м/с) для нанесения урона тараном
@export var car_ram_min_speed_mps: float = 3.5
## Урон по зомби при таране на ходу
@export var car_ram_zombie_damage: float = 120.0
## Урон двигателю/прочности машины при таране БЕЗ установленного отвала (бампера-тарана)
@export var car_ram_self_damage_no_bumper: float = 35.0
## Размер клеточной сетки багажника по умолчанию
@export var car_default_trunk_grid: Vector2i = Vector2i(6, 6)


func get_noise_radius(level: int) -> float:
	match clampi(level, 1, 4):
		1:
			return noise_radius_level_1
		2:
			return noise_radius_level_2
		3:
			return noise_radius_level_3
		4:
			return noise_radius_level_4
		_:
			return noise_radius_level_1