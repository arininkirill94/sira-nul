class_name AttachmentData
extends ItemData
## Ресурс модификации огнестрельного оружия (5 слотов из раздела 3.2 GDD).

enum AttachmentSlot {
	OPTIC = 0,     ## Прицел
	MUZZLE = 1,    ## Дуло / глушитель
	MAGAZINE = 2,  ## Магазин
	GRIP = 3,      ## Тактическая рукоять
	STOCK = 4      ## Приклад
}

@export_group("Параметры обвеса")
@export var slot_type: AttachmentSlot = AttachmentSlot.OPTIC
## Если true, любой выстрел даёт 100% фиксированный 2-й уровень шума (6 метров)
@export var is_suppressor: bool = false
## Дополнительные патроны к базовой ёмкости магазина
@export var extra_magazine_capacity: int = 0
## Множитель разброса (меньше 1.0 = выше кучность)
@export var spread_multiplier: float = 1.0
## Множитель эффективной дальности
@export var range_multiplier: float = 1.0