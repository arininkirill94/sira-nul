class_name VehiclePartData
extends ItemData
## Ресурс заменяемого узла автомобиля (6 слотов из раздела 3.5 GDD).

enum VehicleSlot {
	BUMPER_RAM = 0,  ## 1. Передний бампер / Таран (Отвал)
	BODY_ARMOR = 1,  ## 2. Броня кузова и решётки на окна
	ENGINE = 2,      ## 3. Двигатель
	TIRES = 3,       ## 4. Шины (Колёса)
	EXHAUST = 4,     ## 5. Выхлопная система (Глушитель авто)
	TRUNK = 5        ## 6. Багажник (отдельная клеточная сетка)
}

@export_group("Параметры узла автомобиля")
@export var part_slot: VehicleSlot = VehicleSlot.BUMPER_RAM
## Позволяет таранить зомби на ходу без повреждения двигателя
@export var negates_ram_engine_damage: bool = false
## Защита кузова и водителя от пуль военных/мародёров и ударов мутантов
@export var hull_armor_bonus: float = 0.0
## Прибавка к тяге двигателя (VehicleBody3D.engine_force)
@export var engine_force_bonus: float = 0.0
## Максимальная скорость с данным двигателем (км/ч)
@export var max_speed_kmh: float = 60.0
## Коэффициент сцепления колёс (VehicleWheel3D.wheel_friction_slip)
@export var wheel_friction_slip: float = 1.5
## Уровень шума при езде (сток = 4 палочки, тихий выхлоп = 3 или 2 палочки)
@export_range(2, 4) var driving_noise_level: int = 4
## Размер клеточной сетки багажника для перевозки лута
@export var trunk_grid_size: Vector2i = Vector2i(6, 6)