class_name ZombieData
extends Resource
## Ресурс параметров врага (зомби, быстрые бегуны, громилы, мутанты, военные, мародёры).

enum EnemyFaction {
	INFECTED = 0,  ## Зомби и мутанты
	MILITARY = 1,  ## Вооружённые военные (плотный неточный огонь, идут на шум)
	MARAUDER = 2   ## Мародёры (рандомная экипировка)
}

@export var id: String = "zombie_walker"
@export var display_name: String = "Медленный зомби"
@export var faction: EnemyFaction = EnemyFaction.INFECTED

@export_group("Характеристики и ИИ")
@export var max_hp: float = 60.0
@export var move_speed: float = 2.5
## Дальность зрения через RayCast3D (метры)
@export var vision_range_m: float = 15.0
## Угол обзора (градусы)
@export var vision_fov_deg: float = 110.0
## Дистанция атаки (метры)
@export var attack_range_m: float = 1.8
@export var attack_damage: float = 12.0
@export var attack_cooldown_sec: float = 1.2
## Стреляет ли враг из огнестрельного оружия (военные / мародёры)
@export var uses_ranged_weapon: bool = false
@export var ranged_spread_deg: float = 8.0

@export_group("Шансы наложения травм при попадании по игроку")
@export_range(0.0, 1.0) var bleed_chance: float = 0.20
@export_range(0.0, 1.0) var fracture_chance: float = 0.10
@export_range(0.0, 1.0) var infection_chance: float = 0.15

@export_group("Таблицы лута при обыске трупа")
## Обычный пул предметов (для зомби проверяется с шансом 7% из Balance)
@export var loot_pool_ids: Array[String] = []
## Особо редкие био-трофеи (мутировавшее сердце, пальцы, заражённый кристалл)
@export var rare_bio_trophy_ids: Array[String] = []
@export_range(0.0, 1.0) var rare_bio_trophy_chance: float = 0.02