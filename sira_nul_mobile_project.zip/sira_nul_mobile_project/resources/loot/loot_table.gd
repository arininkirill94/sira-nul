class_name LootTable
extends Resource
## Таблица дропа: список записей с весом.
## Запись — словарь:
## {
##   "item": String,     # путь к .tres предмета
##   "weight": float,    # вес в общей сумме
##   "value_min": int,   # опционально: минимальная стоимость при выпадении
##   "value_max": int    # опционально: максимальная стоимость
## }
##
## Значения весов утверждены пользователем (см. docs/PROJECT_STATE.md).

@export var entries: Array[Dictionary] = []


## Возвращает случайную запись с учётом веса. Пустой словарь — если таблица пуста.
func roll_entry() -> Dictionary:
	var total_weight: float = 0.0
	for entry in entries:
		total_weight += maxf(0.0, float(entry.get("weight", 0.0)))
	if total_weight <= 0.0:
		return {}

	var pick: float = randf() * total_weight
	for entry in entries:
		var weight: float = maxf(0.0, float(entry.get("weight", 0.0)))
		if weight <= 0.0:
			continue
		pick -= weight
		if pick <= 0.0:
			return entry
	return entries.back() if not entries.is_empty() else {}


## Итоговая стоимость записи: базовый предмет или случайный диапазон.
func resolve_value(entry: Dictionary, item: ItemData) -> int:
	var min_value: int = int(entry.get("value_min", 0))
	var max_value: int = int(entry.get("value_max", 0))
	if max_value > 0 and max_value >= min_value:
		return randi_range(min_value, max_value)
	if item != null:
		return item.base_price_rubles
	return 0


## Совместимость с ИИ-скриптом Zombie (Этап 2): он вызывает roll_items() / roll_item().
func roll_items(count: int = 1) -> Array:
	var result: Array = []
	for i in range(maxi(1, count)):
		var entry: Dictionary = roll_entry()
		if entry.is_empty():
			continue
		var item: ItemData = load(str(entry.get("item", ""))) as ItemData
		if item != null:
			result.append(item)
	return result


func roll_item() -> ItemData:
	var items: Array = roll_items(1)
	return items[0] as ItemData if not items.is_empty() else null
