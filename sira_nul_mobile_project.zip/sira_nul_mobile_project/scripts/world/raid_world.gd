extends Node3D
## Контроллер городского уровня (Этап 3):
## - Размещает запертую дикую машину для взлома отмычкой;
## - Если игрок выбрал «Выехать в рейд на машине» в Гараже Хаба — спавнит его машину открытой рядом со стартом;
## - Включает все 3 точки эвакуации из раздела 2 GDD (Вертолётная площадка, Ж/д тоннель/Поезд, Автовыезд/Блокпост).

const HUB_SCENE_PATH: String = "res://scenes/hub/hub_scene.tscn"
const VEHICLE_SCENE: PackedScene = preload("res://scenes/vehicles/raid_vehicle.tscn")

@onready var player_garage_car_spawn: Marker3D = $GarageCarSpawnMarker


func _ready() -> void:
	if not GameState.is_in_raid:
		GameState.start_raid(GameState.deployed_with_garage_vehicle)

	if GameState.deployed_with_garage_vehicle and GameState.has_garage_vehicle():
		_spawn_player_garage_vehicle()

	EventBus.player_died.connect(_on_raid_ended_return_to_hub)
	EventBus.extraction_completed.connect(_on_extraction_completed)


func _spawn_player_garage_vehicle() -> void:
	if VEHICLE_SCENE == null:
		return
	var car: RaidVehicle = VEHICLE_SCENE.instantiate() as RaidVehicle
	add_child(car)
	car.global_transform = player_garage_car_spawn.global_transform
	car.apply_from_garage_dictionary(GameState.garage_vehicle_state)


func _on_extraction_completed(_with_vehicle: bool) -> void:
	_on_raid_ended_return_to_hub()


func _on_raid_ended_return_to_hub() -> void:
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	if ResourceLoader.exists(HUB_SCENE_PATH):
		get_tree().change_scene_to_file(HUB_SCENE_PATH)