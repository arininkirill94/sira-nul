class_name ExtractionZone
extends Area3D
## Точка эвакуации (раздел 2 и 3.5 GDD):
## 1) HELIPAD — Вертолётная площадка (Военная база, только пешая эвакуация)
## 2) TRAIN_TUNNEL — Ж/д тоннель / Поезд (юго-восток, только пешая эвакуация)
## 3) VEHICLE_CHECKPOINT — Укреплённый автовыезд / Блокпост (позволяет эвакуироваться вместе с автомобилем)
## После нажатия кнопки «Вызвать транспорт» включается громкая сирена (4-я шкала шума — 33 м)
## и таймер удержания зоны 15 секунд.

enum ExtractionType {
	HELIPAD = 0,
	TRAIN_TUNNEL = 1,
	VEHICLE_CHECKPOINT = 2
}

@export var point_title: String = "Укреплённый автовыезд / Блокпост"
@export var extraction_type: ExtractionType = ExtractionType.VEHICLE_CHECKPOINT
## Тестовый/отладочный оверрайд времени удержания. 0.0 = брать из Balance.
## Игровое значение 15 секунд остаётся в default_balance.tres.
@export var hold_time_sec: float = 0.0

@onready var beacon_mesh: MeshInstance3D = $BeaconMesh

var is_siren_active: bool = false
var hold_time_left: float = 0.0
var siren_pulse_timer: float = 0.0

var player_inside: bool = false
var vehicles_inside: Array[RaidVehicle] = []


func _ready() -> void:
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)


func _physics_process(delta: float) -> void:
	if not is_siren_active:
		return

	# Проверяем, находится ли игрок в зоне (пешком или за рулём машины внутри зоны)
	var is_holding_zone: bool = player_inside or _is_driver_inside_any_vehicle_in_zone()
	if not is_holding_zone:
		cancel_extraction()
		return

	# Периодический импульс сирены: 4-я шкала шума (33 м), стягивающая всех окрестных зомби
	siren_pulse_timer -= delta
	if siren_pulse_timer <= 0.0:
		siren_pulse_timer = 0.5
		var rad: float = Balance.data.get_noise_radius(4)
		EventBus.noise_emitted.emit(global_position, 4, rad)
		EventBus.player_noise_level_changed.emit(4, rad)

	hold_time_left = maxf(0.0, hold_time_left - delta)
	EventBus.extraction_progress.emit(hold_time_left)

	if hold_time_left <= 0.0:
		_complete_extraction()


func _is_driver_inside_any_vehicle_in_zone() -> bool:
	for v in vehicles_inside:
		if is_instance_valid(v) and v.driver_player != null:
			return true
	return false


func get_valid_vehicle_for_extraction() -> RaidVehicle:
	if extraction_type != ExtractionType.VEHICLE_CHECKPOINT:
		return null
	for v in vehicles_inside:
		if is_instance_valid(v) and not v.is_destroyed and not v.is_locked:
			return v
	return null


func get_effective_hold_time() -> float:
	if hold_time_sec > 0.0:
		return hold_time_sec
	return Balance.data.extraction_hold_time_sec


func start_extraction_siren() -> void:
	if is_siren_active:
		return
	is_siren_active = true
	hold_time_left = get_effective_hold_time()
	siren_pulse_timer = 0.0

	var rad: float = Balance.data.get_noise_radius(4)
	EventBus.noise_emitted.emit(global_position, 4, rad)
	EventBus.player_noise_level_changed.emit(4, rad)
	EventBus.extraction_started.emit(point_title, hold_time_left)


func cancel_extraction() -> void:
	if not is_siren_active:
		return
	is_siren_active = false
	hold_time_left = 0.0
	EventBus.extraction_cancelled.emit()


func _complete_extraction() -> void:
	is_siren_active = false
	var extracted_car: RaidVehicle = get_valid_vehicle_for_extraction()
	var with_vehicle: bool = extracted_car != null

	if with_vehicle:
		GameState.save_vehicle_to_garage(extracted_car)

	EventBus.extraction_completed.emit(with_vehicle)


func get_interaction_prompt() -> String:
	if is_siren_active:
		return "СИРЕНА ЭВАКУАЦИИ: %d сек." % int(ceil(hold_time_left))
	match extraction_type:
		ExtractionType.HELIPAD:
			return "ВЫЗВАТЬ ВЕРТОЛЁТ (%s)" % point_title
		ExtractionType.TRAIN_TUNNEL:
			return "ВЫЗВАТЬ ПОЕЗД (%s)" % point_title
		ExtractionType.VEHICLE_CHECKPOINT:
			return "ВЫЗВАТЬ ТРАНСПОРТ / ОТКРЫТЬ БЛОКПОСТ"
	return "ВЫЗВАТЬ ТРАНСПОРТ"


func interact(_player: Player) -> void:
	start_extraction_siren()


func _on_body_entered(body: Node) -> void:
	if body is Player:
		player_inside = true
	elif body is RaidVehicle:
		var car: RaidVehicle = body as RaidVehicle
		if not vehicles_inside.has(car):
			vehicles_inside.append(car)
		# На автовыезде эвакуация запускается сразу, как только машина с водителем
		# заехала в зону: в автомобильном HUD нет отдельной кнопки контекста.
		if extraction_type == ExtractionType.VEHICLE_CHECKPOINT \
			and not car.is_locked and not car.is_destroyed and car.driver_player != null:
			start_extraction_siren()


func _on_body_exited(body: Node) -> void:
	if body is Player:
		player_inside = false
	elif body is RaidVehicle:
		vehicles_inside.erase(body as RaidVehicle)