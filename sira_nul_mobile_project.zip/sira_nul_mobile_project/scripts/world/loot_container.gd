class_name WorldLootContainer
extends StaticBody3D
## Обыскиваемый контейнер в городской локации (ящик, шкаф, медпункт, схрон).
## Генерирует лут из ресурса LootTable (или стартового пула предметов локации) в сетку InventoryGrid.

@export var container_title: String = "Ящик снабжения"
@export var grid_dimensions: Vector2i = Vector2i(5, 4)
@export var loot_table: Resource
@export var preset_item_ids: Array[String] = [
	"bandage",
	"canned_food",
	"ammo_545",
	"splint",
	"painkiller",
	"antidote",
	"tourniquet"
]
@export var min_items: int = 2
@export var max_items: int = 4

var loot_grid: InventoryGrid
var is_generated: bool = false


func _ready() -> void:
	loot_grid = InventoryGrid.new(grid_dimensions.x, grid_dimensions.y)


func get_container_title() -> String:
	return container_title


func get_loot_grid() -> InventoryGrid:
	if not is_generated:
		_generate_loot()
	return loot_grid


func _generate_loot() -> void:
	is_generated = true
	loot_grid.clear()

	# 1. Если назначен ресурс LootTable (res://resources/loot/loot_table.gd) — вызываем его метод генерации
	if loot_table != null:
		if loot_table.has_method("roll_items"):
			var rolled: Variant = loot_table.call("roll_items")
			if rolled is Array:
				for entry in rolled:
					_add_rolled_entry_to_grid(entry)
				return
		elif loot_table.has_method("generate_loot"):
			var rolled_alt: Variant = loot_table.call("generate_loot")
			if rolled_alt is Array:
				for entry in rolled_alt:
					_add_rolled_entry_to_grid(entry)
				return

	# 2. Генерация из пула предметов локации
	if preset_item_ids.is_empty():
		return
	var count: int = randi_range(min_items, max_items)
	for _i in range(count):
		var random_id: String = preset_item_ids[randi() % preset_item_ids.size()]
		var item_data: ItemData = GameState.get_item_data(random_id)
		if item_data != null:
			var stack: int = randi_range(15, 30) if item_data.max_stack >= 30 else 1
			loot_grid.add_item_auto(item_data, stack)


func _add_rolled_entry_to_grid(entry: Variant) -> void:
	if entry is ItemData:
		var item: ItemData = entry as ItemData
		var stack: int = randi_range(10, 30) if item.max_stack >= 30 else 1
		loot_grid.add_item_auto(item, stack)
	elif entry is String:
		var item_by_id: ItemData = GameState.get_item_data(str(entry))
		if item_by_id != null:
			loot_grid.add_item_auto(item_by_id, 1)


func get_interaction_prompt() -> String:
	return "ОБЫСКАТЬ: %s" % container_title


func interact(_player: Player) -> void:
	var _grid: InventoryGrid = get_loot_grid()
	EventBus.request_open_loot_container.emit(self)