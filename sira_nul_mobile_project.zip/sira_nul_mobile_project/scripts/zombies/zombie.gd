class_name Zombie
extends CharacterBody3D
## ИИ зомби (Этап 2): после смерти переходит в состояние обыскиваемого контейнера
## с сеткой InventoryGrid (4x3) и генерацией лута из res://resources/loot/zombie_loot.tres
## по шансу Balance.data.zombie_loot_drop_chance.

enum AIState {
	IDLE = 0,
	INVESTIGATE_NOISE = 1,
	CHASE_PLAYER = 2,
	ATTACK = 3,
	DEAD = 4
}

const GRAVITY: float = 19.6
const ZOMBIE_LOOT_TABLE_PATH: String = "res://resources/loot/zombie_loot.tres"
## Отдельный слой трупа: игрок должен видеть его InteractionArea3D,
## но не должен упираться в него телом. Значение = бит 6 (32).
const CORPSE_COLLISION_LAYER: int = 32

@export var zombie_data: ZombieData

@onready var collision_shape: CollisionShape3D = $CollisionShape3D
@onready var mesh_instance: MeshInstance3D = $MeshInstance3D
@onready var nav_agent: NavigationAgent3D = $NavigationAgent3D
@onready var vision_ray: RayCast3D = $VisionRayCast3D
@onready var corpse_loot_area: Area3D = $CorpseLootArea3D

var state: AIState = AIState.IDLE
var current_hp: float = 60.0
var target_player: Player = null
var last_heard_position: Vector3 = Vector3.ZERO
var attack_timer: float = 0.0
var vision_check_timer: float = 0.0

var has_rolled_loot: bool = false
var corpse_grid: InventoryGrid


func _ready() -> void:
	add_to_group("enemies")
	if zombie_data == null:
		zombie_data = ZombieData.new()
	current_hp = zombie_data.max_hp
	corpse_grid = InventoryGrid.new(4, 3)
	corpse_loot_area.monitoring = false
	corpse_loot_area.monitorable = false
	EventBus.noise_emitted.connect(_on_noise_emitted)


func _physics_process(delta: float) -> void:
	if state == AIState.DEAD:
		return

	if not is_on_floor():
		velocity.y -= GRAVITY * delta

	if attack_timer > 0.0:
		attack_timer = maxf(0.0, attack_timer - delta)

	vision_check_timer -= delta
	if vision_check_timer <= 0.0:
		vision_check_timer = 0.2
		_check_vision_for_player()

	match state:
		AIState.IDLE:
			velocity.x = move_toward(velocity.x, 0.0, 8.0 * delta)
			velocity.z = move_toward(velocity.z, 0.0, 8.0 * delta)

		AIState.INVESTIGATE_NOISE:
			_move_along_navigation(last_heard_position, zombie_data.move_speed * 0.85, delta)
			if global_position.distance_to(last_heard_position) < 1.4:
				state = AIState.IDLE

		AIState.CHASE_PLAYER:
			if target_player == null or not is_instance_valid(target_player):
				state = AIState.IDLE
			else:
				var dist: float = global_position.distance_to(target_player.global_position)
				if dist <= zombie_data.attack_range_m:
					state = AIState.ATTACK
				else:
					_move_along_navigation(target_player.global_position, zombie_data.move_speed, delta)

		AIState.ATTACK:
			velocity.x = 0.0
			velocity.z = 0.0
			if target_player == null or not is_instance_valid(target_player):
				state = AIState.IDLE
			else:
				_face_target(target_player.global_position, delta)
				var dist: float = global_position.distance_to(target_player.global_position)
				if dist > zombie_data.attack_range_m * 1.15:
					state = AIState.CHASE_PLAYER
				elif attack_timer <= 0.0:
					_perform_melee_attack()

	move_and_slide()


func _check_vision_for_player() -> void:
	if target_player == null:
		target_player = get_tree().get_first_node_in_group("player") as Player
	if target_player == null:
		return

	var to_player: Vector3 = (target_player.global_position + Vector3(0.0, 1.2, 0.0)) - vision_ray.global_position
	var dist: float = to_player.length()
	if dist > zombie_data.vision_range_m:
		return

	var forward_dir: Vector3 = -global_transform.basis.z
	var angle_deg: float = rad_to_deg(forward_dir.angle_to(to_player.normalized()))
	if angle_deg > zombie_data.vision_fov_deg * 0.5:
		return

	vision_ray.target_position = vision_ray.to_local(target_player.global_position + Vector3(0.0, 1.2, 0.0))
	vision_ray.force_raycast_update()
	if vision_ray.is_colliding() and vision_ray.get_collider() == target_player:
		state = AIState.CHASE_PLAYER


func _on_noise_emitted(origin: Vector3, _level: int, radius: float) -> void:
	if state == AIState.DEAD or radius <= 0.0:
		return
	if global_position.distance_to(origin) <= radius:
		last_heard_position = origin
		if state != AIState.CHASE_PLAYER and state != AIState.ATTACK:
			state = AIState.INVESTIGATE_NOISE


func _move_along_navigation(target_pos: Vector3, speed: float, delta: float) -> void:
	nav_agent.target_position = target_pos
	var next_path_pos: Vector3 = nav_agent.get_next_path_position()
	var dir: Vector3 = (next_path_pos - global_position)
	dir.y = 0.0
	if dir.length_squared() > 0.01:
		dir = dir.normalized()
		_face_target(next_path_pos, delta)
		velocity.x = dir.x * speed
		velocity.z = dir.z * speed
	else:
		velocity.x = move_toward(velocity.x, 0.0, speed * 5.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, speed * 5.0 * delta)


func _face_target(world_pos: Vector3, delta: float) -> void:
	var flat_target: Vector3 = Vector3(world_pos.x, global_position.y, world_pos.z)
	if global_position.distance_squared_to(flat_target) > 0.01:
		var target_basis: Basis = Transform3D().looking_at(flat_target - global_position, Vector3.UP).basis
		global_transform.basis = global_transform.basis.slerp(target_basis, 10.0 * delta)


func _perform_melee_attack() -> void:
	attack_timer = zombie_data.attack_cooldown_sec
	if target_player == null:
		return
	var bleed_roll: bool = randf() < zombie_data.bleed_chance
	var fracture_roll: bool = randf() < zombie_data.fracture_chance
	var infect_roll: bool = randf() < zombie_data.infection_chance
	target_player.receive_attack_damage(zombie_data.attack_damage, bleed_roll, fracture_roll, infect_roll)


func apply_damage(amount: float, attacker_pos: Vector3) -> void:
	if state == AIState.DEAD:
		return
	current_hp -= amount
	last_heard_position = attacker_pos
	if state == AIState.IDLE:
		state = AIState.INVESTIGATE_NOISE
	if current_hp <= 0.0:
		_die()


func _die() -> void:
	state = AIState.DEAD
	velocity = Vector3.ZERO
	# Столкновение не отключаем: тело трупа остаётся видимым для InteractionArea3D игрока.
	# Но переводим его на отдельный слой 32, которого нет в маске движения игрока,
	# поэтому труп не блокирует проход и пули.
	set_deferred("collision_layer", CORPSE_COLLISION_LAYER)
	set_deferred("collision_mask", 0)

	mesh_instance.rotation_degrees.x = 90.0
	mesh_instance.position.y = 0.35

	_roll_corpse_loot()
	corpse_loot_area.set_deferred("monitoring", true)
	corpse_loot_area.set_deferred("monitorable", true)

	GameState.current_raid_kills += 1
	EventBus.enemy_killed.emit(zombie_data.id, int(zombie_data.faction), global_position)


## Розыгрыш трофеев убитого зомби по шансу из Balance.data.zombie_loot_drop_chance
## с поддержкой ресурса res://resources/loot/zombie_loot.tres
func _roll_corpse_loot() -> void:
	if has_rolled_loot:
		return
	has_rolled_loot = true
	corpse_grid.clear()

	if randf() > Balance.data.zombie_loot_drop_chance:
		return

	var added_from_table: bool = false
	if ResourceLoader.exists(ZOMBIE_LOOT_TABLE_PATH):
		var table_res: Resource = load(ZOMBIE_LOOT_TABLE_PATH)
		if table_res != null:
			if table_res.has_method("roll_items"):
				var rolled: Variant = table_res.call("roll_items")
				if rolled is Array and not (rolled as Array).is_empty():
					for entry in rolled:
						if entry is ItemData:
							corpse_grid.add_item_auto(entry as ItemData, 1)
							added_from_table = true
						elif entry is String:
							var item_by_id: ItemData = GameState.get_item_data(str(entry))
							if item_by_id != null:
								corpse_grid.add_item_auto(item_by_id, 1)
								added_from_table = true
			elif table_res.has_method("roll_item"):
				var single: Variant = table_res.call("roll_item")
				if single is ItemData:
					corpse_grid.add_item_auto(single as ItemData, 1)
					added_from_table = true

	if not added_from_table:
		var pool: Array[String] = ["ruble_pack_small", "bandage", "canned_food", "ammo_545"]
		var chosen_id: String = pool[randi() % pool.size()]
		var item_data: ItemData = GameState.get_item_data(chosen_id)
		if item_data != null:
			var stack: int = 15 if chosen_id == "ammo_545" else 1
			corpse_grid.add_item_auto(item_data, stack)

	# Редкие био-трофеи (2%) уже входят в таблицу zombie_loot.tres отдельными записями,
	# поэтому второй бросок здесь не нужен.

func get_container_title() -> String:
	return "Труп: %s" % zombie_data.display_name


func get_loot_grid() -> InventoryGrid:
	return corpse_grid


func get_interaction_prompt() -> String:
	if state == AIState.DEAD:
		return "ОБЫСКАТЬ ТРУП"
	return ""


func interact(_player: Player) -> void:
	if state != AIState.DEAD:
		return
	EventBus.request_open_loot_container.emit(self)