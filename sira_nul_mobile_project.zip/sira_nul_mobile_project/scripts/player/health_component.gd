class_name HealthComponent
extends Node
## Система здоровья, 3 травм и инъекторов строго по разделу 3.4 GDD:
## 1. Кровотечение (периодическая потеря ХП) — снимается Бинтом (bandage) или Жгутом (tourniquet).
## 2. Перелом / Вывих (запрет бега, снижение скорости шага) — снимается Шиной (splint) или Обезболивающим (painkiller).
## 3. Заражение вирусом (снижение максимума ХП, помехи зрения) — лечится Антидотом Медика (120 сек)
##    или Инъектором Химика (быстрое выведение за 25 сек).
## 4. Инъекторы-баффы Химика 1-3 уровня: длительность строго 16 сек, 35 сек и 120 сек (без неуязвимости).

var current_hp: float = 100.0
var effective_max_hp: float = 100.0

var is_bleeding: bool = false
var has_fracture: bool = false
var is_infected: bool = false

# Таймер вывода вируса (120.0 с для Антидота Медика или 25.0 с для Инъектора Химика)
var infection_cure_time_left: float = 0.0
var infection_cure_total_duration: float = 0.0

# Таймер инъектора-баффа Химика (16 / 35 / 120 сек)
var active_buff_tier: int = 0
var buff_time_left: float = 0.0
var speed_buff_multiplier: float = 1.0
var strength_buff_multiplier: float = 1.0


func _ready() -> void:
	reset_health()


func reset_health() -> void:
	effective_max_hp = Balance.data.player_base_max_hp
	current_hp = effective_max_hp
	is_bleeding = false
	has_fracture = false
	is_infected = false
	infection_cure_time_left = 0.0
	infection_cure_total_duration = 0.0
	active_buff_tier = 0
	buff_time_left = 0.0
	speed_buff_multiplier = 1.0
	strength_buff_multiplier = 1.0
	_broadcast_state()


func _process(delta: float) -> void:
	var hp_dirty: bool = false
	var status_dirty: bool = false

	# 1. Кровотечение: периодическая потеря ХП
	if is_bleeding:
		current_hp = maxf(0.0, current_hp - Balance.data.bleed_damage_per_sec * delta)
		hp_dirty = true

	# 2. Заражение вирусом и таймер выведения (120 с / 25 с)
	if is_infected:
		if infection_cure_time_left > 0.0:
			infection_cure_time_left = maxf(0.0, infection_cure_time_left - delta)
			status_dirty = true
			if infection_cure_time_left <= 0.0:
				is_infected = false
				infection_cure_total_duration = 0.0
				effective_max_hp = Balance.data.player_base_max_hp
				hp_dirty = true
		else:
			effective_max_hp = maxf(
				Balance.data.infection_min_hp_cap,
				effective_max_hp - Balance.data.infection_max_hp_decay_per_sec * delta
			)
			if current_hp > effective_max_hp:
				current_hp = effective_max_hp
			hp_dirty = true

	# 3. Таймер инъектора-баффа Химика (16 / 35 / 120 сек)
	if active_buff_tier > 0 and buff_time_left > 0.0:
		buff_time_left = maxf(0.0, buff_time_left - delta)
		EventBus.player_buff_changed.emit(active_buff_tier, buff_time_left)
		if buff_time_left <= 0.0:
			active_buff_tier = 0
			speed_buff_multiplier = 1.0
			strength_buff_multiplier = 1.0
			EventBus.player_buff_changed.emit(0, 0.0)

	if hp_dirty:
		EventBus.player_health_changed.emit(current_hp, effective_max_hp, Balance.data.player_base_max_hp)
	if status_dirty:
		EventBus.player_status_changed.emit(is_bleeding, has_fracture, is_infected, infection_cure_time_left)

	if current_hp <= 0.0:
		EventBus.player_died.emit()


## Применение урона и проверка шансов наложения травм
func apply_damage_and_injuries(amount: float, bleed_roll: bool, fracture_roll: bool, infect_roll: bool) -> void:
	current_hp = maxf(0.0, current_hp - amount)

	if bleed_roll and not is_bleeding:
		is_bleeding = true
	if fracture_roll and not has_fracture:
		has_fracture = true
	if infect_roll and not is_infected:
		is_infected = true
		effective_max_hp = minf(effective_max_hp, Balance.data.infection_max_hp_cap_initial)
		current_hp = minf(current_hp, effective_max_hp)

	_broadcast_state()
	if current_hp <= 0.0:
		EventBus.player_died.emit()


## Использование медицинского предмета, еды или инъектора из инвентаря.
## Возвращает true, если предмет был применён и должен быть израсходован.
func use_consumable_item(item_data: ItemData) -> bool:
	if item_data == null:
		return false

	var used: bool = false
	var id_lower: String = item_data.id.to_lower()

	# Снятие кровотечения: Бинт (bandage) или Жгут (tourniquet)
	if item_data.cures_bleeding or id_lower.contains("bandage") or id_lower.contains("tourniquet"):
		if is_bleeding:
			is_bleeding = false
			used = true

	# Снятие перелома/вывиха: Шина (splint) или Обезболивающее (painkiller)
	if item_data.cures_fracture or id_lower.contains("splint") or id_lower.contains("painkiller"):
		if has_fracture:
			has_fracture = false
			used = true

	# Лечение вируса: Антидот Медика (120 сек) или Инъектор Химика (25 сек)
	var cure_duration: float = item_data.infection_cure_duration_sec
	if id_lower.contains("antidote") and cure_duration <= 0.0:
		cure_duration = Balance.data.medic_antidote_cure_sec
	elif id_lower.contains("injector_cure") and cure_duration <= 0.0:
		cure_duration = Balance.data.chemist_injector_cure_sec

	if cure_duration > 0.0 and is_infected:
		# Если уже запущен медленный антидот (120 с), быстрый инъектор (25 с) сокращает таймер
		if infection_cure_time_left <= 0.0 or cure_duration < infection_cure_time_left:
			infection_cure_time_left = cure_duration
			infection_cure_total_duration = cure_duration
			used = true

	# Инъекторы-баффы Химика 1-3 уровня (16 сек / 35 сек / 120 сек)
	var tier: int = item_data.buff_tier
	if tier <= 0 and id_lower.contains("injector_buff"):
		if id_lower.contains("t3") or id_lower.contains("3"):
			tier = 3
		elif id_lower.contains("t2") or id_lower.contains("2"):
			tier = 2
		else:
			tier = 1

	if tier > 0:
		active_buff_tier = clampi(tier, 1, 3)
		match active_buff_tier:
			1:
				buff_time_left = Balance.data.buff_tier_1_duration_sec
				speed_buff_multiplier = maxf(1.2, item_data.buff_speed_multiplier)
				strength_buff_multiplier = maxf(1.25, item_data.buff_strength_multiplier)
			2:
				buff_time_left = Balance.data.buff_tier_2_duration_sec
				speed_buff_multiplier = maxf(1.32, item_data.buff_speed_multiplier)
				strength_buff_multiplier = maxf(1.45, item_data.buff_strength_multiplier)
			3:
				buff_time_left = Balance.data.buff_tier_3_duration_sec
				speed_buff_multiplier = maxf(1.45, item_data.buff_speed_multiplier)
				strength_buff_multiplier = maxf(1.75, item_data.buff_strength_multiplier)
		# Ускоренное обеззараживание от бафф-инъектора Химика, если персонаж заражён
		if is_infected and (infection_cure_time_left <= 0.0 or infection_cure_time_left > Balance.data.chemist_injector_cure_sec):
			infection_cure_time_left = Balance.data.chemist_injector_cure_sec
			infection_cure_total_duration = Balance.data.chemist_injector_cure_sec
		EventBus.player_buff_changed.emit(active_buff_tier, buff_time_left)
		used = true

	# Восполнение общего ХП аптечками / консервами
	var heal_amt: float = item_data.heal_hp_amount
	if heal_amt <= 0.0 and (id_lower.contains("canned_food") or id_lower.contains("medkit")):
		heal_amt = 35.0
	if heal_amt > 0.0 and current_hp < effective_max_hp:
		current_hp = minf(effective_max_hp, current_hp + heal_amt)
		used = true

	if used:
		_broadcast_state()
	return used


func _broadcast_state() -> void:
	EventBus.player_health_changed.emit(current_hp, effective_max_hp, Balance.data.player_base_max_hp)
	EventBus.player_status_changed.emit(is_bleeding, has_fracture, is_infected, infection_cure_time_left)