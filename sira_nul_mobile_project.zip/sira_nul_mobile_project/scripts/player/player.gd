class_name Player
extends CharacterBody3D
## Контроллер персонажа для Godot 4.7.2 (Этап 2: интеграция с HealthComponent и слотами GameState).

const GRAVITY: float = 19.6
const JUMP_VELOCITY: float = 4.5
const STAND_HEIGHT: float = 1.8
const CROUCH_HEIGHT: float = 1.1
const NORMAL_FOV: float = 75.0
const AIM_FOV: float = 52.0
## Как часто пересчитывать цель взаимодействия (сек).
## Нужно, чтобы кнопка «Обыскать» появлялась/исчезала сразу при смене состояния цели,
## а не только по сигналам входа/выхода из Area3D.
const INTERACTION_REFRESH_INTERVAL: float = 0.15

@export_group("Оружие и Модификации")
@export var primary_weapon: WeaponData
@export var secondary_weapon: WeaponData
@export var equipped_muzzle_attachment: AttachmentData
@export var wearing_silent_boots: bool = false

@onready var collision_shape: CollisionShape3D = $CollisionShape3D
@onready var body_mesh: MeshInstance3D = $BodyMesh
@onready var head_pivot: Node3D = $HeadPivot
@onready var first_person_camera: Camera3D = $HeadPivot/FirstPersonCamera
@onready var spring_arm: SpringArm3D = $HeadPivot/SpringArm3D
@onready var third_person_camera: Camera3D = $HeadPivot/SpringArm3D/ThirdPersonCamera
@onready var aim_ray: RayCast3D = $HeadPivot/AimRayCast3D
@onready var interaction_area: Area3D = $InteractionArea3D
@onready var weapon_mesh_fp: MeshInstance3D = $HeadPivot/WeaponMeshHolder/WeaponMesh
@onready var health_component: HealthComponent = $HealthComponent

var active_camera: Camera3D
var active_hand_slot: int = WeaponData.WeaponSlot.PRIMARY_FIREARM

var is_crouching: bool = false
var is_aiming: bool = false
var is_reloading: bool = false
var hud_move_vector: Vector2 = Vector2.ZERO
var hud_fire_held: bool = false

var current_noise_level: int = 1
var shot_noise_override_level: int = 0
var shot_noise_timer: float = 0.0
var continuous_noise_broadcast_timer: float = 0.0

var current_mag_ammo: int = 30
var reserve_ammo: int = 90
var fire_cooldown_timer: float = 0.0
var reload_timer: float = 0.0

var current_interact_target: Node = null
var interaction_refresh_timer: float = 0.0
var last_interaction_prompt: String = ""


func _ready() -> void:
	add_to_group("player")
	# SpringArm не должен цепляться за собственную капсулу игрока.
	if spring_arm != null:
		spring_arm.add_excluded_object(self.get_rid())
	_ensure_default_weapons()
	_sync_equipment_from_game_state()
	_setup_camera_mode()
	_setup_interaction_signals()
	GameState.equipment_changed.connect(_sync_equipment_from_game_state)
	GameState.inventory_changed.connect(_sync_ammo_from_inventory)
	_sync_ammo_from_inventory()
	_update_weapon_state_ui()
	_recalculate_noise_level(true)


func _unhandled_input(event: InputEvent) -> void:
	# Пока игрок в машине, его физика и ввод отключены — не перехватываем управление.
	if not is_physics_processing():
		return

	if event is InputEventMouseMotion and Input.get_mouse_mode() == Input.MOUSE_MODE_CAPTURED:
		var mouse_motion: InputEventMouseMotion = event as InputEventMouseMotion
		rotate_camera_look(mouse_motion.relative)

	if event.is_action_pressed("crouch"):
		toggle_crouch()
	elif event.is_action_pressed("aim"):
		set_aiming(not is_aiming)
	elif event.is_action_pressed("reload"):
		start_reload()
	elif event.is_action_pressed("switch_weapon"):
		switch_hand_weapon()
	elif event.is_action_pressed("interact"):
		trigger_context_interaction()
	elif event.is_action_pressed("open_backpack"):
		EventBus.request_open_backpack.emit()


func _physics_process(delta: float) -> void:
	_process_timers(delta)
	_process_movement(delta)
	_process_combat(delta)
	_recalculate_noise_level(false)
	_update_interaction_target(delta)


func _ensure_default_weapons() -> void:
	if primary_weapon == null:
		primary_weapon = GameState.get_item_data("ak74m") as WeaponData
	if secondary_weapon == null:
		secondary_weapon = GameState.get_item_data("combat_knife") as WeaponData
	if primary_weapon != null:
		current_mag_ammo = get_effective_magazine_capacity()


## Ёмкость магазина с учётом установленного обвеса магазина (+15 патронов)
func get_effective_magazine_capacity() -> int:
	if primary_weapon == null:
		return 0
	return primary_weapon.magazine_capacity + GameState.get_weapon_extra_mag_capacity()


## Синхронизирует надетую обувь (вкл. бесшумные сапоги), слоты оружия
## и установленный глушитель (5 слотов обвесов из Хаба) с GameState
func _sync_equipment_from_game_state() -> void:
	wearing_silent_boots = GameState.is_wearing_silent_boots()

	var p_id: Variant = GameState.equipped_items.get("primary_weapon", null)
	if p_id is String and not str(p_id).is_empty():
		var wpn: WeaponData = GameState.get_item_data(str(p_id)) as WeaponData
		if wpn != null:
			primary_weapon = wpn

	var s_id: Variant = GameState.equipped_items.get("secondary_weapon", null)
	if s_id is String and not str(s_id).is_empty():
		var melee: WeaponData = GameState.get_item_data(str(s_id)) as WeaponData
		if melee != null:
			secondary_weapon = melee

	var muzzle_id: Variant = GameState.weapon_attachments.get("muzzle", null)
	if muzzle_id is String and not str(muzzle_id).is_empty():
		equipped_muzzle_attachment = GameState.get_item_data(str(muzzle_id)) as AttachmentData
	else:
		equipped_muzzle_attachment = null

	current_mag_ammo = mini(current_mag_ammo, get_effective_magazine_capacity())
	_update_weapon_state_ui()
	_recalculate_noise_level(true)


func _sync_ammo_from_inventory() -> void:
	if primary_weapon == null:
		return
	var ammo_id: String = primary_weapon.ammo_item_id if not primary_weapon.ammo_item_id.is_empty() else "ammo_545"
	reserve_ammo = GameState.pockets_grid.count_item_by_id(ammo_id) + GameState.backpack_grid.count_item_by_id(ammo_id)
	EventBus.ammo_changed.emit(current_mag_ammo, get_effective_magazine_capacity(), reserve_ammo)


func _setup_camera_mode() -> void:
	if GameState.selected_camera_mode == GameState.CameraMode.FIRST_PERSON:
		first_person_camera.current = true
		third_person_camera.current = false
		active_camera = first_person_camera
		body_mesh.visible = false
	else:
		first_person_camera.current = false
		third_person_camera.current = true
		active_camera = third_person_camera
		body_mesh.visible = true


func _setup_interaction_signals() -> void:
	interaction_area.area_entered.connect(_on_interaction_candidate_entered)
	interaction_area.area_exited.connect(_on_interaction_candidate_exited)
	interaction_area.body_entered.connect(_on_interaction_candidate_entered)
	interaction_area.body_exited.connect(_on_interaction_candidate_exited)


func rotate_camera_look(screen_delta: Vector2) -> void:
	var sens: float = Balance.data.touch_look_sensitivity
	if is_aiming:
		sens *= 0.65
	rotate_y(-screen_delta.x * sens)
	head_pivot.rotate_x(-screen_delta.y * sens)
	head_pivot.rotation.x = clampf(head_pivot.rotation.x, deg_to_rad(-75.0), deg_to_rad(75.0))


func set_hud_move_vector(vec: Vector2) -> void:
	hud_move_vector = vec


func set_hud_fire_pressed(pressed: bool) -> void:
	hud_fire_held = pressed


func _process_timers(delta: float) -> void:
	if fire_cooldown_timer > 0.0:
		fire_cooldown_timer = maxf(0.0, fire_cooldown_timer - delta)

	if shot_noise_timer > 0.0:
		shot_noise_timer -= delta
		if shot_noise_timer <= 0.0:
			shot_noise_override_level = 0
			_recalculate_noise_level(true)

	if is_reloading:
		reload_timer -= delta
		if reload_timer <= 0.0:
			_finish_reload()


func _process_movement(delta: float) -> void:
	var has_fracture: bool = health_component != null and health_component.has_fracture
	var speed_mult: float = health_component.speed_buff_multiplier if health_component != null else 1.0

	if not is_on_floor():
		velocity.y -= GRAVITY * delta
	elif Input.is_action_just_pressed("jump") and not is_crouching and not has_fracture:
		velocity.y = JUMP_VELOCITY

	var kb_input: Vector2 = Input.get_vector("move_left", "move_right", "move_forward", "move_back")
	var combined_input: Vector2 = hud_move_vector if hud_move_vector.length_squared() > 0.001 else kb_input
	var input_len: float = clampf(combined_input.length(), 0.0, 1.0)

	var wants_run: bool = false
	if combined_input.y <= -Balance.data.joystick_run_threshold and input_len >= Balance.data.joystick_run_threshold:
		wants_run = true
	if kb_input.length_squared() > 0.1 and Input.is_key_pressed(KEY_SHIFT):
		wants_run = true

	# При переломе бег строго запрещён
	if has_fracture or is_aiming:
		wants_run = false
	if wants_run and is_crouching:
		_apply_crouch_state(false)

	var target_speed: float = Balance.data.walk_speed
	if is_crouching:
		target_speed = Balance.data.crouch_speed
	elif wants_run:
		target_speed = Balance.data.run_speed

	if has_fracture:
		target_speed *= Balance.data.fracture_walk_multiplier
	target_speed *= speed_mult

	var move_dir: Vector3 = (transform.basis * Vector3(combined_input.x, 0.0, combined_input.y)).normalized()
	if input_len > 0.05:
		velocity.x = move_dir.x * target_speed * input_len
		velocity.z = move_dir.z * target_speed * input_len
	else:
		velocity.x = move_toward(velocity.x, 0.0, target_speed * 10.0 * delta)
		velocity.z = move_toward(velocity.z, 0.0, target_speed * 10.0 * delta)

	move_and_slide()

	continuous_noise_broadcast_timer -= delta
	if continuous_noise_broadcast_timer <= 0.0:
		continuous_noise_broadcast_timer = 0.25
		var radius: float = Balance.data.get_noise_radius(current_noise_level)
		if radius > 0.0:
			EventBus.noise_emitted.emit(global_position, current_noise_level, radius)


func _recalculate_noise_level(force_emit: bool) -> void:
	var horizontal_speed: float = Vector2(velocity.x, velocity.z).length()
	var movement_level: int = 1

	if horizontal_speed > 0.25:
		if is_crouching:
			movement_level = 1
		elif horizontal_speed > Balance.data.walk_speed + 0.6:
			movement_level = 2 if wearing_silent_boots else 3
		else:
			movement_level = 1 if wearing_silent_boots else 2

	var final_level: int = maxi(movement_level, shot_noise_override_level)
	if final_level != current_noise_level or force_emit:
		current_noise_level = final_level
		var radius: float = Balance.data.get_noise_radius(current_noise_level)
		EventBus.player_noise_level_changed.emit(current_noise_level, radius)


func toggle_crouch() -> void:
	_apply_crouch_state(not is_crouching)


func _apply_crouch_state(crouch_enabled: bool) -> void:
	is_crouching = crouch_enabled
	var shape: CapsuleShape3D = collision_shape.shape as CapsuleShape3D
	if shape != null:
		shape.height = CROUCH_HEIGHT if is_crouching else STAND_HEIGHT
	collision_shape.position.y = (CROUCH_HEIGHT if is_crouching else STAND_HEIGHT) * 0.5
	head_pivot.position.y = 0.95 if is_crouching else 1.55
	_recalculate_noise_level(true)


func set_aiming(aim_enabled: bool) -> void:
	is_aiming = aim_enabled
	if active_camera != null:
		active_camera.fov = AIM_FOV if is_aiming else NORMAL_FOV


func switch_hand_weapon() -> void:
	if is_reloading:
		is_reloading = false
	if active_hand_slot == WeaponData.WeaponSlot.PRIMARY_FIREARM:
		active_hand_slot = WeaponData.WeaponSlot.SECONDARY_MELEE
	else:
		active_hand_slot = WeaponData.WeaponSlot.PRIMARY_FIREARM
	_update_weapon_state_ui()


func get_active_weapon() -> WeaponData:
	if active_hand_slot == WeaponData.WeaponSlot.PRIMARY_FIREARM:
		return primary_weapon
	return secondary_weapon


func _update_weapon_state_ui() -> void:
	var active_wpn: WeaponData = get_active_weapon()
	if weapon_mesh_fp != null:
		var box: BoxMesh = weapon_mesh_fp.mesh as BoxMesh
		if box != null:
			if active_hand_slot == WeaponData.WeaponSlot.PRIMARY_FIREARM:
				box.size = Vector3(0.08, 0.12, 0.65)
			else:
				box.size = Vector3(0.04, 0.06, 0.28)
	EventBus.active_weapon_slot_changed.emit(active_hand_slot, active_wpn)
	if primary_weapon != null:
		EventBus.ammo_changed.emit(current_mag_ammo, get_effective_magazine_capacity(), reserve_ammo)


func _process_combat(_delta: float) -> void:
	var wants_fire: bool = hud_fire_held or Input.is_action_pressed("fire")
	if wants_fire and fire_cooldown_timer <= 0.0 and not is_reloading:
		perform_attack()


func perform_attack() -> void:
	var wpn: WeaponData = get_active_weapon()
	if wpn == null:
		return

	if active_hand_slot == WeaponData.WeaponSlot.PRIMARY_FIREARM:
		if current_mag_ammo <= 0:
			start_reload()
			return
		current_mag_ammo -= 1
		EventBus.ammo_changed.emit(current_mag_ammo, get_effective_magazine_capacity(), reserve_ammo)
		_emit_firearm_shot_noise()
	else:
		var melee_level: int = Balance.data.melee_strike_noise_level
		var melee_radius: float = Balance.data.get_noise_radius(melee_level)
		EventBus.noise_emitted.emit(global_position, melee_level, melee_radius)

	fire_cooldown_timer = 1.0 / maxf(0.5, wpn.fire_rate_rps)

	aim_ray.target_position = Vector3(0.0, 0.0, -wpn.range_meters)
	var spread_deg: float = wpn.base_spread_deg * (0.35 if is_aiming else 1.0)
	if equipped_muzzle_attachment != null:
		spread_deg *= equipped_muzzle_attachment.spread_multiplier

	aim_ray.rotation_degrees = Vector3(
		randf_range(-spread_deg, spread_deg),
		randf_range(-spread_deg, spread_deg),
		0.0
	)
	aim_ray.force_raycast_update()

	if aim_ray.is_colliding():
		var collider: Object = aim_ray.get_collider()
		if collider != null and collider.has_method("apply_damage"):
			var str_mult: float = health_component.strength_buff_multiplier if health_component != null else 1.0
			var final_damage: float = wpn.damage * (str_mult if active_hand_slot == WeaponData.WeaponSlot.SECONDARY_MELEE else 1.0)
			collider.call("apply_damage", final_damage, global_position)


func _emit_firearm_shot_noise() -> void:
	var has_suppressor: bool = equipped_muzzle_attachment != null and equipped_muzzle_attachment.is_suppressor
	var shot_level: int = 2
	if not has_suppressor:
		shot_level = 3 if randf() < Balance.data.unmuffled_shot_quiet_chance else 4

	shot_noise_override_level = shot_level
	shot_noise_timer = Balance.data.shot_noise_duration_sec
	_recalculate_noise_level(true)

	var radius: float = Balance.data.get_noise_radius(shot_level)
	EventBus.noise_emitted.emit(global_position, shot_level, radius)


func start_reload() -> void:
	if active_hand_slot != WeaponData.WeaponSlot.PRIMARY_FIREARM or primary_weapon == null:
		return
	_sync_ammo_from_inventory()
	if is_reloading or current_mag_ammo >= get_effective_magazine_capacity() or reserve_ammo <= 0:
		return
	is_reloading = true
	reload_timer = primary_weapon.reload_time_sec


func _finish_reload() -> void:
	is_reloading = false
	if primary_weapon == null:
		return
	var ammo_id: String = primary_weapon.ammo_item_id if not primary_weapon.ammo_item_id.is_empty() else "ammo_545"
	var needed: int = get_effective_magazine_capacity() - current_mag_ammo
	var taken_from_pockets: int = GameState.pockets_grid.consume_item_by_id(ammo_id, needed)
	var still_needed: int = needed - taken_from_pockets
	var taken_from_bp: int = 0
	if still_needed > 0:
		taken_from_bp = GameState.backpack_grid.consume_item_by_id(ammo_id, still_needed)
	current_mag_ammo += taken_from_pockets + taken_from_bp
	_sync_ammo_from_inventory()


func receive_attack_damage(amount: float, bleed_roll: bool, fracture_roll: bool, infect_roll: bool) -> void:
	if health_component != null:
		health_component.apply_damage_and_injuries(amount, bleed_roll, fracture_roll, infect_roll)


func use_medical_item(item_data: ItemData) -> bool:
	if health_component != null:
		return health_component.use_consumable_item(item_data)
	return false


func trigger_context_interaction() -> void:
	if current_interact_target == null or not is_instance_valid(current_interact_target):
		return
	if current_interact_target.has_method("interact"):
		current_interact_target.call("interact", self)


func _on_interaction_candidate_entered(_node: Node) -> void:
	# Не полагаемся на сам факт входа в Area3D: труп зомби появляется
	# внутри уже пересекающейся области, и отдельного area_entered может не быть.
	interaction_refresh_timer = 0.0


func _on_interaction_candidate_exited(_node: Node) -> void:
	interaction_refresh_timer = 0.0


## Периодически выбирает ближайшую цель с непустым подсказкой взаимодействия.
## Это чинит два случая: живой зомби больше не показывает «Обыскать»,
## а у убитого кнопка появляется сразу после смерти.
func _update_interaction_target(delta: float) -> void:
	interaction_refresh_timer = maxf(0.0, interaction_refresh_timer - delta)
	if interaction_refresh_timer > 0.0:
		return
	interaction_refresh_timer = INTERACTION_REFRESH_INTERVAL

	var best_target: Node = null
	var best_distance: float = INF
	var candidates: Array[Node] = []
	for body in interaction_area.get_overlapping_bodies():
		candidates.append(body)
	for area in interaction_area.get_overlapping_areas():
		candidates.append(area)

	for candidate in candidates:
		var target: Node = _resolve_interaction_target(candidate)
		if target == null:
			continue
		var prompt: String = str(target.call("get_interaction_prompt"))
		if prompt.is_empty():
			continue
		var target_3d: Node3D = target as Node3D
		var distance: float = INF
		if target_3d != null:
			distance = global_position.distance_squared_to(target_3d.global_position)
		if distance < best_distance:
			best_distance = distance
			best_target = target

	_apply_interaction_target(best_target)


func _resolve_interaction_target(node: Node) -> Node:
	if node == null:
		return null
	if node.has_method("get_interaction_prompt"):
		return node
	var parent: Node = node.get_parent()
	if parent != null and parent.has_method("get_interaction_prompt"):
		return parent
	return null


func _apply_interaction_target(target: Node) -> void:
	var prompt: String = ""
	if target != null:
		prompt = str(target.call("get_interaction_prompt"))
	if target == current_interact_target and prompt == last_interaction_prompt:
		return

	if target == null or prompt.is_empty():
		if current_interact_target != null or not last_interaction_prompt.is_empty():
			current_interact_target = null
			last_interaction_prompt = ""
			EventBus.interaction_cleared.emit()
		return

	current_interact_target = target
	last_interaction_prompt = prompt
	EventBus.interaction_available.emit(prompt, target)