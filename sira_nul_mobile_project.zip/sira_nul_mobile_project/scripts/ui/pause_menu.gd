extends CanvasLayer
## Меню паузы (Этап 1).
## Работает в любом сцене, куда добавлено. Никаких чисел баланса не меняет.
## Громкость — это настройка устройства (AudioServer), а не игровые данные.

const HUB_SCENE_PATH: String = "res://scenes/hub/hub_scene.tscn"
const SETTINGS_PATH: String = "user://settings.cfg"

@onready var pause_button: Button = $PauseButton
@onready var dim_overlay: ColorRect = $DimOverlay
@onready var resume_button: Button = $DimOverlay/Center/PanelContainer/VBox/ResumeButton
@onready var volume_label: Label = $DimOverlay/Center/PanelContainer/VBox/VolumeLabel
@onready var volume_slider: HSlider = $DimOverlay/Center/PanelContainer/VBox/VolumeSlider
@onready var hub_button: Button = $DimOverlay/Center/PanelContainer/VBox/HubButton

var is_paused: bool = false
## Режим курсора до открытия меню: возвращаем его при закрытии,
## чтобы на ПК курсор не исчезал самовольно после паузы.
var mouse_mode_before_pause: Input.MouseMode = Input.MOUSE_MODE_VISIBLE


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS

	pause_button.pressed.connect(open_menu)
	resume_button.pressed.connect(close_menu)
	hub_button.pressed.connect(_return_to_hub)
	volume_slider.value_changed.connect(_on_volume_changed)

	volume_slider.set_value_no_signal(_load_volume())
	_on_volume_changed(volume_slider.value)

	_close_visuals()
	# В Хабе кнопка паузы не нужна — меню там только для настроек.
	pause_button.visible = GameState.is_in_raid


func _unhandled_input(event: InputEvent) -> void:
	if not event.is_action_pressed("pause"):
		return
	if is_paused:
		close_menu()
	else:
		open_menu()
	get_viewport().set_input_as_handled()


func open_menu() -> void:
	if is_paused:
		return
	is_paused = true
	mouse_mode_before_pause = Input.get_mouse_mode()
	dim_overlay.visible = true
	get_tree().paused = true
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


func close_menu() -> void:
	if not is_paused:
		_close_visuals()
		return
	is_paused = false
	_close_visuals()
	get_tree().paused = false
	if GameState.is_in_raid:
		Input.set_mouse_mode(mouse_mode_before_pause)
	else:
		Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)


func _close_visuals() -> void:
	dim_overlay.visible = false


func _on_volume_changed(value: float) -> void:
	var master_index: int = AudioServer.get_bus_index("Master")
	AudioServer.set_bus_volume_db(master_index, linear_to_db(maxf(value, 0.0001)))
	AudioServer.set_bus_mute(master_index, value <= 0.001)
	_update_volume_label(value)
	_save_volume(value)


func _load_volume() -> float:
	var config := ConfigFile.new()
	if config.load(SETTINGS_PATH) == OK:
		return clampf(float(config.get_value("audio", "master_volume", 1.0)), 0.0, 1.0)
	return 1.0


func _save_volume(value: float) -> void:
	var config := ConfigFile.new()
	config.set_value("audio", "master_volume", value)
	config.save(SETTINGS_PATH)


func _update_volume_label(value: float) -> void:
	volume_label.text = "Громкость: %d%%" % roundi(value * 100.0)


func _return_to_hub() -> void:
	# Покидая рейд через паузу, игрок ничего не выносит: рейд считается прерванным.
	GameState.is_in_raid = false
	GameState.is_camera_locked_for_raid = false
	get_tree().paused = false
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	get_tree().change_scene_to_file(HUB_SCENE_PATH)
