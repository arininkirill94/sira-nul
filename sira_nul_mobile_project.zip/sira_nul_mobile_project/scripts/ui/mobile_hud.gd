class_name MobileHUD
extends CanvasLayer
## Горизонтальный мобильный HUD (Этап 3: контекстные кнопки взлома/посадки/багажника/эвакуации,
## педали вождения авто, полоска прочности машины, баннер 15-сек сирены и мини-игра QTE взлома замка).
## Проверка попадания QTE сравнивает координаты строго в пикселях внутри TrackBar.

const JOYSTICK_MAX_RADIUS: float = 75.0
const INVENTORY_MODAL_SCENE: PackedScene = preload("res://scenes/ui/inventory_modal.tscn")

@onready var infection_vignette: ColorRect = $RootControl/InfectionVignette

@onready var noise_bar_1: ColorRect = $RootControl/TopLeftNoise/BarsContainer/Bar1
@onready var noise_bar_2: ColorRect = $RootControl/TopLeftNoise/BarsContainer/Bar2
@onready var noise_bar_3: ColorRect = $RootControl/TopLeftNoise/BarsContainer/Bar3
@onready var noise_bar_4: ColorRect = $RootControl/TopLeftNoise/BarsContainer/Bar4
@onready var noise_label: Label = $RootControl/TopLeftNoise/NoiseRadiusLabel

@onready var raid_timer_label: Label = $RootControl/TopCenterTimer/TimerLabel
@onready var extraction_banner: PanelContainer = $RootControl/ExtractionBanner
@onready var extraction_label: Label = $RootControl/ExtractionBanner/ExtractionLabel

@onready var hp_bar: ProgressBar = $RootControl/TopRightCluster/HPBar
@onready var hp_value_label: Label = $RootControl/TopRightCluster/HPBar/HPValueLabel
@onready var icon_bleed: ColorRect = $RootControl/TopRightCluster/InjuriesRow/BleedBadge
@onready var icon_fracture: ColorRect = $RootControl/TopRightCluster/InjuriesRow/FractureBadge
@onready var icon_infected: ColorRect = $RootControl/TopRightCluster/InjuriesRow/InfectedBadge
@onready var infected_label: Label = $RootControl/TopRightCluster/InjuriesRow/InfectedBadge/Label
@onready var backpack_button: Button = $RootControl/TopRightCluster/BackpackButton
@onready var status_timers_label: Label = $RootControl/TopRightCluster/StatusTimersLabel
@onready var vehicle_hp_bar: ProgressBar = $RootControl/TopRightCluster/VehicleHPBar
@onready var vehicle_hp_label: Label = $RootControl/TopRightCluster/VehicleHPBar/VehicleHPLabel

@onready var joystick_touch_zone: Control = $RootControl/JoystickTouchZone
@onready var joystick_base: Control = $RootControl/JoystickTouchZone/JoystickBase
@onready var joystick_knob: ColorRect = $RootControl/JoystickTouchZone/JoystickBase/JoystickKnob

@onready var crouch_button: Button = $RootControl/BottomRightCluster/CrouchButton
@onready var fire_button: Button = $RootControl/BottomRightCluster/FireButton
@onready var aim_button: Button = $RootControl/BottomRightCluster/AimButton
@onready var reload_button: Button = $RootControl/BottomRightCluster/ReloadButton
@onready var switch_hand_button: Button = $RootControl/BottomRightCluster/SwitchHandButton
@onready var context_action_button: Button = $RootControl/BottomRightCluster/ContextActionButton
@onready var trunk_button: Button = $RootControl/BottomRightCluster/TrunkButton
@onready var weapon_info_label: Label = $RootControl/BottomRightCluster/WeaponInfoLabel

# Блок педалей автомобиля (активен, когда игрок за рулём)
@onready var vehicle_controls_cluster: Control = $RootControl/VehicleControlsCluster
@onready var gas_button: Button = $RootControl/VehicleControlsCluster/GasButton
@onready var reverse_brake_button: Button = $RootControl/VehicleControlsCluster/ReverseBrakeButton
@onready var exit_vehicle_button: Button = $RootControl/VehicleControlsCluster/ExitVehicleButton

# Панель QTE взлома автомобиля (палочка + зона успеха, Space или кнопка «ВЗЛОМАТЬ!»)
@onready var qte_panel: PanelContainer = $RootControl/LockpickQTEPanel
@onready var qte_track: ColorRect = $RootControl/LockpickQTEPanel/VBox/TrackBar
@onready var qte_target_zone: ColorRect = $RootControl/LockpickQTEPanel/VBox/TrackBar/TargetZone
@onready var qte_cursor: ColorRect = $RootControl/LockpickQTEPanel/VBox/TrackBar/CursorBar
@onready var qte_hit_button: Button = $RootControl/LockpickQTEPanel/VBox/HitButton

var joystick_touch_idx: int = -1
var look_touch_idx: int = -1
var joystick_origin: Vector2 = Vector2.ZERO
var default_joystick_pos: Vector2 = Vector2(140.0, 760.0)

var current_cure_left: float = 0.0
var current_buff_tier: int = 0
var current_buff_left: float = 0.0

var active_vehicle: RaidVehicle = null
var nearby_trunk_vehicle: RaidVehicle = null
var inventory_modal_instance: InventoryModal = null

# QTE взлома
var qte_active: bool = false
var qte_target_vehicle: RaidVehicle = null
var qte_cursor_norm: float = 0.0
var qte_dir: float = 1.0


func _ready() -> void:
	default_joystick_pos = joystick_base.position
	context_action_button.visible = false
	trunk_button.visible = false
	infection_vignette.visible = false
	vehicle_hp_bar.visible = false
	vehicle_controls_cluster.visible = false
	extraction_banner.visible = false
	qte_panel.visible = false

	if INVENTORY_MODAL_SCENE != null:
		inventory_modal_instance = INVENTORY_MODAL_SCENE.instantiate() as InventoryModal
		add_child(inventory_modal_instance)

	EventBus.player_noise_level_changed.connect(_on_noise_level_changed)
	EventBus.raid_timer_updated.connect(_on_raid_timer_updated)
	EventBus.player_health_changed.connect(_on_player_health_changed)
	EventBus.player_status_changed.connect(_on_player_status_changed)
	EventBus.player_buff_changed.connect(_on_player_buff_changed)
	EventBus.active_weapon_slot_changed.connect(_on_active_weapon_changed)
	EventBus.ammo_changed.connect(_on_ammo_changed)
	EventBus.interaction_available.connect(_on_interaction_available)
	EventBus.interaction_cleared.connect(_on_interaction_cleared)

	EventBus.request_start_lockpick_qte.connect(_on_start_lockpick_qte)
	EventBus.player_entered_vehicle.connect(_on_player_entered_vehicle)
	EventBus.player_exited_vehicle.connect(_on_player_exited_vehicle)
	EventBus.vehicle_durability_changed.connect(_on_vehicle_durability_changed)
	EventBus.trunk_access_changed.connect(_on_trunk_access_changed)

	EventBus.extraction_started.connect(_on_extraction_started)
	EventBus.extraction_progress.connect(_on_extraction_progress)
	EventBus.extraction_cancelled.connect(_on_extraction_cancelled)

	crouch_button.pressed.connect(_on_crouch_pressed)
	fire_button.button_down.connect(_on_fire_down)
	fire_button.button_up.connect(_on_fire_up)
	aim_button.pressed.connect(_on_aim_pressed)
	reload_button.pressed.connect(_on_reload_pressed)
	switch_hand_button.pressed.connect(_on_switch_hand_pressed)
	context_action_button.pressed.connect(_on_context_action_pressed)
	trunk_button.pressed.connect(_on_trunk_button_pressed)
	backpack_button.pressed.connect(_on_backpack_pressed)

	gas_button.button_down.connect(func() -> void: _set_vehicle_throttle(1.0))
	gas_button.button_up.connect(func() -> void: _set_vehicle_throttle(0.0))
	reverse_brake_button.button_down.connect(func() -> void: _set_vehicle_throttle(-0.8))
	reverse_brake_button.button_up.connect(func() -> void: _set_vehicle_throttle(0.0))
	exit_vehicle_button.pressed.connect(_on_exit_vehicle_pressed)
	qte_hit_button.pressed.connect(_evaluate_qte_hit)

	_on_noise_level_changed(1, 0.0)
	_on_raid_timer_updated(Balance.data.raid_duration_sec)
	_on_player_status_changed(false, false, false, 0.0)


func _process(delta: float) -> void:
	if not qte_active:
		return
	qte_cursor_norm += qte_dir * Balance.data.qte_cursor_speed * delta
	if qte_cursor_norm >= 1.0:
		qte_cursor_norm = 1.0
		qte_dir = -1.0
	elif qte_cursor_norm <= 0.0:
		qte_cursor_norm = 0.0
		qte_dir = 1.0

	var track_w: float = maxf(qte_track.size.x, qte_track.custom_minimum_size.x)
	var cursor_w: float = maxf(10.0, qte_cursor.size.x)
	qte_cursor.position.x = qte_cursor_norm * (track_w - cursor_w)

	if Input.is_action_just_pressed("jump") or Input.is_action_just_pressed("qte_action"):
		get_viewport().set_input_as_handled()
		_evaluate_qte_hit()


func _input(event: InputEvent) -> void:
	if (inventory_modal_instance != null and inventory_modal_instance.visible) or qte_active:
		return

	var viewport_size: Vector2 = get_viewport().get_visible_rect().size

	if event is InputEventScreenTouch:
		var touch: InputEventScreenTouch = event as InputEventScreenTouch
		if touch.pressed:
			if joystick_touch_idx == -1 and touch.position.x < viewport_size.x * 0.45 and touch.position.y > viewport_size.y * 0.35:
				joystick_touch_idx = touch.index
				joystick_origin = touch.position
				joystick_base.global_position = touch.position - joystick_base.size * 0.5
				joystick_knob.position = (joystick_base.size - joystick_knob.size) * 0.5
			elif look_touch_idx == -1 and touch.position.x >= viewport_size.x * 0.45 and not _is_point_on_any_button(touch.position):
				look_touch_idx = touch.index
		else:
			if touch.index == joystick_touch_idx:
				joystick_touch_idx = -1
				joystick_base.position = default_joystick_pos
				joystick_knob.position = (joystick_base.size - joystick_knob.size) * 0.5
				_send_move_vector_to_player(Vector2.ZERO)
			elif touch.index == look_touch_idx:
				look_touch_idx = -1

	elif event is InputEventScreenDrag:
		var drag: InputEventScreenDrag = event as InputEventScreenDrag
		if drag.index == joystick_touch_idx:
			var offset: Vector2 = drag.position - joystick_origin
			var clamped_offset: Vector2 = offset.limit_length(JOYSTICK_MAX_RADIUS)
			joystick_knob.position = (joystick_base.size - joystick_knob.size) * 0.5 + clamped_offset
			var normalized_vec: Vector2 = clamped_offset / JOYSTICK_MAX_RADIUS
			_send_move_vector_to_player(normalized_vec)
		elif drag.index == look_touch_idx:
			var player: Player = _get_player()
			if player != null and active_vehicle == null:
				player.rotate_camera_look(drag.relative)


func _is_point_on_any_button(screen_pos: Vector2) -> bool:
	var buttons: Array[Control] = [
		crouch_button,
		fire_button,
		aim_button,
		reload_button,
		switch_hand_button,
		context_action_button,
		trunk_button,
		backpack_button,
		gas_button,
		reverse_brake_button,
		exit_vehicle_button
	]
	for btn in buttons:
		if btn != null and btn.is_visible_in_tree() and btn.get_global_rect().has_point(screen_pos):
			return true
	return false


func _get_player() -> Player:
	return get_tree().get_first_node_in_group("player") as Player


func _send_move_vector_to_player(vec: Vector2) -> void:
	if active_vehicle != null and is_instance_valid(active_vehicle):
		active_vehicle.hud_steer_input = -vec.x
		return
	var player: Player = _get_player()
	if player != null:
		player.set_hud_move_vector(vec)


func _set_vehicle_throttle(val: float) -> void:
	if active_vehicle != null and is_instance_valid(active_vehicle):
		active_vehicle.hud_throttle_input = val


# --- QTE взлома замка машины (проверка попадания в пикселях TrackBar) ---

func _on_start_lockpick_qte(vehicle_node: Node) -> void:
	var car: RaidVehicle = vehicle_node as RaidVehicle
	if car == null:
		return
	qte_target_vehicle = car
	qte_active = true
	qte_cursor_norm = 0.0
	qte_dir = 1.0

	qte_panel.visible = true
	var track_w: float = maxf(qte_track.size.x, qte_track.custom_minimum_size.x)
	var width_norm: float = clampf(Balance.data.qte_success_zone_width, 0.08, 0.35)
	var zone_start_norm: float = randf_range(0.25, 0.75 - width_norm)

	qte_target_zone.position.x = zone_start_norm * track_w
	qte_target_zone.size.x = width_norm * track_w
	qte_cursor.position.x = 0.0


func _evaluate_qte_hit() -> void:
	if not qte_active:
		return
	qte_active = false
	qte_panel.visible = false

	# Сравниваем строго в одной системе координат (пиксели внутри qte_track):
	var cursor_center: float = qte_cursor.position.x + qte_cursor.size.x * 0.5
	var green_left: float = qte_target_zone.position.x
	var green_right: float = qte_target_zone.position.x + qte_target_zone.size.x
	var is_hit: bool = (cursor_center >= green_left) and (cursor_center <= green_right)

	if qte_target_vehicle != null and is_instance_valid(qte_target_vehicle):
		# При попадании (0) открывается тихо; при промахе (1) включается сигнализация 33 м на 7 секунд
		qte_target_vehicle.attempt_lockpick(0 if is_hit else 1)
		EventBus.interaction_available.emit(qte_target_vehicle.get_interaction_prompt(), qte_target_vehicle)
	EventBus.lockpick_qte_finished.emit(qte_target_vehicle, is_hit)
	qte_target_vehicle = null


# --- Обработчики сигналов транспорта и эвакуации ---

func _on_player_entered_vehicle(vehicle_node: Node) -> void:
	active_vehicle = vehicle_node as RaidVehicle
	$RootControl/BottomRightCluster.visible = false
	vehicle_controls_cluster.visible = true
	vehicle_hp_bar.visible = true
	trunk_button.visible = false


func _on_player_exited_vehicle(_vehicle_node: Node) -> void:
	active_vehicle = null
	$RootControl/BottomRightCluster.visible = true
	vehicle_controls_cluster.visible = false
	vehicle_hp_bar.visible = false


func _on_vehicle_durability_changed(current_dur: float, max_dur: float) -> void:
	vehicle_hp_bar.max_value = max_dur
	vehicle_hp_bar.value = current_dur
	vehicle_hp_label.text = "АВТО: %d / %d" % [int(ceil(current_dur)), int(ceil(max_dur))]


func _on_trunk_access_changed(vehicle_node: Node, can_access: bool) -> void:
	if can_access and active_vehicle == null:
		nearby_trunk_vehicle = vehicle_node as RaidVehicle
		trunk_button.visible = true
	else:
		if nearby_trunk_vehicle == vehicle_node:
			nearby_trunk_vehicle = null
			trunk_button.visible = false


func _on_trunk_button_pressed() -> void:
	if nearby_trunk_vehicle != null and is_instance_valid(nearby_trunk_vehicle):
		nearby_trunk_vehicle.open_trunk_inventory()


func _on_exit_vehicle_pressed() -> void:
	if active_vehicle != null and is_instance_valid(active_vehicle):
		active_vehicle.exit_vehicle()


func _on_extraction_started(point_name: String, hold_seconds: float) -> void:
	extraction_banner.visible = true
	extraction_label.text = "СИРЕНА (%s): ПРОДЕРЖИТЕСЬ %.1f СЕК!" % [point_name, hold_seconds]


func _on_extraction_progress(seconds_left: float) -> void:
	extraction_banner.visible = true
	extraction_label.text = "СИРЕНА ЭВАКУАЦИИ (33 м): ОСТАЛОСЬ %.1f СЕК!" % seconds_left


func _on_extraction_cancelled() -> void:
	extraction_banner.visible = false


# --- Стандартные индикаторы HUD ---

func _on_noise_level_changed(level: int, radius: float) -> void:
	var active_color: Color = Color(0.88, 0.92, 0.88, 1.0)
	if level == 3:
		active_color = Color(0.95, 0.78, 0.25, 1.0)
	elif level >= 4:
		active_color = Color(0.95, 0.28, 0.25, 1.0)
	var inactive_color: Color = Color(0.25, 0.28, 0.26, 0.45)

	noise_bar_1.color = active_color if level >= 1 else inactive_color
	noise_bar_2.color = active_color if level >= 2 else inactive_color
	noise_bar_3.color = active_color if level >= 3 else inactive_color
	noise_bar_4.color = active_color if level >= 4 else inactive_color
	noise_label.text = "ШУМ: %d (%d м)" % [level, int(radius)]


func _on_raid_timer_updated(seconds_left: float) -> void:
	var total_sec: int = maxi(0, int(ceil(seconds_left)))
	raid_timer_label.text = "%02d:%02d" % [total_sec / 60, total_sec % 60]


func _on_player_health_changed(current_hp: float, effective_max_hp: float, base_max_hp: float) -> void:
	hp_bar.max_value = base_max_hp
	hp_bar.value = current_hp
	hp_value_label.text = "%d / %d ХП" % [int(ceil(current_hp)), int(ceil(effective_max_hp))]


func _on_player_status_changed(bleeding: bool, fracture: bool, infected: bool, cure_time_left: float) -> void:
	icon_bleed.modulate = Color(1.0, 1.0, 1.0, 1.0) if bleeding else Color(1.0, 1.0, 1.0, 0.2)
	icon_fracture.modulate = Color(1.0, 1.0, 1.0, 1.0) if fracture else Color(1.0, 1.0, 1.0, 0.2)
	icon_infected.modulate = Color(1.0, 1.0, 1.0, 1.0) if infected else Color(1.0, 1.0, 1.0, 0.2)
	infection_vignette.visible = infected

	current_cure_left = cure_time_left
	infected_label.text = ("ВИРУС %dс" % int(ceil(cure_time_left))) if (infected and cure_time_left > 0.0) else "ВИРУС"
	_update_status_timers_text()


func _on_player_buff_changed(buff_tier: int, time_left: float) -> void:
	current_buff_tier = buff_tier
	current_buff_left = time_left
	_update_status_timers_text()


func _update_status_timers_text() -> void:
	var parts: Array[String] = []
	if current_cure_left > 0.0:
		parts.append("Вывод вируса: %d с" % int(ceil(current_cure_left)))
	if current_buff_tier > 0 and current_buff_left > 0.0:
		parts.append("Инъектор Ур.%d: %d с" % [current_buff_tier, int(ceil(current_buff_left))])
	status_timers_label.text = " | ".join(parts)


func _on_active_weapon_changed(hand_slot: int, weapon_data: WeaponData) -> void:
	switch_hand_button.text = "РУКА 1: ОГНЕСТРЕЛ" if hand_slot == WeaponData.WeaponSlot.PRIMARY_FIREARM else "РУКА 2: ХОЛОДНОЕ"
	if weapon_data != null:
		weapon_info_label.text = weapon_data.display_name


func _on_ammo_changed(current_in_mag: int, magazine_capacity: int, reserve_ammo: int) -> void:
	var player: Player = _get_player()
	if player != null and player.active_hand_slot == WeaponData.WeaponSlot.SECONDARY_MELEE and player.secondary_weapon != null:
		weapon_info_label.text = "%s [БЛИЖНИЙ БОЙ]" % player.secondary_weapon.display_name
	else:
		weapon_info_label.text = "ПАТРОНЫ: %d / %d (Запас: %d)" % [current_in_mag, magazine_capacity, reserve_ammo]


func _on_interaction_available(prompt_text: String, _target_node: Node) -> void:
	context_action_button.text = prompt_text
	context_action_button.visible = true


func _on_interaction_cleared() -> void:
	context_action_button.visible = false


func _on_crouch_pressed() -> void:
	var player: Player = _get_player()
	if player != null:
		player.toggle_crouch()


func _on_fire_down() -> void:
	var player: Player = _get_player()
	if player != null:
		player.set_hud_fire_pressed(true)


func _on_fire_up() -> void:
	var player: Player = _get_player()
	if player != null:
		player.set_hud_fire_pressed(false)


func _on_aim_pressed() -> void:
	var player: Player = _get_player()
	if player != null:
		player.set_aiming(not player.is_aiming)


func _on_reload_pressed() -> void:
	var player: Player = _get_player()
	if player != null:
		player.start_reload()


func _on_switch_hand_pressed() -> void:
	var player: Player = _get_player()
	if player != null:
		player.switch_hand_weapon()


func _on_context_action_pressed() -> void:
	var player: Player = _get_player()
	if player != null:
		player.trigger_context_interaction()


func _on_backpack_pressed() -> void:
	EventBus.request_open_backpack.emit()