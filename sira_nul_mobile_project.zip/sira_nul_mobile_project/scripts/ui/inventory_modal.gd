class_name InventoryModal
extends CanvasLayer
## Горизонтальный сенсорный UI инвентаря (Этап 2):
## - Левая колонка: слоты персонажа (Голова, Руки, Торс, Ноги, Сапоги, Рюкзак + 1-я рука Огнестрел, 2-я рука Холодное)
## - Центральная колонка: Карманы (6x1), Защищённый страховой слот (2x2), Рюкзак (4x4..10x10)
## - Правая колонка: Обыскиваемый контейнер / Труп зомби / Единый Склад Хаба (12x30 со скроллом)
## - Верхняя панель действий: «ПОВЕРНУТЬ (90°)», «ИСПОЛЬЗОВАТЬ», «НАДЕТЬ В СЛОТ», «ЗАКРЫТЬ»

const CELL_PIXELS: int = 64

## Короткие подписи для клеток инвентаря. Полное название показывается
## в строке выбранного предмета, а в клетке — читаемое короткое имя.
const ITEM_SHORT_LABELS: Dictionary = {
	"ruble_pack_small": "Рубли",
	"ammo_545": "Патроны",
	"canned_food": "Консервы",
	"bandage": "Бинт",
	"tourniquet": "Жгут",
	"splint": "Шина",
	"painkiller": "Обезбол.",
	"antidote": "Антидот",
	"injector_buff": "Инъектор",
	"mutant_heart": "Сердце",
	"mutant_fingers": "Пальцы",
	"infected_crystal": "Кристалл",
	"lockpick": "Отмычка",
	"bumper_ram": "Отвал",
	"body_armor": "Броня",
	"engine_stock": "Двигатель",
	"tires_stock": "Шины",
	"exhaust_muffler": "Глушитель",
	"trunk_stock": "Багажник",
}

@onready var root_panel: PanelContainer = $RootControl/MainPanel
@onready var title_label: Label = $RootControl/MainPanel/Margin/MainVBox/HeaderBar/TitleLabel
@onready var selected_info_label: Label = $RootControl/MainPanel/Margin/MainVBox/HeaderBar/SelectedInfoLabel
@onready var rotate_button: Button = $RootControl/MainPanel/Margin/MainVBox/HeaderBar/RotateButton
@onready var use_button: Button = $RootControl/MainPanel/Margin/MainVBox/HeaderBar/UseButton
@onready var equip_button: Button = $RootControl/MainPanel/Margin/MainVBox/HeaderBar/EquipButton
@onready var close_button: Button = $RootControl/MainPanel/Margin/MainVBox/HeaderBar/CloseButton

@onready var equip_slots_vbox: VBoxContainer = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/EquipColumn/SlotsVBox
@onready var pockets_holder: Control = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/CenterColumn/PocketsHolder
@onready var safe_holder: Control = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/CenterColumn/SafeHolder
@onready var backpack_label: Label = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/CenterColumn/BackpackLabel
@onready var backpack_scroll: ScrollContainer = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/CenterColumn/BackpackScroll
@onready var backpack_holder: Control = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/CenterColumn/BackpackScroll/BackpackHolder

@onready var right_column: VBoxContainer = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/RightColumn
@onready var external_title_label: Label = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/RightColumn/ExternalTitleLabel
@onready var external_scroll: ScrollContainer = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/RightColumn/ExternalScroll
@onready var external_holder: Control = $RootControl/MainPanel/Margin/MainVBox/ColumnsHBox/RightColumn/ExternalScroll/ExternalHolder

var external_grid: InventoryGrid = null
var external_title: String = ""

# Выделенный предмет для переноса/поворота/использования тачем или мышью
var selected_source_grid: InventoryGrid = null
var selected_uid: int = -1
var pending_rotation: bool = false

const EQUIP_SLOTS_META: Array[Dictionary] = [
	{"key": "head", "label": "Голова"},
	{"key": "torso", "label": "Торс"},
	{"key": "hands", "label": "Руки"},
	{"key": "legs", "label": "Ноги"},
	{"key": "boots", "label": "Сапоги (Тихие)"},
	{"key": "backpack", "label": "Рюкзак"},
	{"key": "primary_weapon", "label": "1-я рука (Огнестрел)"},
	{"key": "secondary_weapon", "label": "2-я рука (Холодное)"}
]


func _ready() -> void:
	visible = false
	rotate_button.pressed.connect(_on_rotate_pressed)
	use_button.pressed.connect(_on_use_pressed)
	equip_button.pressed.connect(_on_equip_pressed)
	close_button.pressed.connect(close_modal)

	EventBus.request_open_backpack.connect(toggle_backpack_only)
	EventBus.request_open_loot_container.connect(open_with_container_node)
	GameState.inventory_changed.connect(_refresh_if_visible)
	GameState.equipment_changed.connect(_refresh_if_visible)


func toggle_backpack_only() -> void:
	if visible:
		close_modal()
	else:
		external_grid = null if GameState.is_in_raid else GameState.stash_grid
		external_title = "СКЛАД ХАБА (12x30)" if not GameState.is_in_raid else "ОКРУЖЕНИЕ"
		open_modal()


func open_with_container_node(container_node: Node) -> void:
	if container_node != null and container_node.has_method("get_loot_grid"):
		external_grid = container_node.call("get_loot_grid") as InventoryGrid
		external_title = str(container_node.call("get_container_title")) if container_node.has_method("get_container_title") else "ОБЫСК"
	open_modal()


func open_modal() -> void:
	visible = true
	Input.set_mouse_mode(Input.MOUSE_MODE_VISIBLE)
	_clear_selection()
	_rebuild_all_views()


func close_modal() -> void:
	visible = false
	external_grid = null
	_clear_selection()


func _refresh_if_visible() -> void:
	if visible:
		_rebuild_all_views()


func _clear_selection() -> void:
	selected_source_grid = null
	selected_uid = -1
	pending_rotation = false
	selected_info_label.text = "Выберите предмет тачем/мышью, затем нажмите на свободную клетку для переноса"


func _rebuild_all_views() -> void:
	_rebuild_equipment_buttons()
	_render_grid_into(GameState.pockets_grid, pockets_holder)
	_render_grid_into(GameState.safe_grid, safe_holder)

	var bp_size: Vector2i = Vector2i(GameState.backpack_grid.width, GameState.backpack_grid.height)
	backpack_label.text = "РЮКЗАК (%dx%d)" % [bp_size.x, bp_size.y]
	_render_grid_into(GameState.backpack_grid, backpack_holder)

	if external_grid != null:
		right_column.visible = true
		external_title_label.text = external_title
		_render_grid_into(external_grid, external_holder)
	else:
		right_column.visible = false


func _rebuild_equipment_buttons() -> void:
	for child in equip_slots_vbox.get_children():
		child.queue_free()

	for slot_info in EQUIP_SLOTS_META:
		var slot_key: String = str(slot_info["key"])
		var slot_label: String = str(slot_info["label"])
		var equipped_id: Variant = GameState.equipped_items.get(slot_key, null)
		var item_title: String = "Пусто"
		if equipped_id is String and not str(equipped_id).is_empty():
			var item_data: ItemData = GameState.get_item_data(str(equipped_id))
			item_title = item_data.display_name if item_data != null else str(equipped_id)

		var btn: Button = Button.new()
		btn.custom_minimum_size = Vector2(240, 42)
		btn.text = "%s: %s" % [slot_label, item_title]
		btn.pressed.connect(_on_equipment_slot_clicked.bind(slot_key))
		equip_slots_vbox.add_child(btn)


## Отрисовывает интерактивную сетку клеток и лежащие в ней предметы
func _render_grid_into(grid: InventoryGrid, holder: Control) -> void:
	for child in holder.get_children():
		child.queue_free()

	if grid == null:
		return

	var total_px: Vector2 = Vector2(grid.width * CELL_PIXELS, grid.height * CELL_PIXELS)
	holder.custom_minimum_size = total_px
	holder.size = total_px

	# 1. Клетки фона
	for y in range(grid.height):
		for x in range(grid.width):
			var cell_btn: Button = Button.new()
			cell_btn.position = Vector2(x * CELL_PIXELS, y * CELL_PIXELS)
			cell_btn.size = Vector2(CELL_PIXELS - 2, CELL_PIXELS - 2)
			cell_btn.text = ""
			cell_btn.pressed.connect(_on_grid_cell_pressed.bind(grid, Vector2i(x, y)))
			holder.add_child(cell_btn)

	# 2. Предметы поверх клеток
	for entry in grid.get_items():
		var uid: int = int(entry["uid"])
		var item_data: ItemData = entry["item_data"] as ItemData
		var pos: Vector2i = entry["pos"] as Vector2i
		var is_rot: bool = bool(entry["rotated"])
		var eff_size: Vector2i = InventoryGrid.get_effective_size(item_data, is_rot)
		var stack_cnt: int = int(entry["stack"])

		var item_rect: ColorRect = ColorRect.new()
		item_rect.position = Vector2(pos.x * CELL_PIXELS + 2, pos.y * CELL_PIXELS + 2)
		item_rect.size = Vector2(eff_size.x * CELL_PIXELS - 4, eff_size.y * CELL_PIXELS - 4)
		item_rect.mouse_filter = Control.MOUSE_FILTER_IGNORE

		var base_col: Color = item_data.placeholder_color if item_data != null else Color(0.4, 0.45, 0.4)
		if selected_source_grid == grid and selected_uid == uid:
			base_col = base_col.lightened(0.32)
		item_rect.color = base_col
		holder.add_child(item_rect)

		var lbl: Label = Label.new()
		lbl.set_anchors_preset(Control.PRESET_FULL_RECT)
		lbl.offset_left = 3.0
		lbl.offset_top = 2.0
		lbl.offset_right = -3.0
		lbl.offset_bottom = -2.0
		lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
		lbl.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
		lbl.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
		lbl.mouse_filter = Control.MOUSE_FILTER_IGNORE
		lbl.add_theme_font_size_override("font_size", 14)
		# Тёмный текст на светлых предметах и светлый на тёмных — иначе подписи сливаются.
		var text_color: Color = Color(0.07, 0.07, 0.07) if base_col.get_luminance() > 0.55 else Color(0.96, 0.96, 0.96)
		var outline_color: Color = Color(1.0, 1.0, 1.0, 0.45) if text_color.get_luminance() < 0.5 else Color(0.0, 0.0, 0.0, 0.45)
		lbl.add_theme_color_override("font_color", text_color)
		lbl.add_theme_color_override("font_outline_color", outline_color)
		lbl.add_theme_constant_override("outline_size", 2)
		var short_name: String = _get_item_short_label(item_data, str(entry["item_id"]))
		if stack_cnt > 1:
			short_name += " x%d" % stack_cnt
		if is_rot:
			short_name += "\n90°"
		lbl.text = short_name
		item_rect.add_child(lbl)


func _get_item_short_label(item_data: ItemData, item_id: String) -> String:
	if item_data != null and ITEM_SHORT_LABELS.has(item_data.id):
		return str(ITEM_SHORT_LABELS[item_data.id])
	if ITEM_SHORT_LABELS.has(item_id):
		return str(ITEM_SHORT_LABELS[item_id])
	if item_data != null:
		return item_data.display_name
	return item_id


func _on_grid_cell_pressed(target_grid: InventoryGrid, cell: Vector2i) -> void:
	var clicked_entry: Dictionary = target_grid.get_item_at_cell(cell)

	# Если ещё ничего не выбрано — выделяем предмет в этой клетке
	if selected_source_grid == null or selected_uid == -1:
		if not clicked_entry.is_empty():
			selected_source_grid = target_grid
			selected_uid = int(clicked_entry["uid"])
			pending_rotation = bool(clicked_entry["rotated"])
			var item_data: ItemData = clicked_entry["item_data"] as ItemData
			selected_info_label.text = "Выбрано: %s (%dx%d)" % [
				item_data.display_name,
				item_data.grid_size.x,
				item_data.grid_size.y
			]
			_rebuild_all_views()
		return

	# Если кликнули по тому же самому предмету — снимаем выделение
	if selected_source_grid == target_grid and not clicked_entry.is_empty() and int(clicked_entry["uid"]) == selected_uid:
		_clear_selection()
		_rebuild_all_views()
		return

	# Перемещение внутри одной сетки
	if selected_source_grid == target_grid:
		if target_grid.move_item(selected_uid, cell, pending_rotation):
			_clear_selection()
			_rebuild_all_views()
		return

	# Перенос между двумя разными сетками (например, из контейнера/трупа в рюкзак/страховой слот)
	var src_entry: Dictionary = selected_source_grid.get_item_by_uid(selected_uid)
	if src_entry.is_empty():
		_clear_selection()
		return

	var item_data: ItemData = src_entry["item_data"] as ItemData
	var stack_cnt: int = int(src_entry["stack"])
	var dur: float = float(src_entry["durability"])

	if target_grid.can_place(item_data, cell, pending_rotation):
		selected_source_grid.remove_item_by_uid(selected_uid)
		# Если игрок забрал пачку рублей в свой инвентарь — можно сразу начислить рубли или хранить пачкой
		target_grid.place_item(item_data, cell, pending_rotation, stack_cnt, dur)
		_clear_selection()
		_rebuild_all_views()


func _on_rotate_pressed() -> void:
	if selected_source_grid == null or selected_uid == -1:
		return
	if selected_source_grid.rotate_item_in_place(selected_uid):
		var entry: Dictionary = selected_source_grid.get_item_by_uid(selected_uid)
		pending_rotation = bool(entry.get("rotated", false))
	else:
		pending_rotation = not pending_rotation
	_rebuild_all_views()


func _on_use_pressed() -> void:
	if selected_source_grid == null or selected_uid == -1:
		return
	var entry: Dictionary = selected_source_grid.get_item_by_uid(selected_uid)
	if entry.is_empty():
		return
	var item_data: ItemData = entry["item_data"] as ItemData
	if item_data == null:
		return

	# Если это пачка рублей — зачисляем в баланс рублей
	if item_data.id == "ruble_pack_small" or item_data.id == "rubles_small_stack":
		GameState.rubles += item_data.base_price_rubles * int(entry["stack"])
		selected_source_grid.remove_item_by_uid(selected_uid)
		_clear_selection()
		_rebuild_all_views()
		return

	var player: Player = get_tree().get_first_node_in_group("player") as Player
	if player != null and player.use_medical_item(item_data):
		selected_source_grid.consume_from_uid(selected_uid, 1)
		_clear_selection()
		_rebuild_all_views()
	else:
		selected_info_label.text = "Предмет «%s» сейчас не требуется (нет соответствующих травм/урона)" % item_data.display_name


func _on_equip_pressed() -> void:
	if selected_source_grid == null or selected_uid == -1:
		return
	var entry: Dictionary = selected_source_grid.get_item_by_uid(selected_uid)
	if entry.is_empty():
		return
	var item_data: ItemData = entry["item_data"] as ItemData
	for slot_info in EQUIP_SLOTS_META:
		var slot_key: String = str(slot_info["key"])
		if GameState.can_equip_item_to_slot(item_data, slot_key):
			if GameState.equip_item_from_grid(selected_source_grid, selected_uid, slot_key):
				_clear_selection()
				_rebuild_all_views()
				return


func _on_equipment_slot_clicked(slot_key: String) -> void:
	# Если выбран подходящий предмет в сетке — надеваем его в этот слот
	if selected_source_grid != null and selected_uid != -1:
		if GameState.equip_item_from_grid(selected_source_grid, selected_uid, slot_key):
			_clear_selection()
			_rebuild_all_views()
			return
	# Иначе снимаем предмет из слота в рюкзак (или на Склад в Хабе)
	var fallback_grid: InventoryGrid = GameState.backpack_grid if GameState.is_in_raid else GameState.stash_grid
	GameState.unequip_slot_to_grid(slot_key, fallback_grid)
	_rebuild_all_views()