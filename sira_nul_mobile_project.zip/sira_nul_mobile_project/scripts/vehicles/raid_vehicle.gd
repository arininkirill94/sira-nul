class_name RaidVehicle
extends VehicleBody3D
## Автомобиль на узлах VehicleBody3D и 4 VehicleWheel3D (раздел 3.5 GDD):
## - Состояния: заперт (is_locked = true) / открыт (is_locked = false) / уничтожен (is_destroyed = true).
## - Взлом отмычкой: проверяет и списывает 1 lockpick, открывает машину; при срабатывании сигнализации
##   (или промахе в QTE) включает 4-й уровень шума (33 м) на 7 секунд.
## - 6 заменяемых узлов (VehiclePartData): Бампер/Таран, Броня кузова, Двигатель, Шины, Выхлопная система, Багажник.
## - Таран зомби: на скорости >= car_ram_min_speed_mps наносит урон зомби; без установленного отвала
##   двигатель/кузов получает урон car_ram_self_damage_no_bumper, с отвалом — 0 урона.
## - Багажник: отдельная клеточная сетка InventoryGrid (доступна снаружи через InventoryModal).
## - Передняя часть автомобиля ориентирована вдоль локальной оси -Z (стандарт Godot 4).
## - Взаимное исключение коллизий с игроком (add_collision_exception_with), ручной тормоз
##   и безопасная точка высадки слева от водительской двери.
## - SpringArm3D камеры не цепляется за собственный кузов и за игрока.

const EXIT_LOCAL_OFFSET: Vector3 = Vector3(-2.4, 0.6, 0.0)
const EXIT_COLLISION_GRACE_SEC: float = 1.2

@export var vehicle_title: String = "ВАЗ-2121 «Нива»"
@export var is_locked: bool = true

@onready var chassis_mesh: Node3D = $ChassisMesh
@onready var ram_bumper_visual: MeshInstance3D = $RamBumperVisual
@onready var wheel_fl: VehicleWheel3D = $WheelFL
@onready var wheel_fr: VehicleWheel3D = $WheelFR
@onready var wheel_rl: VehicleWheel3D = $WheelRL
@onready var wheel_rr: VehicleWheel3D = $WheelRR

@onready var driver_exit_marker: Marker3D = $DriverExitMarker
@onready var camera_pivot: Node3D = $CameraPivot
@onready var first_person_cam: Camera3D = $CameraPivot/FirstPersonCamera3D
@onready var spring_arm: SpringArm3D = $CameraPivot/SpringArm3D
@onready var third_person_cam: Camera3D = $CameraPivot/SpringArm3D/ThirdPersonCamera3D

@onready var interact_area: Area3D = $InteractArea3D
@onready var trunk_area: Area3D = $TrunkArea3D
@onready var ram_hitbox_area: Area3D = $RamHitboxArea3D
@onready var alarm_audio: AudioStreamPlayer3D = $AlarmAudio

## 6 слотов узлов автомобиля:
## "bumper_ram", "body_armor", "engine", "tires", "exhaust", "trunk"
var installed_parts: Dictionary = {
	"bumper_ram": null,
	"body_armor": null,
	"engine": "engine_stock",
	"tires": "tires_stock",
	"exhaust": null,
	"trunk": "trunk_stock"
}

var max_durability: float = 200.0
var current_durability: float = 200.0
var is_destroyed: bool = false

var driver_player: Player = null
var last_exited_player: Player = null
var exit_collision_grace_timer: float = 0.0
var trunk_grid: InventoryGrid

# Управление с HUD / клавиатуры
var hud_steer_input: float = 0.0
var hud_throttle_input: float = 0.0
var hud_brake_input: float = 0.0

# Таймеры сигнализации и шума двигателя
var alarm_timer: float = 0.0
var alarm_pulse_timer: float = 0.0
var engine_noise_timer: float = 0.0


func _ready() -> void:
	add_to_group("vehicles")
	max_durability = Balance.data.car_max_durability
	current_durability = max_durability

	# Камера 3-го лица не должна упираться в собственный кузов.
	if spring_arm != null:
		spring_arm.add_excluded_object(self.get_rid())

	if driver_exit_marker != null:
		driver_exit_marker.position = EXIT_LOCAL_OFFSET

	var trunk_sz: Vector2i = _get_configured_trunk_size()
	trunk_grid = InventoryGrid.new(trunk_sz.x, trunk_sz.y)
	_recalculate_vehicle_stats()

	ram_hitbox_area.body_entered.connect(_on_ram_hitbox_body_entered)
	trunk_area.body_entered.connect(_on_trunk_candidate_entered)
	trunk_area.body_exited.connect(_on_trunk_candidate_exited)

	# В проекте нет звуковых ассетов, поэтому сигнализация генерируется кодом.
	alarm_audio.stream = _build_alarm_stream()


func _physics_process(delta: float) -> void:
	_process_exit_collision_grace(delta)

	if is_destroyed:
		engine_force = 0.0
		brake = Balance.data.car_base_brake_force
		return

	_process_alarm(delta)

	if driver_player != null and is_instance_valid(driver_player):
		_process_driving_controls(delta)
		# Держим отключённого игрока в центре салона без физического контакта
		driver_player.global_position = to_global(Vector3(-0.4, 0.85, -0.15))
	else:
		engine_force = 0.0
		steering = move_toward(steering, 0.0, 2.5 * delta)
		brake = Balance.data.car_base_brake_force * 0.5


## Снимает временное исключение коллизий с игроком только после того,
## как он отошёл от кузова (защита от подбрасывания машины при высадке).
func _process_exit_collision_grace(delta: float) -> void:
	if last_exited_player != null and not is_instance_valid(last_exited_player):
		last_exited_player = null
		exit_collision_grace_timer = 0.0
		return
	if exit_collision_grace_timer <= 0.0:
		return

	exit_collision_grace_timer -= delta
	if exit_collision_grace_timer > 0.0:
		return

	if last_exited_player != null and global_position.distance_to(last_exited_player.global_position) > 2.0:
		last_exited_player.remove_collision_exception_with(self)
		remove_collision_exception_with(last_exited_player)
		last_exited_player = null
	else:
		exit_collision_grace_timer = 0.5


func _unhandled_input(event: InputEvent) -> void:
	if driver_player == null:
		return
	if event.is_action_pressed("interact"):
		exit_vehicle()


## Пересчитывает физические параметры VehicleBody3D и 4 VehicleWheel3D по установленным в 6 слотах деталям
func _recalculate_vehicle_stats() -> void:
	var friction: float = 1.6
	var tires_part: VehiclePartData = _get_part_data("tires")
	if tires_part != null:
		friction = tires_part.wheel_friction_slip

	for wheel in [wheel_fl, wheel_fr, wheel_rl, wheel_rr]:
		if wheel != null:
			wheel.wheel_friction_slip = friction

	var bumper_part: VehiclePartData = _get_part_data("bumper_ram")
	if ram_bumper_visual != null:
		ram_bumper_visual.visible = (bumper_part != null and bumper_part.negates_ram_engine_damage)

	var new_trunk_size: Vector2i = _get_configured_trunk_size()
	if trunk_grid != null and (trunk_grid.width != new_trunk_size.x or trunk_grid.height != new_trunk_size.y):
		trunk_grid.resize_grid(new_trunk_size.x, new_trunk_size.y)


func _get_part_data(slot_key: String) -> VehiclePartData:
	var part_id: Variant = installed_parts.get(slot_key, null)
	if part_id is String and not str(part_id).is_empty():
		return GameState.get_vehicle_part_data(str(part_id))
	return null


func _get_configured_trunk_size() -> Vector2i:
	var trunk_part: VehiclePartData = _get_part_data("trunk")
	if trunk_part != null and trunk_part.trunk_grid_size.x >= 2:
		return trunk_part.trunk_grid_size
	return Balance.data.car_default_trunk_grid


## Возвращает уровень шума при езде: сток = 4 палочки (33 м), с глушителем авто = 3 (16 м) или 2 (6 м)
func get_driving_noise_level() -> int:
	var exhaust_part: VehiclePartData = _get_part_data("exhaust")
	if exhaust_part != null:
		return clampi(exhaust_part.driving_noise_level, 2, 4)
	return 4


func has_ram_bumper() -> bool:
	var bumper_part: VehiclePartData = _get_part_data("bumper_ram")
	return bumper_part != null and bumper_part.negates_ram_engine_damage


func get_hull_armor_reduction() -> float:
	var armor_part: VehiclePartData = _get_part_data("body_armor")
	if armor_part != null:
		return clampf(armor_part.hull_armor_bonus / 100.0, 0.0, 0.75)
	return 0.0


func _process_driving_controls(delta: float) -> void:
	# Страховка: если тело всё-таки заснуло (например, после долгой стоянки),
	# любой ввод сразу будит его, иначе engine_force игнорируется физикой.
	if sleeping:
		sleeping = false

	var kb_steer: float = Input.get_axis("move_right", "move_left")
	var kb_throttle: float = Input.get_axis("move_back", "move_forward")

	var final_steer: float = hud_steer_input if absf(hud_steer_input) > 0.01 else kb_steer
	var final_throttle: float = hud_throttle_input if absf(hud_throttle_input) > 0.01 else kb_throttle

	var max_steer: float = Balance.data.car_max_steer_angle_rad
	steering = move_toward(steering, final_steer * max_steer, 2.8 * delta)

	var total_engine_force: float = Balance.data.car_base_engine_force
	var engine_part: VehiclePartData = _get_part_data("engine")
	if engine_part != null:
		total_engine_force += engine_part.engine_force_bonus

	var max_speed_mps: float = (engine_part.max_speed_kmh if engine_part != null else 65.0) / 3.6
	var current_speed_mps: float = linear_velocity.length()

	if hud_brake_input > 0.1:
		engine_force = 0.0
		brake = Balance.data.car_base_brake_force * hud_brake_input
	elif absf(final_throttle) > 0.05:
		brake = 0.0
		# Колёса в сцене развёрнуты по X/Z (Transform3D -1,-1), поэтому
		# положительный «газ» даёт положительный engine_force и едет вперёд по -Z.
		if current_speed_mps < max_speed_mps or signf(final_throttle) != signf(engine_force):
			engine_force = final_throttle * total_engine_force
		else:
			engine_force = 0.0
	else:
		engine_force = 0.0
		brake = Balance.data.car_base_brake_force * 0.25

	# Шум двигателя при езде
	engine_noise_timer -= delta
	if engine_noise_timer <= 0.0:
		engine_noise_timer = 0.3
		if current_speed_mps > 1.2 or absf(final_throttle) > 0.1:
			var lvl: int = get_driving_noise_level()
			var rad: float = Balance.data.get_noise_radius(lvl)
			EventBus.player_noise_level_changed.emit(lvl, rad)
			EventBus.noise_emitted.emit(global_position, lvl, rad)
		else:
			var idle_lvl: int = 2
			var idle_rad: float = Balance.data.get_noise_radius(idle_lvl)
			EventBus.player_noise_level_changed.emit(idle_lvl, idle_rad)


## Процедурный звук автосигнализации: двухтональный вой без внешних ассетов.
func _build_alarm_stream() -> AudioStreamWAV:
	var sample_rate: int = 22050
	var duration: float = 0.8
	var frames: int = int(sample_rate * duration)
	var data: PackedByteArray = PackedByteArray()
	data.resize(frames * 2)
	for i in range(frames):
		var t: float = float(i) / float(sample_rate)
		var freq: float = 880.0 if fmod(t, 0.4) < 0.2 else 660.0
		var sample: float = sin(TAU * freq * t) * 0.35
		data.encode_s16(i * 2, int(clampf(sample, -1.0, 1.0) * 32767.0))

	var stream: AudioStreamWAV = AudioStreamWAV.new()
	stream.format = AudioStreamWAV.FORMAT_16_BITS
	stream.mix_rate = sample_rate
	stream.stereo = false
	stream.data = data
	stream.loop_mode = AudioStreamWAV.LOOP_FORWARD
	stream.loop_begin = 0
	stream.loop_end = frames
	return stream


## Обработка штатной автосигнализации (4-я шкала шума — 33 м в течение 7 секунд)
func _process_alarm(delta: float) -> void:
	if alarm_timer <= 0.0:
		if alarm_audio != null and alarm_audio.playing:
			alarm_audio.stop()
		return
	alarm_timer = maxf(0.0, alarm_timer - delta)
	alarm_pulse_timer -= delta
	if alarm_pulse_timer <= 0.0:
		alarm_pulse_timer = 0.5
		var rad: float = Balance.data.get_noise_radius(4)
		EventBus.noise_emitted.emit(global_position, 4, rad)
		EventBus.player_noise_level_changed.emit(4, rad)

	if alarm_timer <= 0.0:
		if alarm_audio != null:
			alarm_audio.stop()
		if driver_player == null:
			# По окончании 7 секунд сигнализации возвращаем индикатор шума к тишине.
			EventBus.player_noise_level_changed.emit(1, 0.0)


## Запускает штатную сигнализацию на 7 секунд (33 метра)
func trigger_car_alarm() -> void:
	alarm_timer = Balance.data.car_alarm_duration_sec
	alarm_pulse_timer = 0.0
	if alarm_audio != null:
		if alarm_audio.stream == null:
			alarm_audio.stream = _build_alarm_stream()
		if not alarm_audio.playing:
			alarm_audio.play()
	var rad: float = Balance.data.get_noise_radius(4)
	EventBus.noise_emitted.emit(global_position, 4, rad)
	EventBus.player_noise_level_changed.emit(4, rad)


## Взлом замка отмычкой: проверяет наличие lockpick, списывает 1 шт., открывает машину.
## Если force_alarm_result == -1, разыгрывает шанс Balance.data.car_alarm_chance;
## если 0 — взлом без сигнализации (успех QTE); если 1 — срабатывает сигнализация (промах QTE).
func attempt_lockpick(force_alarm_result: int = -1) -> bool:
	if not is_locked or is_destroyed:
		return false
	if not GameState.consume_any_item("lockpick", 1):
		return false

	is_locked = false
	var alarm_triggered: bool = false
	if force_alarm_result == 1:
		alarm_triggered = true
	elif force_alarm_result == 0:
		# Успешное попадание в зелёную зону QTE — тихое открытие, сигнализации нет.
		alarm_triggered = false
		alarm_timer = 0.0
	else:
		alarm_triggered = randf() < Balance.data.car_alarm_chance

	if alarm_triggered:
		trigger_car_alarm()

	EventBus.vehicle_lockpicked.emit(self, alarm_triggered)
	return true


## Посадка игрока на место водителя
func enter_vehicle(player: Player) -> bool:
	if is_locked or is_destroyed or driver_player != null or player == null:
		return false

	# Взаимно исключаем коллизии между машиной и капсулой игрока.
	add_collision_exception_with(player)
	player.add_collision_exception_with(self)
	if spring_arm != null:
		spring_arm.add_excluded_object(player.get_rid())

	# Проснувшаяся после стоянки машина не реагирует на газ, пока RigidBody3D спит.
	# Пока водитель внутри, запрещаем телу засыпать, иначе педали «не работают».
	sleeping = false
	can_sleep = false

	driver_player = player
	driver_player.velocity = Vector3.ZERO
	driver_player.visible = false
	driver_player.set_physics_process(false)
	# Пока игрок за рулём, его собственные действия (прыжок, перезарядка,
	# повторное «interact») не должны перехватывать управление у машины.
	driver_player.set_process_input(false)
	driver_player.set_process_unhandled_input(false)
	driver_player.collision_shape.set_deferred("disabled", true)

	# Переключаем камеру строго по выбранному до рейда режиму (1-е или 3-е лицо)
	if GameState.selected_camera_mode == GameState.CameraMode.FIRST_PERSON:
		first_person_cam.current = true
		third_person_cam.current = false
	else:
		first_person_cam.current = false
		third_person_cam.current = true

	EventBus.player_entered_vehicle.emit(self)
	EventBus.vehicle_durability_changed.emit(current_durability, max_durability)
	return true


## Высадка игрока из автомобиля
func exit_vehicle() -> void:
	if driver_player == null or not is_instance_valid(driver_player):
		driver_player = null
		return

	var p: Player = driver_player
	driver_player = null
	last_exited_player = p
	exit_collision_grace_timer = EXIT_COLLISION_GRACE_SEC
	can_sleep = true

	# Гарантируем взаимное исключение коллизий на момент выхода.
	add_collision_exception_with(p)
	p.add_collision_exception_with(self)

	# Ставим машину на ручной тормоз и гасим паразитные импульсы.
	hud_steer_input = 0.0
	hud_throttle_input = 0.0
	hud_brake_input = 0.0
	engine_force = 0.0
	steering = 0.0
	brake = Balance.data.car_base_brake_force
	angular_velocity = Vector3.ZERO
	if linear_velocity.y > 0.0:
		linear_velocity.y = 0.0

	first_person_cam.current = false
	third_person_cam.current = false

	# Безопасная точка слева от водительской двери с защитой от пола.
	var safe_exit_pos: Vector3 = to_global(EXIT_LOCAL_OFFSET)
	var min_floor_y: float = maxf(0.15, global_position.y + 0.25)
	if safe_exit_pos.y < min_floor_y:
		safe_exit_pos.y = min_floor_y

	p.global_position = safe_exit_pos
	p.velocity = Vector3.ZERO
	p.rotation = Vector3(0.0, global_rotation.y, 0.0)
	p.visible = true
	p.set_physics_process(true)
	p.set_process_input(true)
	p.set_process_unhandled_input(true)
	p._setup_camera_mode()

	# Включаем коллизию игрока только после того, как физический сервер
	# получит его новую позицию. Иначе один тик капсула ещё находится в машине
	# и выталкивает её — машина подлетает и переворачивается.
	_reenable_player_collision_after_physics(p)

	EventBus.player_exited_vehicle.emit(self)


func _reenable_player_collision_after_physics(p: Player) -> void:
	await get_tree().physics_frame
	if is_instance_valid(p):
		p.collision_shape.set_deferred("disabled", false)


## Таран зомби на ходу
func _on_ram_hitbox_body_entered(body: Node) -> void:
	if is_destroyed or body == self or body == driver_player:
		return
	var speed_mps: float = linear_velocity.length()
	if speed_mps < Balance.data.car_ram_min_speed_mps:
		return

	if body.has_method("apply_damage"):
		body.call("apply_damage", Balance.data.car_ram_zombie_damage, global_position)

		# Если НЕ установлен Передний бампер / Таран (Отвал), двигатель и кузов получают урон
		if not has_ram_bumper():
			apply_vehicle_damage(Balance.data.car_ram_self_damage_no_bumper)


## Нанесение урона автомобилю (при падении до 0 машина взрывается с 4-м уровнем шума 33 м и теряется навсегда)
func apply_vehicle_damage(raw_damage: float) -> void:
	if is_destroyed or raw_damage <= 0.0:
		return
	var final_damage: float = raw_damage * (1.0 - get_hull_armor_reduction())
	current_durability = maxf(0.0, current_durability - final_damage)
	EventBus.vehicle_durability_changed.emit(current_durability, max_durability)

	if current_durability <= 0.0:
		_destroy_vehicle()


func _destroy_vehicle() -> void:
	is_destroyed = true
	if alarm_audio != null:
		alarm_audio.stop()
	trunk_grid.clear()

	if driver_player != null:
		exit_vehicle()

	# Взрыв машины создаёт 4-й уровень шума (33 м)
	var rad: float = Balance.data.get_noise_radius(4)
	EventBus.noise_emitted.emit(global_position, 4, rad)

	# Если это была машина из Гаража — она теряется навсегда по разделу 3.5 GDD
	if GameState.deployed_with_garage_vehicle:
		GameState.garage_vehicle_state.clear()
		GameState.deployed_with_garage_vehicle = false

	EventBus.vehicle_destroyed.emit(self)


# --- Интерфейс взаимодействия для Player и InventoryModal ---

func get_interaction_prompt() -> String:
	if is_destroyed:
		return "АВТОМОБИЛЬ УНИЧТОЖЕН"
	if is_locked:
		return "ВЗЛОМАТЬ ЗАМОК (ОТМЫЧКА)"
	return "СЕСТЬ В АВТО [%s]" % vehicle_title


func interact(player: Player) -> void:
	if is_destroyed:
		return
	if is_locked:
		if GameState.count_any_item("lockpick") <= 0:
			print("[Транспорт]: Нужна Отмычка (lockpick) для взлома замка!")
			return
		# Если HUD поддерживает QTE — запускает QTE, иначе сразу выполняет взлом
		EventBus.request_start_lockpick_qte.emit(self)
		return

	enter_vehicle(player)


func get_container_title() -> String:
	return "БАГАЖНИК: %s (%dx%d)" % [vehicle_title, trunk_grid.width, trunk_grid.height]


func get_loot_grid() -> InventoryGrid:
	return trunk_grid


func open_trunk_inventory() -> void:
	if is_locked or is_destroyed:
		return
	EventBus.request_open_loot_container.emit(self)


func _on_trunk_candidate_entered(body: Node) -> void:
	if body is Player and not is_locked and not is_destroyed and driver_player == null:
		EventBus.trunk_access_changed.emit(self, true)


func _on_trunk_candidate_exited(body: Node) -> void:
	if body is Player:
		EventBus.trunk_access_changed.emit(self, false)


## Сериализация состояния машины (прочность, 6 деталей, багажник) для сохранения в Гараж Хаба
func to_garage_dictionary() -> Dictionary:
	return {
		"vehicle_title": vehicle_title,
		"current_durability": current_durability,
		"max_durability": max_durability,
		"installed_parts": installed_parts.duplicate(true),
		"trunk_items": trunk_grid.to_serialized_array()
	}


## Восстановление состояния машины из словаря Гаража Хаба
func apply_from_garage_dictionary(state_dict: Dictionary) -> void:
	if state_dict.is_empty():
		return
	is_locked = false
	vehicle_title = str(state_dict.get("vehicle_title", vehicle_title))
	max_durability = float(state_dict.get("max_durability", Balance.data.car_max_durability))
	current_durability = float(state_dict.get("current_durability", max_durability))
	var saved_parts: Dictionary = state_dict.get("installed_parts", {})
	for key in installed_parts.keys():
		if saved_parts.has(key):
			installed_parts[key] = saved_parts[key]
	_recalculate_vehicle_stats()
	var saved_trunk: Array = state_dict.get("trunk_items", [])
	trunk_grid.load_from_serialized_array(saved_trunk, GameState.get_item_data)