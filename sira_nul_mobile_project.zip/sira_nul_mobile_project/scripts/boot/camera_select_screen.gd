extends Control
## Стартовый экран выбора вида камеры (от 1-го или от 3-го лица) ДО старта сессии (раздел 1 GDD).

const HUB_SCENE_PATH: String = "res://scenes/hub/hub_scene.tscn"

@onready var btn_first_person: Button = $CenterPanel/VBox/BtnFirstPerson
@onready var btn_third_person: Button = $CenterPanel/VBox/BtnThirdPerson


func _ready() -> void:
	SaveManager.load_game()
	btn_first_person.pressed.connect(_on_first_person_selected)
	btn_third_person.pressed.connect(_on_third_person_selected)


func _on_first_person_selected() -> void:
	GameState.set_camera_mode_before_raid(GameState.CameraMode.FIRST_PERSON)
	get_tree().change_scene_to_file(HUB_SCENE_PATH)


func _on_third_person_selected() -> void:
	GameState.set_camera_mode_before_raid(GameState.CameraMode.THIRD_PERSON)
	get_tree().change_scene_to_file(HUB_SCENE_PATH)