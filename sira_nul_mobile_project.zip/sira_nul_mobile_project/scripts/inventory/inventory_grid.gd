class_name InventoryGrid
extends RefCounted
## Логика 2D-клеточной сетки инвентаря (Рюкзак 4x4..10x10, Страховой слот 2x2,
## Карманы 6x1, Контейнеры локаций/трупов и единый Склад Хаба 12x30).
## Поддерживает поворот предметов на 90 градусов и стакинг расходуемых предметов/патронов.

signal grid_changed()

var width: int = 4
var height: int = 4

## Список размещённых элементов:
## {
##   "uid": int,
##   "item_id": String,
##   "item_data": ItemData,
##   "pos": Vector2i,
##   "rotated": bool,
##   "stack": int,
##   "durability": float
## }
var _items: Array[Dictionary] = []
var _next_uid: int = 1


func _init(grid_width: int = 4, grid_height: int = 4) -> void:
	width = maxi(1, grid_width)
	height = maxi(1, grid_height)


## Изменяет размер сетки (например, при смене модели рюкзака от 4x4 до 10x10)
func resize_grid(new_width: int, new_height: int) -> void:
	width = maxi(1, new_width)
	height = maxi(1, new_height)
	grid_changed.emit()


func get_items() -> Array[Dictionary]:
	return _items


func clear() -> void:
	_items.clear()
	grid_changed.emit()


## Возвращает габариты предмета с учётом флага поворота на 90 градусов
static func get_effective_size(item_data: ItemData, is_rotated: bool) -> Vector2i:
	if item_data == null:
		return Vector2i(1, 1)
	var raw_size: Vector2i = Vector2i(maxi(1, item_data.grid_size.x), maxi(1, item_data.grid_size.y))
	if is_rotated and item_data.can_rotate:
		return Vector2i(raw_size.y, raw_size.x)
	return raw_size


## Проверяет, свободны ли клетки для размещения предмета в позиции top_left
func can_place(item_data: ItemData, top_left: Vector2i, is_rotated: bool, ignore_uid: int = -1) -> bool:
	if item_data == null:
		return false
	var eff_size: Vector2i = get_effective_size(item_data, is_rotated)
	if top_left.x < 0 or top_left.y < 0:
		return false
	if top_left.x + eff_size.x > width or top_left.y + eff_size.y > height:
		return false

	var candidate_rect: Rect2i = Rect2i(top_left, eff_size)
	for entry in _items:
		if int(entry["uid"]) == ignore_uid:
			continue
		var other_data: ItemData = entry["item_data"] as ItemData
		var other_size: Vector2i = get_effective_size(other_data, bool(entry["rotated"]))
		var other_rect: Rect2i = Rect2i(entry["pos"] as Vector2i, other_size)
		if candidate_rect.intersects(other_rect):
			return false
	return true


## Возвращает запись предмета, занимающего указанную клетку (или пустой Dictionary)
func get_item_at_cell(cell: Vector2i) -> Dictionary:
	for entry in _items:
		var item_data: ItemData = entry["item_data"] as ItemData
		var eff_size: Vector2i = get_effective_size(item_data, bool(entry["rotated"]))
		var rect: Rect2i = Rect2i(entry["pos"] as Vector2i, eff_size)
		if rect.has_point(cell):
			return entry
	return {}


func get_item_by_uid(uid: int) -> Dictionary:
	for entry in _items:
		if int(entry["uid"]) == uid:
			return entry
	return {}


## Размещает предмет в указанной клетке
func place_item(
	item_data: ItemData,
	top_left: Vector2i,
	is_rotated: bool = false,
	stack_count: int = 1,
	durability: float = -1.0
) -> int:
	var final_rotated: bool = is_rotated and item_data.can_rotate
	if not can_place(item_data, top_left, final_rotated):
		return -1

	var uid: int = _next_uid
	_next_uid += 1
	var final_durability: float = item_data.max_durability if durability < 0.0 else durability

	var entry: Dictionary = {
		"uid": uid,
		"item_id": item_data.id,
		"item_data": item_data,
		"pos": top_left,
		"rotated": final_rotated,
		"stack": clampi(stack_count, 1, maxi(1, item_data.max_stack)),
		"durability": final_durability
	}
	_items.append(entry)
	grid_changed.emit()
	return uid


## Автоматически стакает расходуемый предмет/патроны или ищет первую свободную позицию (в т.ч. с поворотом)
func add_item_auto(item_data: ItemData, stack_count: int = 1, durability: float = -1.0) -> bool:
	if item_data == null or stack_count <= 0:
		return false

	var remaining: int = stack_count

	# 1. Если предмет стакается — сначала докладываем в существующие неполные стаки
	if item_data.max_stack > 1:
		for entry in _items:
			if str(entry["item_id"]) == item_data.id and int(entry["stack"]) < item_data.max_stack:
				var space: int = item_data.max_stack - int(entry["stack"])
				var added: int = mini(space, remaining)
				entry["stack"] = int(entry["stack"]) + added
				remaining -= added
				if remaining <= 0:
					grid_changed.emit()
					return true

	# 2. Размещаем оставшееся количество в свободные ячейки сетки
	while remaining > 0:
		var chunk: int = mini(remaining, maxi(1, item_data.max_stack))
		var placed: bool = false

		for y in range(height):
			for x in range(width):
				var cell: Vector2i = Vector2i(x, y)
				if can_place(item_data, cell, false):
					place_item(item_data, cell, false, chunk, durability)
					placed = true
					break
				elif item_data.can_rotate and can_place(item_data, cell, true):
					place_item(item_data, cell, true, chunk, durability)
					placed = true
					break
			if placed:
				break

		if not placed:
			grid_changed.emit()
			return false
		remaining -= chunk

	grid_changed.emit()
	return true


## Поворачивает уже лежащий в сетке предмет на 90 градусов, если габариты позволяют
func rotate_item_in_place(uid: int) -> bool:
	var entry: Dictionary = get_item_by_uid(uid)
	if entry.is_empty():
		return false
	var item_data: ItemData = entry["item_data"] as ItemData
	if item_data == null or not item_data.can_rotate:
		return false

	var new_rotated: bool = not bool(entry["rotated"])
	var pos: Vector2i = entry["pos"] as Vector2i
	if can_place(item_data, pos, new_rotated, uid):
		entry["rotated"] = new_rotated
		grid_changed.emit()
		return true
	return false


## Перемещает предмет внутри этой же сетки (с поддержкой объединения стаков)
func move_item(uid: int, new_top_left: Vector2i, new_rotated: bool) -> bool:
	var entry: Dictionary = get_item_by_uid(uid)
	if entry.is_empty():
		return false
	var item_data: ItemData = entry["item_data"] as ItemData
	var final_rotated: bool = new_rotated and item_data.can_rotate

	# Проверка объединения стаков одинаковых предметов
	var target_at_cell: Dictionary = get_item_at_cell(new_top_left)
	if not target_at_cell.is_empty() and int(target_at_cell["uid"]) != uid:
		if str(target_at_cell["item_id"]) == item_data.id and item_data.max_stack > 1:
			var space: int = item_data.max_stack - int(target_at_cell["stack"])
			if space > 0:
				var transfer: int = mini(space, int(entry["stack"]))
				target_at_cell["stack"] = int(target_at_cell["stack"]) + transfer
				entry["stack"] = int(entry["stack"]) - transfer
				if int(entry["stack"]) <= 0:
					remove_item_by_uid(uid)
				else:
					grid_changed.emit()
				return true

	if can_place(item_data, new_top_left, final_rotated, uid):
		entry["pos"] = new_top_left
		entry["rotated"] = final_rotated
		grid_changed.emit()
		return true
	return false


## Удаляет предмет по uid и возвращает его словарь
func remove_item_by_uid(uid: int) -> Dictionary:
	for i in range(_items.size()):
		if int(_items[i]["uid"]) == uid:
			var removed: Dictionary = _items[i]
			_items.remove_at(i)
			grid_changed.emit()
			return removed
	return {}


## Уменьшает стак предмета на amount (и удаляет, если стак стал 0)
func consume_from_uid(uid: int, amount: int = 1) -> bool:
	var entry: Dictionary = get_item_by_uid(uid)
	if entry.is_empty():
		return false
	entry["stack"] = int(entry["stack"]) - amount
	if int(entry["stack"]) <= 0:
		remove_item_by_uid(uid)
	else:
		grid_changed.emit()
	return true


## Подсчитывает общее количество предметов с данным item_id в сетке
func count_item_by_id(item_id: String) -> int:
	var total: int = 0
	for entry in _items:
		if str(entry["item_id"]) == item_id:
			total += int(entry["stack"])
	return total


## Списывает нужное количество предметов по item_id (например, патроны при перезарядке)
func consume_item_by_id(item_id: String, amount: int) -> int:
	var left_to_take: int = amount
	for i in range(_items.size() - 1, -1, -1):
		if left_to_take <= 0:
			break
		var entry: Dictionary = _items[i]
		if str(entry["item_id"]) == item_id:
			var avail: int = int(entry["stack"])
			var taken: int = mini(avail, left_to_take)
			entry["stack"] = avail - taken
			left_to_take -= taken
			if int(entry["stack"]) <= 0:
				_items.remove_at(i)
	if left_to_take != amount:
		grid_changed.emit()
	return amount - left_to_take


## Сериализация в массив словарей для GameState и SaveManager
func to_serialized_array() -> Array[Dictionary]:
	var result: Array[Dictionary] = []
	for entry in _items:
		var pos: Vector2i = entry["pos"] as Vector2i
		result.append({
			"item_id": str(entry["item_id"]),
			"pos_x": pos.x,
			"pos_y": pos.y,
			"rotated": bool(entry["rotated"]),
			"stack": int(entry["stack"]),
			"durability": float(entry["durability"])
		})
	return result


## Восстановление сетки из сериализованного массива
func load_from_serialized_array(serialized: Array, item_lookup: Callable) -> void:
	_items.clear()
	for raw in serialized:
		if typeof(raw) != TYPE_DICTIONARY:
			continue
		var dict: Dictionary = raw
		var id: String = str(dict.get("item_id", ""))
		var item_data: ItemData = item_lookup.call(id) as ItemData
		if item_data == null:
			continue
		var pos: Vector2i = Vector2i(int(dict.get("pos_x", 0)), int(dict.get("pos_y", 0)))
		if dict.has("pos") and dict["pos"] is Vector2i:
			pos = dict["pos"]
		var rot: bool = bool(dict.get("rotated", false))
		var st: int = int(dict.get("stack", 1))
		var dur: float = float(dict.get("durability", item_data.max_durability))
		place_item(item_data, pos, rot, st, dur)
	grid_changed.emit()