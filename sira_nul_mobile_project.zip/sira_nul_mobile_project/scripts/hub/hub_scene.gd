extends Node3D
## 2D-меню Хаба поверх полупрозрачной 3D-панорамы туманного города с высоты птичьего полёта (раздел 4 GDD):
## 4 вкладки:
## 1) «Склад и Экипировка» (вызов сетки Склада 12x30 + тюнинг 5 слотов обвесов оружия);
## 2) «Гараж» (состояние машины, ремонт ремкомплектом, 6 слотов узлов авто, багажник, чекбокс выезда);
## 3) «Торговцы (7)» (Медик, Оружейник, Механик с ремонтом, Снабженец, Химик с крафтом инъекторов, Автомеханик, Чёрный торговец);
## 4) «Контракты» (взятие и сдача контрактов за рубли, репутацию и топовое снаряжение).

const RAID_WORLD_PATH: String = "res://scenes/world/raid_world.tscn"
const CAMERA_SELECT_PATH: String = "res://scenes/boot/camera_select_screen.tscn"
const INVENTORY_MODAL_SCENE: PackedScene = preload("res://scenes/ui/inventory_modal.tscn")

@onready var status_label: Label = $HubUI/MainPanel/Margin/VBox/HeaderRow/StatusLabel
@onready var save_button: Button = $HubUI/MainPanel/Margin/VBox/HeaderRow/SaveButton
@onready var change_cam_button: Button = $HubUI/MainPanel/Margin/VBox/HeaderRow/ChangeCameraButton

@onready var tab_stash_btn: Button = $HubUI/MainPanel/Margin/VBox/NavTabsRow/TabStashBtn
@onready var tab_garage_btn: Button = $HubUI/MainPanel/Margin/VBox/NavTabsRow/TabGarageBtn
@onready var tab_traders_btn: Button = $HubUI/MainPanel/Margin/VBox/NavTabsRow/TabTradersBtn
@onready var tab_contracts_btn: Button = $HubUI/MainPanel/Margin/VBox/NavTabsRow/TabContractsBtn

@onready var stash_page: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/StashPage
@onready var open_stash_modal_btn: Button = $HubUI/MainPanel/Margin/VBox/PagesContainer/StashPage/OpenStashModalButton
@onready var weapon_mods_vbox: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/StashPage/WeaponModsVBox

@onready var garage_page: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/GaragePage
@onready var garage_status_label: Label = $HubUI/MainPanel/Margin/VBox/PagesContainer/GaragePage/GarageStatusLabel
@onready var parts_list_vbox: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/GaragePage/PartsVBox
@onready var repair_car_button: Button = $HubUI/MainPanel/Margin/VBox/PagesContainer/GaragePage/GarageActionsHBox/RepairCarButton
@onready var open_trunk_button: Button = $HubUI/MainPanel/Margin/VBox/PagesContainer/GaragePage/GarageActionsHBox/OpenTrunkButton
@onready var deploy_with_car_check: CheckButton = $HubUI/MainPanel/Margin/VBox/PagesContainer/GaragePage/GarageActionsHBox/DeployWithCarCheck

@onready var traders_page: HBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/TradersPage
@onready var trader_buttons_vbox: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/TradersPage/TraderListVBox
@onready var trader_title_label: Label = $HubUI/MainPanel/Margin/VBox/PagesContainer/TradersPage/TraderContentVBox/TraderTitleLabel
@onready var trader_desc_label: Label = $HubUI/MainPanel/Margin/VBox/PagesContainer/TradersPage/TraderContentVBox/TraderDescLabel
@onready var trader_items_vbox: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/TradersPage/TraderContentVBox/CatalogScroll/TraderItemsVBox

@onready var contracts_page: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/ContractsPage
@onready var contracts_list_vbox: VBoxContainer = $HubUI/MainPanel/Margin/VBox/PagesContainer/ContractsPage/ContractsScroll/ContractsListVBox

@onready var deploy_button: Button = $HubUI/MainPanel/Margin/VBox/DeployButton

var inventory_modal: InventoryModal = null
var selected_trader_id: String = "medic"

const TRADER_ORDER: Array[String] = [
	"medic", "gunsmith", "mechanic", "supplier", "chemist", "auto_mechanic", "black_trader"
]

const WEAPON_MOD_SLOTS_META: Array[Dictionary] = [
	{"key": "optic", "title": "1. Прицел (Optic)", "item_id": "optic_pso1"},
	{"key": "muzzle", "title": "2. Дуло / Глушитель (6 м шума)", "item_id": "muzzle_suppressor"},
	{"key": "magazine", "title": "3. Магазин (+15 патронов)", "item_id": "mag_extended_45"},
	{"key": "grip", "title": "4. Тактическая рукоять", "item_id": "grip_tactical"},
	{"key": "stock", "title": "5. Приклад", "item_id": "stock_polymer"}
]

const GARAGE_SLOTS_META: Array[Dictionary] = [
	{"key": "bumper_ram", "title": "1. Передний бампер / Таран", "part_id": "bumper_ram"},
	{"key": "body_armor", "title": "2. Броня кузова и решётки", "part_id": "body_armor"},
	{"key": "engine", "title": "3. Двигатель", "part_id": "engine_stock"},
	{"key": "tires", "title": "4. Шины (Колёса)", "part_id": "tires_stock"},
	{"key": "exhaust", "title": "5. Выхлопная система (Глушитель)", "part_id": "exhaust_muffler"},
	{"key": "trunk", "title": "6. Багажник (Сетка)", "part_id": "trunk_stock"}
]


func _ready() -> void:
	# В Хабе камеру снова можно менять: после рейда флаг остаётся включённым.
	GameState.is_camera_locked_for_raid = false

	if INVENTORY_MODAL_SCENE != null:
		inventory_modal = INVENTORY_MODAL_SCENE.instantiate() as InventoryModal
		add_child(inventory_modal)

	save_button.pressed.connect(func() -> void: SaveManager.save_game())
	change_cam_button.pressed.connect(_on_change_cam_pressed)

	tab_stash_btn.pressed.connect(func() -> void: _switch_page(0))
	tab_garage_btn.pressed.connect(func() -> void: _switch_page(1))
	tab_traders_btn.pressed.connect(func() -> void: _switch_page(2))
	tab_contracts_btn.pressed.connect(func() -> void: _switch_page(3))

	open_stash_modal_btn.pressed.connect(_on_open_stash_pressed)
	repair_car_button.pressed.connect(_on_repair_car_pressed)
	open_trunk_button.pressed.connect(_on_open_trunk_pressed)
	deploy_button.pressed.connect(_on_deploy_pressed)

	EventBus.currency_changed.connect(func(_r: int) -> void: _refresh_all())
	GameState.inventory_changed.connect(_refresh_all)
	GameState.equipment_changed.connect(_refresh_all)
	GameState.garage_changed.connect(_refresh_all)
	GameState.quests_changed.connect(_refresh_all)

	_build_trader_selector_buttons()
	_switch_page(0)
	_refresh_all()


func _switch_page(page_idx: int) -> void:
	stash_page.visible = (page_idx == 0)
	garage_page.visible = (page_idx == 1)
	traders_page.visible = (page_idx == 2)
	contracts_page.visible = (page_idx == 3)
	_refresh_all()


func _refresh_all() -> void:
	var cam_text: String = "1-е лицо" if GameState.selected_camera_mode == GameState.CameraMode.FIRST_PERSON else "3-е лицо"
	status_label.text = "Рубли: %d ₽ | Камера: %s | Отмычки: %d" % [
		GameState.rubles,
		cam_text,
		GameState.count_item_including_stash("lockpick")
	]
	_refresh_weapon_mods_ui()
	_refresh_garage_ui()
	_refresh_active_trader_ui()
	_refresh_contracts_ui()


func _refresh_weapon_mods_ui() -> void:
	for child in weapon_mods_vbox.get_children():
		child.queue_free()

	for meta in WEAPON_MOD_SLOTS_META:
		var slot_key: String = str(meta["key"])
		var slot_title: String = str(meta["title"])
		var item_id: String = str(meta["item_id"])
		var cur_id: Variant = GameState.weapon_attachments.get(slot_key, null)

		var row: HBoxContainer = HBoxContainer.new()
		var lbl: Label = Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		var cur_name: String = "Не установлено"
		if cur_id is String and not str(cur_id).is_empty():
			var d: ItemData = GameState.get_item_data(str(cur_id))
			cur_name = d.display_name if d != null else str(cur_id)
		lbl.text = "%s: %s" % [slot_title, cur_name]
		row.add_child(lbl)

		if cur_id is String and not str(cur_id).is_empty():
			var rem_btn: Button = Button.new()
			rem_btn.text = "Снять на Склад"
			rem_btn.pressed.connect(func() -> void: GameState.remove_weapon_attachment(slot_key))
			row.add_child(rem_btn)
		else:
			var inst_btn: Button = Button.new()
			inst_btn.text = "Установить (%s)" % item_id
			inst_btn.disabled = GameState.count_item_including_stash(item_id) <= 0
			inst_btn.pressed.connect(func() -> void: GameState.install_weapon_attachment(item_id))
			row.add_child(inst_btn)

		weapon_mods_vbox.add_child(row)


func _refresh_garage_ui() -> void:
	for child in parts_list_vbox.get_children():
		child.queue_free()

	if not GameState.has_garage_vehicle():
		garage_status_label.text = "ГАРАЖ ПУСТ: Угоните машину в городе и эвакуируйте через Блокпост (Автовыезд)"
		repair_car_button.disabled = true
		open_trunk_button.disabled = true
		deploy_with_car_check.disabled = true
		deploy_with_car_check.button_pressed = false
		return

	var car_title: String = str(GameState.garage_vehicle_state.get("vehicle_title", "Автомобиль"))
	var cur_hp: float = float(GameState.garage_vehicle_state.get("current_durability", 200.0))
	var max_hp: float = float(GameState.garage_vehicle_state.get("max_durability", 200.0))
	garage_status_label.text = "В ГАРАЖЕ: %s | Прочность: %d / %d" % [car_title, int(cur_hp), int(max_hp)]
	repair_car_button.disabled = (cur_hp >= max_hp) or (GameState.count_item_including_stash("vehicle_repair_kit") <= 0)
	open_trunk_button.disabled = false
	deploy_with_car_check.disabled = false

	var installed: Dictionary = GameState.garage_vehicle_state.get("installed_parts", {})
	for slot_meta in GARAGE_SLOTS_META:
		var slot_key: String = str(slot_meta["key"])
		var slot_title: String = str(slot_meta["title"])
		var upgrade_id: String = str(slot_meta["part_id"])
		var current_part_id: Variant = installed.get(slot_key, null)

		var current_name: String = "Сток / Не установлено"
		if current_part_id is String and not str(current_part_id).is_empty():
			var p_data: ItemData = GameState.get_item_data(str(current_part_id))
			current_name = p_data.display_name if p_data != null else str(current_part_id)

		var row: HBoxContainer = HBoxContainer.new()
		var lbl: Label = Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.text = "%s: %s" % [slot_title, current_name]
		row.add_child(lbl)

		var install_btn: Button = Button.new()
		install_btn.text = "Установить со Склада"
		install_btn.disabled = (GameState.count_item_including_stash(upgrade_id) <= 0) or (str(current_part_id) == upgrade_id)
		install_btn.pressed.connect(func() -> void: GameState.install_vehicle_part_in_garage(upgrade_id))
		row.add_child(install_btn)
		parts_list_vbox.add_child(row)


func _build_trader_selector_buttons() -> void:
	for child in trader_buttons_vbox.get_children():
		child.queue_free()

	for t_id in TRADER_ORDER:
		var tr: TraderData = GameState.get_trader_data(t_id)
		var btn: Button = Button.new()
		btn.custom_minimum_size = Vector2(210, 42)
		btn.text = tr.display_name if tr != null else t_id
		btn.pressed.connect(func() -> void:
			selected_trader_id = t_id
			_refresh_active_trader_ui()
		)
		trader_buttons_vbox.add_child(btn)


func _refresh_active_trader_ui() -> void:
	for child in trader_items_vbox.get_children():
		child.queue_free()

	var tr: TraderData = GameState.get_trader_data(selected_trader_id)
	if tr == null:
		return

	var rep: int = GameState.get_trader_reputation(selected_trader_id)
	trader_title_label.text = "%s | Репутация: %d очк." % [tr.display_name, rep]
	trader_desc_label.text = tr.specialization_desc

	# 1. Витрина товаров на покупку за рубли
	for item_id in tr.catalog_item_ids:
		var item: ItemData = GameState.get_item_data(item_id)
		if item == null:
			continue
		var req_rep: int = int(tr.item_required_rep.get(item_id, 0))
		var row: HBoxContainer = HBoxContainer.new()
		var lbl: Label = Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.text = "%s — %d ₽ (Треб. реп: %d)" % [item.display_name, item.base_price_rubles, req_rep]
		row.add_child(lbl)

		var buy_btn: Button = Button.new()
		buy_btn.text = "Купить"
		buy_btn.disabled = not GameState.can_buy_from_trader(selected_trader_id, item_id)
		buy_btn.pressed.connect(func() -> void: GameState.buy_item_from_trader(selected_trader_id, item_id))
		row.add_child(buy_btn)
		trader_items_vbox.add_child(row)

	# 2. Спецфункция Механика: ремонт изношенного оружия и брони за рубли
	if tr.can_repair_gear:
		var sep: Label = Label.new()
		sep.text = "--- РЕМОНТ СНАРЯЖЕНИЯ И ОРУЖИЯ ЗА РУБЛИ ---"
		trader_items_vbox.add_child(sep)
		for slot_key in GameState.equipped_items.keys():
			var eq_id: Variant = GameState.equipped_items[slot_key]
			if not (eq_id is String) or str(eq_id).is_empty():
				continue
			var cost: int = GameState.get_slot_repair_cost(slot_key)
			var cur_d: int = int(GameState.equipped_durability.get(slot_key, 100.0))
			var r_row: HBoxContainer = HBoxContainer.new()
			var r_lbl: Label = Label.new()
			r_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			r_lbl.text = "Слот [%s] (%s): прочность %d%%" % [slot_key, str(eq_id), cur_d]
			r_row.add_child(r_lbl)

			var r_btn: Button = Button.new()
			r_btn.text = "Починить (%d ₽)" % cost if cost > 0 else "Целое (100%)"
			r_btn.disabled = (cost <= 0) or (GameState.rubles < cost)
			r_btn.pressed.connect(func() -> void: GameState.repair_equipped_slot_at_mechanic(slot_key))
			r_row.add_child(r_btn)
			trader_items_vbox.add_child(r_row)

	# 3. Спецфункция Химика: создание инъекторов 1–3 уровня (16/35/120 с и 25 с)
	if tr.can_craft_injectors:
		var c_sep: Label = Label.new()
		c_sep.text = "--- ЛАБОРАТОРИЯ ХИМИКА: СИНТЕЗ ИНЪЕКТОРОВ ---"
		trader_items_vbox.add_child(c_sep)
		for idx in range(GameState.CHEMIST_RECIPES.size()):
			var rec: Dictionary = GameState.CHEMIST_RECIPES[idx]
			var ing_id: String = str(rec["ingredient_id"])
			var cost: int = int(rec["rubles_cost"])
			var c_row: HBoxContainer = HBoxContainer.new()
			var c_lbl: Label = Label.new()
			c_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
			c_lbl.text = "%s [Нужно: %s + %d ₽]" % [str(rec["title"]), ing_id, cost]
			c_row.add_child(c_lbl)

			var c_btn: Button = Button.new()
			c_btn.text = "Создать"
			c_btn.disabled = (GameState.rubles < cost) or (GameState.count_item_including_stash(ing_id) <= 0)
			c_btn.pressed.connect(func() -> void: GameState.craft_injector_at_chemist(idx))
			c_row.add_child(c_btn)
			trader_items_vbox.add_child(c_row)

	# 4. Продажа предметов со Склада торговцу (Чёрный торговец скупает исключительно редкий лут)
	var s_sep: Label = Label.new()
	s_sep.text = "--- СКУПКА ПРЕДМЕТОВ СО СКЛАДА ---"
	trader_items_vbox.add_child(s_sep)
	for entry in GameState.stash_grid.get_items():
		var item: ItemData = entry["item_data"] as ItemData
		if item == null:
			continue
		if tr.buys_only_rare_loot and not item.is_rare_black_market:
			continue
		var uid: int = int(entry["uid"])
		var stack_cnt: int = int(entry["stack"])
		var mult: float = 1.25 if tr.buys_only_rare_loot else 0.65
		var payout: int = maxi(10, int(round(item.base_price_rubles * mult)) * stack_cnt)

		var s_row: HBoxContainer = HBoxContainer.new()
		var s_lbl: Label = Label.new()
		s_lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		s_lbl.text = "%s x%d" % [item.display_name, stack_cnt]
		s_row.add_child(s_lbl)

		var s_btn: Button = Button.new()
		s_btn.text = "Продать за %d ₽" % payout
		s_btn.pressed.connect(func() -> void: GameState.sell_item_to_trader(selected_trader_id, GameState.stash_grid, uid))
		s_row.add_child(s_btn)
		trader_items_vbox.add_child(s_row)


func _refresh_contracts_ui() -> void:
	for child in contracts_list_vbox.get_children():
		child.queue_free()

	for q_id in GameState.quest_database.keys():
		var qd: QuestData = GameState.get_quest_data(str(q_id))
		if qd == null:
			continue
		var is_taken: bool = GameState.active_quests.has(q_id)
		var st: Dictionary = GameState.active_quests.get(q_id, {})
		var is_claimed: bool = bool(st.get("claimed", false))
		var prog: int = int(st.get("progress", 0))
		if qd.objective_type == QuestData.QuestType.FETCH_ITEM:
			prog = GameState.count_item_including_stash(qd.target_id)

		var row: HBoxContainer = HBoxContainer.new()
		var lbl: Label = Label.new()
		lbl.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		lbl.text = "%s | Награда: %d ₽, +%d реп. | Прогресс: %d / %d" % [
			qd.title, qd.reward_rubles, qd.reward_reputation, prog, qd.required_amount
		]
		row.add_child(lbl)

		var btn: Button = Button.new()
		if is_claimed:
			btn.text = "ВЫПОЛНЕНО"
			btn.disabled = true
		elif not is_taken:
			btn.text = "Взять контракт"
			btn.pressed.connect(func() -> void: GameState.accept_quest(str(q_id)))
		else:
			var ready_claim: bool = GameState.is_quest_ready_to_claim(str(q_id))
			btn.text = "Сдать контракт!" if ready_claim else "В процессе..."
			btn.disabled = not ready_claim
			btn.pressed.connect(func() -> void: GameState.claim_quest_reward(str(q_id)))
		row.add_child(btn)
		contracts_list_vbox.add_child(row)


func _on_open_stash_pressed() -> void:
	if inventory_modal != null:
		inventory_modal.external_grid = GameState.stash_grid
		inventory_modal.external_title = "СКЛАД ХАБА (12x30)"
		inventory_modal.open_modal()


func _on_repair_car_pressed() -> void:
	GameState.repair_garage_vehicle_with_kit()


func _on_open_trunk_pressed() -> void:
	if inventory_modal != null and GameState.has_garage_vehicle():
		inventory_modal.external_grid = GameState.garage_trunk_grid
		inventory_modal.external_title = "БАГАЖНИК МАШИНЫ В ГАРАЖЕ"
		inventory_modal.open_modal()


func _on_deploy_pressed() -> void:
	var use_car: bool = deploy_with_car_check.button_pressed and GameState.has_garage_vehicle()
	GameState.start_raid(use_car)
	SaveManager.save_game()
	get_tree().change_scene_to_file(RAID_WORLD_PATH)


func _on_change_cam_pressed() -> void:
	GameState.is_camera_locked_for_raid = false
	get_tree().change_scene_to_file(CAMERA_SELECT_PATH)