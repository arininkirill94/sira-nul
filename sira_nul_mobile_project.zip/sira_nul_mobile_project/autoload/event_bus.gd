extends Node
## Автозагрузка EventBus: глобальная шина сигналов (Этапы 1–4).

# --- Шум и Стелс ---
signal noise_emitted(origin: Vector3, level: int, radius: float)
signal player_noise_level_changed(level: int, radius: float)

# --- Здоровье, Травмы и Баффы ---
signal player_health_changed(current_hp: float, effective_max_hp: float, base_max_hp: float)
signal player_status_changed(bleeding: bool, fracture: bool, infected: bool, cure_time_left: float)
signal player_buff_changed(buff_tier: int, time_left: float)
signal player_died()

# --- Оружие и Бой ---
signal active_weapon_slot_changed(hand_slot: int, weapon_data: WeaponData)
signal ammo_changed(current_in_mag: int, magazine_capacity: int, reserve_ammo: int)
signal enemy_killed(enemy_id: String, faction: int, world_position: Vector3)
signal sector_cleared(sector_id: String)

# --- Контекстное взаимодействие и Инвентарь ---
signal interaction_available(prompt_text: String, target_node: Node)
signal interaction_cleared()
signal request_open_backpack()
signal request_open_loot_container(container_node: Node)

# --- Транспорт, QTE взлома и Багажник ---
signal request_start_lockpick_qte(vehicle_node: Node)
signal lockpick_qte_finished(vehicle_node: Node, is_success: bool)
signal vehicle_lockpicked(vehicle_node: Node, alarm_triggered: bool)
signal player_entered_vehicle(vehicle_node: Node)
signal player_exited_vehicle(vehicle_node: Node)
signal vehicle_durability_changed(current_durability: float, max_durability: float)
signal vehicle_destroyed(vehicle_node: Node)
signal trunk_access_changed(vehicle_node: Node, can_access: bool)

# --- Таймер вылазки и Эвакуация ---
signal raid_timer_updated(seconds_left: float)
signal extraction_started(point_name: String, hold_seconds: float)
signal extraction_progress(seconds_left: float)
signal extraction_cancelled()
signal extraction_completed(with_vehicle: bool)

# --- Экономика Хаба, 7 Торговцев и Контракты ---
signal currency_changed(new_rubles: int)
signal trader_reputation_changed(trader_id: String, new_rep: int)
signal weapon_attachments_changed()
signal quest_progress_updated(quest_id: String, current_amount: int, required_amount: int)
signal quest_completed(quest_id: String)