extends Node
## Автозагрузка SaveManager (Этап 4): полная сериализация и десериализация прогресса в user://savegame.json.
## Сохраняет рубли, камеру, 7 торговцев, квесты, 5 обвесов оружия, прочность экипировки,
## карманы, рюкзак, страховой слот, единый Склад 12x30 и машину в Гараже с багажником.

const SAVE_FILE_PATH: String = "user://savegame.json"


func save_game() -> bool:
	var payload: Dictionary = {
		"version": 4,
		"selected_camera_mode": int(GameState.selected_camera_mode),
		"rubles": GameState.rubles,
		"equipped_items": GameState.equipped_items.duplicate(true),
		"equipped_durability": GameState.equipped_durability.duplicate(true),
		"weapon_attachments": GameState.weapon_attachments.duplicate(true),
		"pockets_grid": GameState.pockets_grid.to_serialized_array(),
		"safe_slot_items": GameState.safe_grid.to_serialized_array(),
		"backpack_items": GameState.backpack_grid.to_serialized_array(),
		"stash_items": GameState.stash_grid.to_serialized_array(),
		"garage_vehicle_state": GameState.garage_vehicle_state.duplicate(true),
		"trader_reputations": GameState.trader_reputations.duplicate(true),
		"active_quests": GameState.active_quests.duplicate(true)
	}

	var file: FileAccess = FileAccess.open(SAVE_FILE_PATH, FileAccess.WRITE)
	if file == null:
		push_error("SaveManager: ошибка открытия файла для записи: %s" % SAVE_FILE_PATH)
		return false
	file.store_string(JSON.stringify(payload, "\t"))
	file.close()
	return true


func load_game() -> bool:
	if not FileAccess.file_exists(SAVE_FILE_PATH):
		return false
	var file: FileAccess = FileAccess.open(SAVE_FILE_PATH, FileAccess.READ)
	if file == null:
		return false
	var raw_text: String = file.get_as_text()
	file.close()

	var json: JSON = JSON.new()
	var err: Error = json.parse(raw_text)
	if err != OK or typeof(json.data) != TYPE_DICTIONARY:
		push_error("SaveManager: повреждённый JSON файл сохранения.")
		return false

	var data: Dictionary = json.data
	GameState.selected_camera_mode = int(data.get("selected_camera_mode", int(GameState.CameraMode.THIRD_PERSON)))
	GameState.rubles = int(data.get("rubles", 2500))

	var loaded_eq: Dictionary = data.get("equipped_items", {})
	for k in GameState.equipped_items.keys():
		if loaded_eq.has(k):
			GameState.equipped_items[k] = loaded_eq[k]

	var loaded_dur: Dictionary = data.get("equipped_durability", {})
	for k in GameState.equipped_durability.keys():
		if loaded_dur.has(k):
			GameState.equipped_durability[k] = float(loaded_dur[k])

	var loaded_att: Dictionary = data.get("weapon_attachments", {})
	for k in GameState.weapon_attachments.keys():
		if loaded_att.has(k):
			GameState.weapon_attachments[k] = loaded_att[k]

	GameState._update_backpack_dimensions()

	var pockets_arr: Array = data.get("pockets_grid", [])
	if pockets_arr.is_empty() and data.has("pockets"):
		# Миграция сохранений версии 1: там карманы хранились как массив ID без позиций.
		GameState.pockets_grid.clear()
		var old_pockets: Array = data.get("pockets", [])
		for i in range(mini(old_pockets.size(), GameState.pockets_grid.width)):
			var pocket_id: Variant = old_pockets[i]
			if pocket_id is String and not str(pocket_id).is_empty():
				var pocket_item: ItemData = GameState.get_item_data(str(pocket_id))
				if pocket_item != null:
					GameState.pockets_grid.place_item(pocket_item, Vector2i(i, 0), false, 1)
	else:
		GameState.pockets_grid.load_from_serialized_array(pockets_arr, GameState.get_item_data)

	var safe_arr: Array = data.get("safe_slot_items", [])
	GameState.safe_grid.load_from_serialized_array(safe_arr, GameState.get_item_data)

	var bp_arr: Array = data.get("backpack_items", [])
	GameState.backpack_grid.load_from_serialized_array(bp_arr, GameState.get_item_data)

	var stash_arr: Array = data.get("stash_items", [])
	GameState.stash_grid.load_from_serialized_array(stash_arr, GameState.get_item_data)

	GameState.garage_vehicle_state = data.get("garage_vehicle_state", {})
	if GameState.has_garage_vehicle():
		var trunk_arr: Array = GameState.garage_vehicle_state.get("trunk_items", [])
		GameState.garage_trunk_grid.load_from_serialized_array(trunk_arr, GameState.get_item_data)
	else:
		GameState.garage_trunk_grid.clear()

	var rep_dict: Dictionary = data.get("trader_reputations", {})
	for t_id in GameState.trader_reputations.keys():
		if rep_dict.has(t_id):
			GameState.trader_reputations[t_id] = int(rep_dict[t_id])

	GameState.active_quests = data.get("active_quests", {})
	GameState._sync_backing_arrays()
	GameState.equipment_changed.emit()
	GameState.garage_changed.emit()
	GameState.quests_changed.emit()
	return true