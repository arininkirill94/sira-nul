extends Node
## Автозагрузка GameState (Этап 4: полная экономика Хаба, 7 торговцев, репутация,
## ремонт оружия и брони у Механика, крафт инъекторов 16/35/120/25 сек у Химика,
## 5 слотов модификации оружия, тюнинг и ремонт 6 узлов авто, контракты и скупка редкостей).

signal inventory_changed()
signal equipment_changed()
signal garage_changed()
signal quests_changed()

enum CameraMode {
	FIRST_PERSON = 1,
	THIRD_PERSON = 3
}

const ITEMS_DIR: String = "res://resources/items"
const WEAPONS_DIR: String = "res://resources/weapons"
const ATTACHMENTS_DIR: String = "res://resources/attachments"
const VEHICLE_PARTS_DIR: String = "res://resources/vehicle_parts"
const TRADERS_DIR: String = "res://resources/traders"
const QUESTS_DIR: String = "res://resources/quests"

var selected_camera_mode: CameraMode = CameraMode.THIRD_PERSON
var is_camera_locked_for_raid: bool = false

var is_in_raid: bool = false
var raid_time_left_sec: float = 1500.0

var rubles: int = 2500:
	set(value):
		rubles = maxi(0, value)
		EventBus.currency_changed.emit(rubles)

## Слоты экипировки персонажа
var equipped_items: Dictionary = {
	"head": null,
	"hands": null,
	"torso": null,
	"legs": null,
	"boots": null,
	"backpack": null,
	"primary_weapon": null,
	"secondary_weapon": null
}

## Текущая прочность надетой экипировки (0..100, ремонтируется у Механика за рубли)
var equipped_durability: Dictionary = {
	"head": 100.0,
	"hands": 100.0,
	"torso": 100.0,
	"legs": 100.0,
	"boots": 100.0,
	"backpack": 100.0,
	"primary_weapon": 100.0,
	"secondary_weapon": 100.0
}

## 5 слотов модификаций основного огнестрельного оружия (раздел 3.2 GDD):
## "optic" (0), "muzzle" (1), "magazine" (2), "grip" (3), "stock" (4)
var weapon_attachments: Dictionary = {
	"optic": null,
	"muzzle": null,
	"magazine": null,
	"grip": null,
	"stock": null
}

var pockets: Array = [null, null, null, null, null, null]
var safe_slot_items: Array[Dictionary] = []
var backpack_items: Array[Dictionary] = []
var stash_items: Array[Dictionary] = []

var pockets_grid: InventoryGrid
var safe_grid: InventoryGrid
var backpack_grid: InventoryGrid
var stash_grid: InventoryGrid
var garage_trunk_grid: InventoryGrid

var item_database: Dictionary = {}
var trader_database: Dictionary = {}
var quest_database: Dictionary = {}

var garage_vehicle_state: Dictionary = {}
var deployed_with_garage_vehicle: bool = false

## Репутация у 7 торговцев
var trader_reputations: Dictionary = {
	"medic": 0,
	"gunsmith": 0,
	"mechanic": 0,
	"supplier": 0,
	"chemist": 0,
	"auto_mechanic": 0,
	"black_trader": 0
}

## Статусы контрактов: { "quest_id": { "progress": int, "completed": bool, "claimed": bool } }
var active_quests: Dictionary = {}
var current_raid_kills: int = 0

## Рецепты создания инъекторов у Химика из био-образцов (раздел 3.4 и 4 GDD)
const CHEMIST_RECIPES: Array[Dictionary] = [
	{
		"output_id": "injector_cure_fast",
		"title": "Инъектор Химика: Быстрый вывод вируса (25 сек)",
		"ingredient_id": "antidote",
		"rubles_cost": 300
	},
	{
		"output_id": "injector_buff",
		"title": "Инъектор-бафф Уровень 1 (16 сек) — из базовых био-образцов",
		"ingredient_id": "mutant_fingers",
		"rubles_cost": 250
	},
	{
		"output_id": "injector_buff_t2",
		"title": "Инъектор-бафф Уровень 2 (35 сек) — из редких органов",
		"ingredient_id": "mutant_heart",
		"rubles_cost": 500
	},
	{
		"output_id": "injector_buff_t3",
		"title": "Инъектор-бафф Уровень 3 (120 сек) — из заражённого кристалла",
		"ingredient_id": "infected_crystal",
		"rubles_cost": 800
	}
]


func _ready() -> void:
	_register_all_items()
	_register_all_traders()
	_register_all_quests()
	_init_grids()
	_give_starter_loadout_if_empty()

	EventBus.player_died.connect(_on_player_died)
	EventBus.extraction_completed.connect(_on_extraction_completed)
	EventBus.enemy_killed.connect(_on_enemy_killed_for_quests)
	EventBus.sector_cleared.connect(_on_sector_cleared_for_quests)


func _process(delta: float) -> void:
	if not is_in_raid:
		return
	raid_time_left_sec -= delta
	EventBus.raid_timer_updated.emit(maxf(0.0, raid_time_left_sec))
	if raid_time_left_sec <= 0.0:
		is_in_raid = false
		EventBus.player_died.emit()


func _register_all_items() -> void:
	item_database.clear()
	for fname in [
		"ammo_545.tres", "antidote.tres", "bandage.tres", "canned_food.tres",
		"infected_crystal.tres", "injector_buff.tres", "lockpick.tres",
		"mutant_fingers.tres", "mutant_heart.tres", "painkiller.tres",
		"ruble_pack_small.tres", "splint.tres", "tourniquet.tres",
		"pawnshop_watch.tres", "backpack_4x4.tres", "backpack_10x10.tres",
		"silent_boots.tres", "vehicle_repair_kit.tres"
	]:
		_load_item_resource_file(ITEMS_DIR + "/" + fname, fname.get_basename())

	for wname in ["ak74m.tres", "combat_knife.tres"]:
		_load_item_resource_file(WEAPONS_DIR + "/" + wname, wname.get_basename())

	for aname in [
		"optic_pso1.tres", "muzzle_suppressor.tres", "mag_extended_45.tres",
		"grip_tactical.tres", "stock_polymer.tres"
	]:
		_load_item_resource_file(ATTACHMENTS_DIR + "/" + aname, aname.get_basename())

	for pname in [
		"bumper_ram.tres", "body_armor.tres", "engine_stock.tres",
		"tires_stock.tres", "exhaust_muffler.tres", "trunk_stock.tres"
	]:
		_load_item_resource_file(VEHICLE_PARTS_DIR + "/" + pname, pname.get_basename())

	_ensure_builtin_fallback_items()


func _load_item_resource_file(full_path: String, fallback_id: String) -> void:
	if ResourceLoader.exists(full_path):
		var res: Resource = load(full_path)
		if res is ItemData:
			var item: ItemData = res as ItemData
			if item.id.is_empty():
				item.id = fallback_id
			item_database[item.id] = item
			item_database[fallback_id] = item


func _ensure_builtin_fallback_items() -> void:
	_ensure_med_item("bandage", "Бинт", Vector2i(1, 1), 15.0, true, false, 0.0, 0, 120, Color(0.75, 0.25, 0.25))
	_ensure_med_item("tourniquet", "Жгут Эсмарха", Vector2i(1, 1), 10.0, true, false, 0.0, 0, 180, Color(0.65, 0.18, 0.22))
	_ensure_med_item("splint", "Шина медицинская", Vector2i(1, 2), 0.0, false, true, 0.0, 0, 220, Color(0.72, 0.52, 0.2))
	_ensure_med_item("painkiller", "Обезболивающее", Vector2i(1, 1), 10.0, false, true, 0.0, 0, 260, Color(0.8, 0.6, 0.25))
	_ensure_med_item("antidote", "Антидот Медика (120 с)", Vector2i(1, 1), 0.0, false, false, Balance.data.medic_antidote_cure_sec, 0, 650, Color(0.2, 0.65, 0.35))
	_ensure_med_item("medkit_small", "Малая аптечка", Vector2i(1, 1), 40.0, true, false, 0.0, 0, 380, Color(0.82, 0.3, 0.3))
	_ensure_med_item("medkit_military", "Военная аптечка", Vector2i(1, 2), 75.0, true, true, 0.0, 0, 850, Color(0.55, 0.45, 0.22))
	_ensure_med_item("medkit_scientific", "Научная аптечка", Vector2i(2, 2), 100.0, true, true, Balance.data.medic_antidote_cure_sec, 0, 1650, Color(0.88, 0.78, 0.2))
	_ensure_med_item("injector_cure_fast", "Инъектор Химика: Антивирус (25 с)", Vector2i(1, 1), 15.0, false, false, Balance.data.chemist_injector_cure_sec, 0, 1100, Color(0.15, 0.8, 0.55))
	_ensure_med_item("injector_buff", "Инъектор Химика Ур. 1 (16 с)", Vector2i(1, 1), 0.0, false, false, 0.0, 1, 750, Color(0.25, 0.55, 0.85))
	_ensure_med_item("injector_buff_t2", "Инъектор Химика Ур. 2 (35 с)", Vector2i(1, 1), 0.0, false, false, 0.0, 2, 1450, Color(0.45, 0.35, 0.88))
	_ensure_med_item("injector_buff_t3", "Инъектор Химика Ур. 3 (120 с)", Vector2i(1, 1), 0.0, false, false, 0.0, 3, 2900, Color(0.75, 0.25, 0.85))
	_ensure_med_item("canned_food", "Армейские консервы", Vector2i(1, 1), 35.0, false, false, 0.0, 0, 160, Color(0.55, 0.48, 0.32))

	_ensure_simple_item("lockpick", "Отмычка", ItemData.ItemCategory.LOCKPICK, Vector2i(1, 1), 5, 350, false)
	_ensure_simple_item("flashlight", "Тактический фонарик", ItemData.ItemCategory.MISC, Vector2i(1, 2), 1, 450, false)
	_ensure_simple_item("ammo_545", "Патроны 5.45x39", ItemData.ItemCategory.AMMO, Vector2i(1, 1), 60, 12, false)
	_ensure_simple_item("ruble_pack_small", "Пачка мелких рублей", ItemData.ItemCategory.VALUABLE, Vector2i(1, 1), 5000, 150, false)
	item_database["rubles_small_stack"] = item_database["ruble_pack_small"]

	# Боевая химия и пиротехника Химика
	_ensure_simple_item("grenade_frag", "Осколочная граната Ф-1", ItemData.ItemCategory.EXPLOSIVE, Vector2i(1, 1), 3, 600, false)
	_ensure_simple_item("smoke_grenade", "Дымовая шашка РДГ-2", ItemData.ItemCategory.EXPLOSIVE, Vector2i(1, 2), 3, 400, false)
	_ensure_simple_item("molotov_cocktail", "Коктейль Молотова", ItemData.ItemCategory.EXPLOSIVE, Vector2i(1, 2), 2, 350, false)

	# Редкие ценности для скупки Чёрным торговцем и био-мутации
	_ensure_simple_item("pawnshop_watch", "Золотые часы и электроника (Ломбард)", ItemData.ItemCategory.VALUABLE, Vector2i(1, 1), 5, 4200, true)
	_ensure_simple_item("mutant_heart", "Огромное мутировавшее сердце", ItemData.ItemCategory.BIO_TROPHY, Vector2i(2, 2), 1, 3500, true)
	_ensure_simple_item("mutant_fingers", "Острые мутировавшие пальцы", ItemData.ItemCategory.BIO_TROPHY, Vector2i(1, 2), 2, 1400, true)
	_ensure_simple_item("infected_crystal", "Загадочный заражённый кристалл", ItemData.ItemCategory.BIO_TROPHY, Vector2i(1, 1), 1, 5000, true)
	_ensure_simple_item("vehicle_repair_kit", "Ремкомплект для транспорта", ItemData.ItemCategory.VEHICLE_PART, Vector2i(2, 2), 2, 1200, false)

	# Броня и рюкзаки (4x4, 6x6, 10x10)
	_ensure_armor_item("armor_helmet_steel", "Стальной шлем СШ-68", ItemData.ItemCategory.ARMOR_HEAD, Vector2i(2, 2), 15.0, 1600)
	_ensure_armor_item("armor_vest_light", "Лёгкий бронежилет", ItemData.ItemCategory.ARMOR_TORSO, Vector2i(3, 3), 25.0, 2400)
	_ensure_armor_item("armor_vest_military", "Армейский бронежилет 6Б45", ItemData.ItemCategory.ARMOR_TORSO, Vector2i(3, 3), 50.0, 5800)

	if not item_database.has("silent_boots"):
		var boots: ItemData = ItemData.new()
		boots.id = "silent_boots"
		boots.display_name = "Специальные бесшумные сапоги"
		boots.category = ItemData.ItemCategory.ARMOR_BOOTS
		boots.grid_size = Vector2i(2, 2)
		boots.is_silent_boots = true
		boots.armor_defense = 5.0
		boots.base_price_rubles = 2200
		item_database["silent_boots"] = boots

	_ensure_backpack_item("backpack_4x4", "Городской ранец (4x4)", Vector2i(2, 2), Vector2i(4, 4), 900)
	_ensure_backpack_item("raid_backpack_6x6", "Тактический рюкзак (6x6)", Vector2i(3, 3), Vector2i(6, 6), 1800)
	_ensure_backpack_item("backpack_10x10", "Экспедиционный рюкзак (10x10)", Vector2i(4, 4), Vector2i(10, 10), 6800)

	# Оружие и 5 обвесов
	if not item_database.has("ak74m"):
		var ak: WeaponData = WeaponData.new()
		ak.id = "ak74m"
		ak.display_name = "АК-74М"
		ak.category = ItemData.ItemCategory.FIREARM
		ak.hand_slot = WeaponData.WeaponSlot.PRIMARY_FIREARM
		ak.grid_size = Vector2i(4, 2)
		ak.damage = 28.0
		ak.fire_rate_rps = 5.5
		ak.range_meters = 60.0
		ak.magazine_capacity = 30
		ak.ammo_item_id = "ammo_545"
		ak.base_price_rubles = 4500
		item_database["ak74m"] = ak

	if not item_database.has("combat_knife"):
		var knife: WeaponData = WeaponData.new()
		knife.id = "combat_knife"
		knife.display_name = "Армейский нож"
		knife.category = ItemData.ItemCategory.MELEE
		knife.hand_slot = WeaponData.WeaponSlot.SECONDARY_MELEE
		knife.grid_size = Vector2i(1, 2)
		knife.damage = 35.0
		knife.fire_rate_rps = 1.8
		knife.range_meters = 2.3
		knife.magazine_capacity = 0
		knife.base_price_rubles = 1100
		item_database["combat_knife"] = knife

	_ensure_attachment("optic_pso1", "Оптический прицел ПСО-1", AttachmentData.AttachmentSlot.OPTIC, false, 0, 0.75, 1.35, 1900)
	_ensure_attachment("muzzle_suppressor", "Глушитель ПБС-4", AttachmentData.AttachmentSlot.MUZZLE, true, 0, 0.9, 1.0, 2600)
	_ensure_attachment("mag_extended_45", "Увеличенный магазин (45 патр.)", AttachmentData.AttachmentSlot.MAGAZINE, false, 15, 1.0, 1.0, 1500)
	_ensure_attachment("grip_tactical", "Тактическая рукоять", AttachmentData.AttachmentSlot.GRIP, false, 0, 0.8, 1.0, 1200)
	_ensure_attachment("stock_polymer", "Телескопический приклад", AttachmentData.AttachmentSlot.STOCK, false, 0, 0.85, 1.0, 1350)

	# 6 узлов автомобиля
	_ensure_vehicle_part("bumper_ram", "Передний бампер / Таран (Отвал)", VehiclePartData.VehicleSlot.BUMPER_RAM, Vector2i(3, 2), true, 15.0, 0.0, 60.0, 1.5, 4, Vector2i(6, 6), 2800)
	_ensure_vehicle_part("body_armor", "Броня кузова и решётки на окна", VehiclePartData.VehicleSlot.BODY_ARMOR, Vector2i(3, 3), false, 45.0, 0.0, 60.0, 1.5, 4, Vector2i(6, 6), 3200)
	_ensure_vehicle_part("engine_stock", "Двигатель (Форсированный)", VehiclePartData.VehicleSlot.ENGINE, Vector2i(2, 2), false, 0.0, 450.0, 85.0, 1.5, 4, Vector2i(6, 6), 3500)
	_ensure_vehicle_part("tires_stock", "Шины внедорожные", VehiclePartData.VehicleSlot.TIRES, Vector2i(2, 2), false, 0.0, 0.0, 60.0, 2.4, 4, Vector2i(6, 6), 2100)
	_ensure_vehicle_part("exhaust_muffler", "Выхлопная система (Глушитель авто)", VehiclePartData.VehicleSlot.EXHAUST, Vector2i(1, 3), false, 0.0, 0.0, 60.0, 1.5, 2, Vector2i(6, 6), 2900)
	_ensure_vehicle_part("trunk_stock", "Багажник экспедиционный (6x6)", VehiclePartData.VehicleSlot.TRUNK, Vector2i(3, 2), false, 0.0, 0.0, 60.0, 1.5, 4, Vector2i(6, 6), 2400)


func _ensure_med_item(id: String, title: String, size: Vector2i, heal: float, bleed: bool, fracture: bool, cure_sec: float, buff_lvl: int, price: int, col: Color) -> void:
	var item: ItemData = item_database.get(id, null) as ItemData
	if item == null:
		item = ItemData.new()
		item.id = id
		item.display_name = title
		item.grid_size = size
		item.base_price_rubles = price
		item_database[id] = item
	if heal > 0.0 and item.heal_hp_amount <= 0.0:
		item.heal_hp_amount = heal
	if bleed:
		item.cures_bleeding = true
		item.category = ItemData.ItemCategory.MEDICAL
	if fracture:
		item.cures_fracture = true
		item.category = ItemData.ItemCategory.MEDICAL
	if cure_sec > 0.0:
		item.infection_cure_duration_sec = cure_sec
		item.category = ItemData.ItemCategory.INJECTOR if cure_sec <= 30.0 else ItemData.ItemCategory.MEDICAL
	if buff_lvl > 0:
		item.buff_tier = buff_lvl
		item.category = ItemData.ItemCategory.INJECTOR
		item.buff_speed_multiplier = 1.25
		item.buff_strength_multiplier = 1.35
	item.placeholder_color = col


func _ensure_simple_item(id: String, title: String, cat: ItemData.ItemCategory, sz: Vector2i, stack: int, price: int, rare_bm: bool) -> void:
	if item_database.has(id):
		return
	var it: ItemData = ItemData.new()
	it.id = id
	it.display_name = title
	it.category = cat
	it.grid_size = sz
	it.max_stack = stack
	it.base_price_rubles = price
	it.is_rare_black_market = rare_bm
	item_database[id] = it


func _ensure_armor_item(id: String, title: String, cat: ItemData.ItemCategory, sz: Vector2i, def_val: float, price: int) -> void:
	if item_database.has(id):
		return
	var ar: ItemData = ItemData.new()
	ar.id = id
	ar.display_name = title
	ar.category = cat
	ar.grid_size = sz
	ar.armor_defense = def_val
	ar.base_price_rubles = price
	ar.max_durability = 100.0
	item_database[id] = ar


func _ensure_backpack_item(id: String, title: String, sz: Vector2i, bp_sz: Vector2i, price: int) -> void:
	if item_database.has(id):
		return
	var bp: ItemData = ItemData.new()
	bp.id = id
	bp.display_name = title
	bp.category = ItemData.ItemCategory.BACKPACK
	bp.grid_size = sz
	bp.backpack_grid_size = bp_sz
	bp.base_price_rubles = price
	item_database[id] = bp


func _ensure_attachment(id: String, title: String, slot: AttachmentData.AttachmentSlot, supp: bool, extra_mag: int, spread_m: float, range_m: float, price: int) -> void:
	if item_database.has(id) and item_database[id] is AttachmentData:
		return
	var att: AttachmentData = AttachmentData.new()
	att.id = id
	att.display_name = title
	att.category = ItemData.ItemCategory.ATTACHMENT
	att.slot_type = slot
	att.is_suppressor = supp
	att.extra_magazine_capacity = extra_mag
	att.spread_multiplier = spread_m
	att.range_multiplier = range_m
	att.base_price_rubles = price
	item_database[id] = att


func _ensure_vehicle_part(id: String, title: String, slot: VehiclePartData.VehicleSlot, size: Vector2i, negates_ram: bool, armor: float, eng_force: float, max_kmh: float, friction: float, noise_lvl: int, trunk_sz: Vector2i, price: int) -> void:
	if item_database.has(id) and item_database[id] is VehiclePartData:
		return
	var part: VehiclePartData = VehiclePartData.new()
	part.id = id
	part.display_name = title
	part.category = ItemData.ItemCategory.VEHICLE_PART
	part.part_slot = slot
	part.grid_size = size
	part.negates_ram_engine_damage = negates_ram
	part.hull_armor_bonus = armor
	part.engine_force_bonus = eng_force
	part.max_speed_kmh = max_kmh
	part.wheel_friction_slip = friction
	part.driving_noise_level = noise_lvl
	part.trunk_grid_size = trunk_sz
	part.base_price_rubles = price
	item_database[id] = part


func _register_all_traders() -> void:
	trader_database.clear()
	for t_file in [
		"medic.tres", "gunsmith.tres", "mechanic.tres", "supplier.tres",
		"chemist.tres", "auto_mechanic.tres", "black_trader.tres"
	]:
		var p: String = TRADERS_DIR + "/" + t_file
		if ResourceLoader.exists(p):
			var tr: TraderData = load(p) as TraderData
			if tr != null:
				trader_database[tr.trader_id] = tr


func _register_all_quests() -> void:
	quest_database.clear()
	for q_file in [
		"contract_kill_50_zombies.tres",
		"contract_clear_sector.tres",
		"contract_fetch_mutant_heart.tres"
	]:
		var p: String = QUESTS_DIR + "/" + q_file
		if ResourceLoader.exists(p):
			var qd: QuestData = load(p) as QuestData
			if qd != null:
				quest_database[qd.quest_id] = qd


func get_item_data(item_id: String) -> ItemData:
	return item_database.get(item_id, null) as ItemData


func get_vehicle_part_data(part_id: String) -> VehiclePartData:
	return item_database.get(part_id, null) as VehiclePartData


func get_trader_data(trader_id: String) -> TraderData:
	return trader_database.get(trader_id, null) as TraderData


func get_quest_data(quest_id: String) -> QuestData:
	return quest_database.get(quest_id, null) as QuestData


func _init_grids() -> void:
	pockets_grid = InventoryGrid.new(Balance.data.pockets_slot_count, 1)
	safe_grid = InventoryGrid.new(Balance.data.safe_slot_grid_size.x, Balance.data.safe_slot_grid_size.y)
	var bp_size: Vector2i = get_active_backpack_grid_size()
	backpack_grid = InventoryGrid.new(bp_size.x, bp_size.y)
	stash_grid = InventoryGrid.new(Balance.data.stash_grid_size.x, Balance.data.stash_grid_size.y)
	garage_trunk_grid = InventoryGrid.new(Balance.data.car_default_trunk_grid.x, Balance.data.car_default_trunk_grid.y)

	pockets_grid.grid_changed.connect(_sync_backing_arrays)
	safe_grid.grid_changed.connect(_sync_backing_arrays)
	backpack_grid.grid_changed.connect(_sync_backing_arrays)
	stash_grid.grid_changed.connect(_sync_backing_arrays)
	garage_trunk_grid.grid_changed.connect(_sync_garage_trunk_to_state)


func _give_starter_loadout_if_empty() -> void:
	if equipped_items["primary_weapon"] == null:
		equipped_items["primary_weapon"] = "ak74m"
	if equipped_items["secondary_weapon"] == null:
		equipped_items["secondary_weapon"] = "combat_knife"
	if equipped_items["backpack"] == null:
		equipped_items["backpack"] = "raid_backpack_6x6"
		_update_backpack_dimensions()

	if pockets_grid.get_items().is_empty() and backpack_grid.get_items().is_empty():
		pockets_grid.add_item_auto(get_item_data("lockpick"), 3)
		pockets_grid.add_item_auto(get_item_data("bandage"), 1)
		pockets_grid.add_item_auto(get_item_data("splint"), 1)
		pockets_grid.add_item_auto(get_item_data("ammo_545"), 60)

		backpack_grid.add_item_auto(get_item_data("canned_food"), 1)
		backpack_grid.add_item_auto(get_item_data("tourniquet"), 1)
		backpack_grid.add_item_auto(get_item_data("painkiller"), 1)
		backpack_grid.add_item_auto(get_item_data("injector_buff"), 1)

		safe_grid.add_item_auto(get_item_data("antidote"), 1)
		safe_grid.add_item_auto(get_item_data("injector_cure_fast"), 1)

		stash_grid.add_item_auto(get_item_data("lockpick"), 3)
		stash_grid.add_item_auto(get_item_data("bumper_ram"), 1)
		stash_grid.add_item_auto(get_item_data("exhaust_muffler"), 1)
		stash_grid.add_item_auto(get_item_data("muzzle_suppressor"), 1)
		stash_grid.add_item_auto(get_item_data("pawnshop_watch"), 1)
		stash_grid.add_item_auto(get_item_data("mutant_fingers"), 1)


# --- Экономика 7 торговцев: покупка, продажа, ремонт, крафт Химика ---

func get_trader_reputation(trader_id: String) -> int:
	return int(trader_reputations.get(trader_id, 0))


func add_trader_reputation(trader_id: String, delta_rep: int) -> void:
	var cur: int = get_trader_reputation(trader_id)
	trader_reputations[trader_id] = maxi(0, cur + delta_rep)
	EventBus.trader_reputation_changed.emit(trader_id, int(trader_reputations[trader_id]))


func can_buy_from_trader(trader_id: String, item_id: String) -> bool:
	var tr: TraderData = get_trader_data(trader_id)
	var item: ItemData = get_item_data(item_id)
	if tr == null or item == null:
		return false
	if not tr.catalog_item_ids.has(item_id):
		return false
	var req_rep: int = int(tr.item_required_rep.get(item_id, 0))
	if get_trader_reputation(trader_id) < req_rep:
		return false
	return rubles >= item.base_price_rubles


## Покупка предмета у торговца за рубли (кладётся на Склад Хаба или в Рюкзак)
func buy_item_from_trader(trader_id: String, item_id: String) -> bool:
	if not can_buy_from_trader(trader_id, item_id):
		return false
	var item: ItemData = get_item_data(item_id)
	var stack_cnt: int = 30 if item.category == ItemData.ItemCategory.AMMO else 1
	if not stash_grid.add_item_auto(item, stack_cnt):
		if not backpack_grid.add_item_auto(item, stack_cnt):
			return false
	rubles -= item.base_price_rubles
	add_trader_reputation(trader_id, 2)
	return true


## Продажа предмета со Склада торговцу за рубли (Чёрный торговец скупает только редкости по повышенной цене)
func sell_item_to_trader(trader_id: String, source_grid: InventoryGrid, uid: int) -> bool:
	var tr: TraderData = get_trader_data(trader_id)
	var entry: Dictionary = source_grid.get_item_by_uid(uid)
	if tr == null or entry.is_empty():
		return false
	var item: ItemData = entry["item_data"] as ItemData
	if item == null:
		return false

	if tr.buys_only_rare_loot and not item.is_rare_black_market:
		return false

	var stack_cnt: int = int(entry["stack"])
	var mult: float = 1.25 if tr.buys_only_rare_loot else 0.65
	var payout: int = maxi(10, int(round(item.base_price_rubles * mult)) * stack_cnt)

	source_grid.remove_item_by_uid(uid)
	rubles += payout
	add_trader_reputation(trader_id, 3 if tr.buys_only_rare_loot else 1)
	return true


## Механик (Торговец 3): расчёт стоимости и ремонт изношенного оружия или брони за рубли
func get_slot_repair_cost(slot_key: String) -> int:
	var item_id: Variant = equipped_items.get(slot_key, null)
	if not (item_id is String) or str(item_id).is_empty():
		return 0
	var cur_dur: float = float(equipped_durability.get(slot_key, 100.0))
	if cur_dur >= 99.9:
		return 0
	var missing: float = 100.0 - cur_dur
	return maxi(25, int(ceil(missing * 8.0)))


func repair_equipped_slot_at_mechanic(slot_key: String) -> bool:
	var cost: int = get_slot_repair_cost(slot_key)
	if cost <= 0 or rubles < cost:
		return false
	rubles -= cost
	equipped_durability[slot_key] = 100.0
	add_trader_reputation("mechanic", 2)
	equipment_changed.emit()
	return true


## Химик (Торговец 5): создание инъекторов 1–3 уровня (16/35/120 сек) и антивируса (25 сек) из био-образцов
func craft_injector_at_chemist(recipe_index: int) -> bool:
	if recipe_index < 0 or recipe_index >= CHEMIST_RECIPES.size():
		return false
	var rec: Dictionary = CHEMIST_RECIPES[recipe_index]
	var ing_id: String = str(rec["ingredient_id"])
	var out_id: String = str(rec["output_id"])
	var cost: int = int(rec["rubles_cost"])

	if rubles < cost or count_item_including_stash(ing_id) <= 0:
		return false

	var out_item: ItemData = get_item_data(out_id)
	if out_item == null:
		return false

	if not consume_item_including_stash(ing_id, 1):
		return false
	rubles -= cost
	if not stash_grid.add_item_auto(out_item, 1):
		backpack_grid.add_item_auto(out_item, 1)
	add_trader_reputation("chemist", 4)
	return true


# --- Модификация огнестрельного оружия (5 слотов обвесов) ---

func install_weapon_attachment(attachment_id: String) -> bool:
	var att: AttachmentData = get_item_data(attachment_id) as AttachmentData
	if att == null:
		return false
	if count_item_including_stash(attachment_id) <= 0:
		return false

	var slot_key: String = _attachment_slot_key(att.slot_type)
	var prev_id: Variant = weapon_attachments.get(slot_key, null)

	if not consume_item_including_stash(attachment_id, 1):
		return false

	if prev_id is String and not str(prev_id).is_empty():
		var prev_data: ItemData = get_item_data(str(prev_id))
		if prev_data != null:
			stash_grid.add_item_auto(prev_data, 1)

	weapon_attachments[slot_key] = attachment_id
	EventBus.weapon_attachments_changed.emit()
	equipment_changed.emit()
	return true


func remove_weapon_attachment(slot_key: String) -> bool:
	var cur_id: Variant = weapon_attachments.get(slot_key, null)
	if not (cur_id is String) or str(cur_id).is_empty():
		return false
	var att_data: ItemData = get_item_data(str(cur_id))
	if att_data != null:
		if not stash_grid.add_item_auto(att_data, 1):
			backpack_grid.add_item_auto(att_data, 1)
	weapon_attachments[slot_key] = null
	EventBus.weapon_attachments_changed.emit()
	equipment_changed.emit()
	return true


func _attachment_slot_key(slot_type: AttachmentData.AttachmentSlot) -> String:
	match slot_type:
		AttachmentData.AttachmentSlot.OPTIC:
			return "optic"
		AttachmentData.AttachmentSlot.MUZZLE:
			return "muzzle"
		AttachmentData.AttachmentSlot.MAGAZINE:
			return "magazine"
		AttachmentData.AttachmentSlot.GRIP:
			return "grip"
		AttachmentData.AttachmentSlot.STOCK:
			return "stock"
	return "optic"


func has_weapon_suppressor_installed() -> bool:
	var muzzle_id: Variant = weapon_attachments.get("muzzle", null)
	if muzzle_id is String and not str(muzzle_id).is_empty():
		var att: AttachmentData = get_item_data(str(muzzle_id)) as AttachmentData
		return att != null and att.is_suppressor
	return false


func get_weapon_extra_mag_capacity() -> int:
	var mag_id: Variant = weapon_attachments.get("magazine", null)
	if mag_id is String and not str(mag_id).is_empty():
		var att: AttachmentData = get_item_data(str(mag_id)) as AttachmentData
		if att != null:
			return att.extra_magazine_capacity
	return 0


## Ремонт машины в Гараже ремкомплектом от Автомеханика
func repair_garage_vehicle_with_kit() -> bool:
	if not has_garage_vehicle():
		return false
	var cur_hp: float = float(garage_vehicle_state.get("current_durability", 200.0))
	var max_hp: float = float(garage_vehicle_state.get("max_durability", 200.0))
	if cur_hp >= max_hp:
		return false
	if not consume_item_including_stash("vehicle_repair_kit", 1):
		return false
	garage_vehicle_state["current_durability"] = minf(max_hp, cur_hp + 100.0)
	garage_changed.emit()
	return true


# --- Система контрактов и квестов (Чёрный торговец и др.) ---

func accept_quest(quest_id: String) -> bool:
	if not quest_database.has(quest_id):
		return false
	if active_quests.has(quest_id):
		return false
	active_quests[quest_id] = {
		"progress": 0,
		"completed": false,
		"claimed": false
	}
	quests_changed.emit()
	return true


func is_quest_ready_to_claim(quest_id: String) -> bool:
	var qd: QuestData = get_quest_data(quest_id)
	if qd == null or not active_quests.has(quest_id):
		return false
	var st: Dictionary = active_quests[quest_id]
	if bool(st.get("claimed", false)):
		return false

	if qd.objective_type == QuestData.QuestType.FETCH_ITEM:
		return count_item_including_stash(qd.target_id) >= qd.required_amount
	return bool(st.get("completed", false)) or int(st.get("progress", 0)) >= qd.required_amount


func claim_quest_reward(quest_id: String) -> bool:
	if not is_quest_ready_to_claim(quest_id):
		return false
	var qd: QuestData = get_quest_data(quest_id)
	if qd.objective_type == QuestData.QuestType.FETCH_ITEM:
		if not consume_item_including_stash(qd.target_id, qd.required_amount):
			return false

	active_quests[quest_id]["completed"] = true
	active_quests[quest_id]["claimed"] = true
	rubles += qd.reward_rubles
	add_trader_reputation(qd.trader_id, qd.reward_reputation)

	for rew_id in qd.reward_item_ids:
		var rew_item: ItemData = get_item_data(rew_id)
		if rew_item != null:
			stash_grid.add_item_auto(rew_item, 1)

	EventBus.quest_completed.emit(quest_id)
	quests_changed.emit()
	return true


func _on_enemy_killed_for_quests(_enemy_id: String, _faction: int, _pos: Vector3) -> void:
	for q_id in active_quests.keys():
		var qd: QuestData = get_quest_data(str(q_id))
		var st: Dictionary = active_quests[q_id]
		if qd != null and not bool(st.get("claimed", false)) and qd.objective_type == QuestData.QuestType.KILL_COUNT:
			var prog: int = int(st.get("progress", 0)) + 1
			st["progress"] = prog
			if prog >= qd.required_amount:
				st["completed"] = true
			EventBus.quest_progress_updated.emit(q_id, prog, qd.required_amount)
	quests_changed.emit()


func _on_sector_cleared_for_quests(sector_id: String) -> void:
	for q_id in active_quests.keys():
		var qd: QuestData = get_quest_data(str(q_id))
		var st: Dictionary = active_quests[q_id]
		if qd != null and not bool(st.get("claimed", false)) and qd.objective_type == QuestData.QuestType.CLEAR_SECTOR:
			if qd.target_id.is_empty() or qd.target_id == sector_id:
				st["progress"] = qd.required_amount
				st["completed"] = true
				EventBus.quest_progress_updated.emit(q_id, qd.required_amount, qd.required_amount)
	quests_changed.emit()


# --- Вспомогательные методы инвентаря и Гаража ---

func count_any_item(item_id: String) -> int:
	return (
		pockets_grid.count_item_by_id(item_id)
		+ backpack_grid.count_item_by_id(item_id)
		+ safe_grid.count_item_by_id(item_id)
	)


func count_item_including_stash(item_id: String) -> int:
	return count_any_item(item_id) + stash_grid.count_item_by_id(item_id)


func consume_any_item(item_id: String, amount: int = 1) -> bool:
	if count_any_item(item_id) < amount:
		return false
	var remaining: int = amount
	remaining -= pockets_grid.consume_item_by_id(item_id, remaining)
	if remaining > 0:
		remaining -= backpack_grid.consume_item_by_id(item_id, remaining)
	if remaining > 0:
		remaining -= safe_grid.consume_item_by_id(item_id, remaining)
	return remaining <= 0


func consume_item_including_stash(item_id: String, amount: int = 1) -> bool:
	if count_item_including_stash(item_id) < amount:
		return false
	var remaining: int = amount
	remaining -= stash_grid.consume_item_by_id(item_id, remaining)
	if remaining > 0:
		consume_any_item(item_id, remaining)
	return true


func has_garage_vehicle() -> bool:
	return not garage_vehicle_state.is_empty() and float(garage_vehicle_state.get("current_durability", 0.0)) > 0.0


func save_vehicle_to_garage(vehicle: Node) -> void:
	if vehicle == null or not vehicle.has_method("to_garage_dictionary"):
		return
	garage_vehicle_state = vehicle.call("to_garage_dictionary")
	var saved_trunk: Array = garage_vehicle_state.get("trunk_items", [])
	garage_trunk_grid.load_from_serialized_array(saved_trunk, get_item_data)
	garage_changed.emit()


func _sync_garage_trunk_to_state() -> void:
	if not garage_vehicle_state.is_empty():
		garage_vehicle_state["trunk_items"] = garage_trunk_grid.to_serialized_array()
		garage_changed.emit()


func install_vehicle_part_in_garage(part_id: String) -> bool:
	if not has_garage_vehicle():
		return false
	var part_data: VehiclePartData = get_vehicle_part_data(part_id)
	if part_data == null or count_item_including_stash(part_id) <= 0:
		return false

	var slot_key: String = _slot_key_from_enum(part_data.part_slot)
	var parts_dict: Dictionary = garage_vehicle_state.get("installed_parts", {})
	var old_part_id: Variant = parts_dict.get(slot_key, null)

	consume_item_including_stash(part_id, 1)

	if old_part_id is String and not str(old_part_id).is_empty():
		var old_data: ItemData = get_item_data(str(old_part_id))
		if old_data != null:
			stash_grid.add_item_auto(old_data, 1)

	parts_dict[slot_key] = part_id
	garage_vehicle_state["installed_parts"] = parts_dict
	garage_changed.emit()
	return true


func _slot_key_from_enum(slot_enum: VehiclePartData.VehicleSlot) -> String:
	match slot_enum:
		VehiclePartData.VehicleSlot.BUMPER_RAM:
			return "bumper_ram"
		VehiclePartData.VehicleSlot.BODY_ARMOR:
			return "body_armor"
		VehiclePartData.VehicleSlot.ENGINE:
			return "engine"
		VehiclePartData.VehicleSlot.TIRES:
			return "tires"
		VehiclePartData.VehicleSlot.EXHAUST:
			return "exhaust"
		VehiclePartData.VehicleSlot.TRUNK:
			return "trunk"
	return "bumper_ram"


func get_active_backpack_grid_size() -> Vector2i:
	var bp_id: Variant = equipped_items.get("backpack", null)
	if bp_id is String and not str(bp_id).is_empty():
		var bp_data: ItemData = get_item_data(str(bp_id))
		if bp_data != null and bp_data.backpack_grid_size.x >= 4:
			return bp_data.backpack_grid_size
	return Balance.data.backpack_min_grid


func _update_backpack_dimensions() -> void:
	var sz: Vector2i = get_active_backpack_grid_size()
	backpack_grid.resize_grid(sz.x, sz.y)


func is_wearing_silent_boots() -> bool:
	var boots_id: Variant = equipped_items.get("boots", null)
	if boots_id is String and not str(boots_id).is_empty():
		var data: ItemData = get_item_data(str(boots_id))
		return data != null and data.is_silent_boots
	return false


func can_equip_item_to_slot(item_data: ItemData, slot_key: String) -> bool:
	if item_data == null:
		return false
	match slot_key:
		"head":
			return item_data.category == ItemData.ItemCategory.ARMOR_HEAD
		"hands":
			return item_data.category == ItemData.ItemCategory.ARMOR_HANDS
		"torso":
			return item_data.category == ItemData.ItemCategory.ARMOR_TORSO
		"legs":
			return item_data.category == ItemData.ItemCategory.ARMOR_LEGS
		"boots":
			return item_data.category == ItemData.ItemCategory.ARMOR_BOOTS
		"backpack":
			return item_data.category == ItemData.ItemCategory.BACKPACK
		"primary_weapon":
			return item_data.category == ItemData.ItemCategory.FIREARM
		"secondary_weapon":
			return item_data.category == ItemData.ItemCategory.MELEE
		_:
			return false


func equip_item_from_grid(source_grid: InventoryGrid, uid: int, slot_key: String) -> bool:
	var entry: Dictionary = source_grid.get_item_by_uid(uid)
	if entry.is_empty():
		return false
	var item_data: ItemData = entry["item_data"] as ItemData
	if not can_equip_item_to_slot(item_data, slot_key):
		return false

	var previous_id: Variant = equipped_items.get(slot_key, null)
	var new_dur: float = float(entry.get("durability", 100.0))
	source_grid.remove_item_by_uid(uid)

	if previous_id is String and not str(previous_id).is_empty():
		var prev_data: ItemData = get_item_data(str(previous_id))
		if prev_data != null:
			var old_dur: float = float(equipped_durability.get(slot_key, 100.0))
			if not source_grid.add_item_auto(prev_data, 1, old_dur):
				backpack_grid.add_item_auto(prev_data, 1, old_dur)

	equipped_items[slot_key] = item_data.id
	equipped_durability[slot_key] = new_dur
	if slot_key == "backpack":
		_update_backpack_dimensions()
	equipment_changed.emit()
	inventory_changed.emit()
	return true


func unequip_slot_to_grid(slot_key: String, target_grid: InventoryGrid) -> bool:
	var current_id: Variant = equipped_items.get(slot_key, null)
	if not (current_id is String) or str(current_id).is_empty():
		return false
	var item_data: ItemData = get_item_data(str(current_id))
	if item_data == null:
		return false
	var cur_dur: float = float(equipped_durability.get(slot_key, 100.0))
	if target_grid.add_item_auto(item_data, 1, cur_dur):
		equipped_items[slot_key] = null
		equipped_durability[slot_key] = 100.0
		if slot_key == "backpack":
			_update_backpack_dimensions()
		equipment_changed.emit()
		inventory_changed.emit()
		return true
	return false


func _sync_backing_arrays() -> void:
	safe_slot_items = safe_grid.to_serialized_array()
	backpack_items = backpack_grid.to_serialized_array()
	stash_items = stash_grid.to_serialized_array()

	pockets.resize(Balance.data.pockets_slot_count)
	for i in range(pockets.size()):
		var cell_entry: Dictionary = pockets_grid.get_item_at_cell(Vector2i(i, 0))
		pockets[i] = cell_entry.get("item_id", null) if not cell_entry.is_empty() else null

	inventory_changed.emit()


func set_camera_mode_before_raid(mode: CameraMode) -> void:
	if is_camera_locked_for_raid:
		return
	selected_camera_mode = mode


func start_raid(use_garage_vehicle: bool = false) -> void:
	is_camera_locked_for_raid = true
	is_in_raid = true
	current_raid_kills = 0
	deployed_with_garage_vehicle = use_garage_vehicle and has_garage_vehicle()
	raid_time_left_sec = Balance.data.raid_duration_sec

	# Сбрасываем прогресс невыполненных однорейдовых квестов (например, 50 зомби за вылазку)
	for q_id in active_quests.keys():
		var qd: QuestData = get_quest_data(str(q_id))
		var st: Dictionary = active_quests[q_id]
		if qd != null and qd.single_raid_only and not bool(st.get("completed", false)):
			st["progress"] = 0


func _on_player_died() -> void:
	is_in_raid = false
	is_camera_locked_for_raid = false
	for slot_key in equipped_items.keys():
		equipped_items[slot_key] = null
		equipped_durability[slot_key] = 100.0
	for att_key in weapon_attachments.keys():
		weapon_attachments[att_key] = null
	pockets_grid.clear()
	backpack_grid.clear()
	_update_backpack_dimensions()
	if deployed_with_garage_vehicle:
		garage_vehicle_state.clear()
		garage_trunk_grid.clear()
		deployed_with_garage_vehicle = false
		garage_changed.emit()
	_sync_backing_arrays()
	equipment_changed.emit()
	SaveManager.save_game()


func _on_extraction_completed(with_vehicle: bool) -> void:
	is_in_raid = false
	is_camera_locked_for_raid = false
	if deployed_with_garage_vehicle and not with_vehicle:
		garage_vehicle_state.clear()
		garage_trunk_grid.clear()
		garage_changed.emit()
	deployed_with_garage_vehicle = false
	_sync_backing_arrays()
	SaveManager.save_game()