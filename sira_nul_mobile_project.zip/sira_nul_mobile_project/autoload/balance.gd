extends Node
## Автозагрузка Balance: предоставляет глобальный доступ к ресурсу GameBalanceData.

const DEFAULT_BALANCE_PATH: String = "res://resources/default_balance.tres"

var data: GameBalanceData


func _ready() -> void:
	if ResourceLoader.exists(DEFAULT_BALANCE_PATH):
		data = load(DEFAULT_BALANCE_PATH) as GameBalanceData
	if data == null:
		push_warning("Balance: не удалось загрузить default_balance.tres, создан экземпляр по умолчанию.")
		data = GameBalanceData.new()